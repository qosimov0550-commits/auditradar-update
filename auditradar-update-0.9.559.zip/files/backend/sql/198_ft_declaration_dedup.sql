-- 0.9.537: битта БЮД — битта қатор. Аввал гуруҳлаш sys_no ва режим бўйича ҳам эди: шартнома бошқа банкка ўтказилганда
-- («Переведенный») бир БЮД бир ИДН да API дан («2701605/16/261005438»), бошқасида картадан («27016/16.05.2026/1005438»)
-- келади — икки қатор бўлиб, БЮДлар сони ва «товар қаторлари» тўлиқлиги нотўғри (MINGBULOQ: 1270 ўрнига ≈980) чиқарди.
CREATE OR REPLACE VIEW v_ft_declaration AS
SELECT taxpayer_id, kind, MAX(regime)::VARCHAR(10) AS regime, MAX(decl_post)::VARCHAR(10) AS decl_post, decl_no, op_date AS decl_date, MIN(sys_no) AS sys_no,
       string_agg(DISTINCT idn, ', ') AS idn, MAX(partner_name) AS partner_name, MAX(currency1) AS currency1,
       MAX(amount1) AS amount1, COUNT(*) AS n_rows,
       bool_or(position('Переоформ' in op_type) = 1) AS reissued
FROM ft_operation
WHERE decl_no IS NOT NULL
GROUP BY taxpayer_id, kind, decl_no, op_date;
