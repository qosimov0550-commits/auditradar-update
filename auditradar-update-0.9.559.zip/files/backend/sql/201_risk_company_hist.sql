-- 0.9.553: шубҳали корхоналар реестри тарихи — рўйхатда бўлган даврлар (рўйхатдан чиқариш ва қайта киритиш ҳам).
-- Ўтган давр текширувида корхона ўша даврда рўйхатда бўлганми — шу жадвал бўйича (кейин чиқарилган бўлса ҳам).
CREATE TABLE IF NOT EXISTS risk_company_hist (
    id        BIGSERIAL PRIMARY KEY,
    tin       TEXT NOT NULL,
    from_date DATE NOT NULL,           -- платформа рўйхатда кўрган биринчи кун (расмий киритилган сана эмас)
    to_date   DATE                     -- рўйхатдан чиқарилган кун (NULL — ҳозир ҳам рўйхатда)
);
CREATE INDEX IF NOT EXISTS risk_company_hist_tin ON risk_company_hist(tin);
INSERT INTO risk_company_hist(tin, from_date, to_date)
SELECT tin, first_seen, removed_at FROM risk_company k
WHERE NOT EXISTS (SELECT 1 FROM risk_company_hist h WHERE h.tin = k.tin);
