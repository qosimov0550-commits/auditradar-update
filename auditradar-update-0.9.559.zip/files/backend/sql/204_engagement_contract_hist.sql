-- 0.9.558 (фойдаланувчи, 23.11.2026): текширув шартномаси рақами ва санасини таҳрирлаш — сабаби билан, тарихи сақланади.
ALTER TABLE audit_engagement ADD COLUMN IF NOT EXISTS contract_hist JSONB NOT NULL DEFAULT '[]'::jsonb;
