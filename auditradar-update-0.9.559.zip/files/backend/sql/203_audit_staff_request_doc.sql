-- 0.9.556 (фойдаланувчи, 23.11.2026): аудиторлик ташкилотлари ва ходимлари «Созламалар»да; текширувга ташкилот ва аудиторлар
-- танланади; сўровнома электрон тасдиқланганда — рақам, QR код ва ўзгармас нусха.
CREATE TABLE IF NOT EXISTS audit_firm_staff (
    id         BIGSERIAL PRIMARY KEY,
    firm_id    BIGINT      NOT NULL REFERENCES audit_firm(id) ON DELETE CASCADE,
    full_name  TEXT        NOT NULL,
    position   TEXT,                          -- лавозими (директор, раҳбар аудитор, аудитор, ассистент)
    cert_no    TEXT,                          -- аудитор малака сертификати рақами
    cert_date  DATE,
    user_id    BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    active     BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_audit_firm_staff_firm ON audit_firm_staff(firm_id);
ALTER TABLE audit_engagement ADD COLUMN IF NOT EXISTS staff_ids BIGINT[];
ALTER TABLE audit_engagement ADD COLUMN IF NOT EXISTS lead_staff_id BIGINT REFERENCES audit_firm_staff(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS request_doc (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    engagement_id BIGINT,
    firm_id       BIGINT REFERENCES audit_firm(id) ON DELETE SET NULL,
    doc_no        TEXT        NOT NULL,
    doc_date      DATE        NOT NULL,
    token         TEXT        NOT NULL UNIQUE,
    sha256        TEXT        NOT NULL,
    content       BYTEA       NOT NULL,
    approved_by   BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    approved_name TEXT,
    approved_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    summary       JSONB,
    revoked_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_request_doc_tp ON request_doc(taxpayer_id, approved_at DESC);
