-- 0.9.540 (фойдаланувчи, 21.11.2026): божхона маълумотномалари (cargo.customs.uz → «Справочники / Сведения»).
-- Кенгайтма фойдаланувчи очиб қўйган маълумотнома саҳифасидаги жадвални ўқийди (cargo га қўшимча сўров юбормайди).
-- Чоракда бир янгиланади; барча мижозлар учун битта.
CREATE TABLE IF NOT EXISTS customs_ref (
    kind        TEXT        NOT NULL,     -- post | warehouse | country | currency | unit | tnved | transport | guarantee | region | district
    code        TEXT        NOT NULL,
    name        TEXT,
    extra       JSONB       NOT NULL DEFAULT '{}'::jsonb,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (kind, code)
);
CREATE TABLE IF NOT EXISTS customs_ref_load (
    kind        TEXT        PRIMARY KEY,
    rows        INTEGER     NOT NULL DEFAULT 0,
    total       INTEGER,                  -- саҳифадаги «… из N записей»
    loaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id     BIGINT      REFERENCES app_user(id) ON DELETE SET NULL
);
