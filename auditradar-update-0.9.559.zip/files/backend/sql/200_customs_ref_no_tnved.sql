-- 0.9.547 (фойдаланувчи, 21.11.2026): ТН ВЭД кодлари cargo маълумотномаларидан йиғилмайди — синовда олинган қисман
-- ёзувлар (100 / 13 137) ўчирилади, эслатмада «тўлиқ эмас» деб чиқмаслиги учун.
DELETE FROM customs_ref WHERE kind = 'tnved';
DELETE FROM customs_ref_load WHERE kind = 'tnved';
