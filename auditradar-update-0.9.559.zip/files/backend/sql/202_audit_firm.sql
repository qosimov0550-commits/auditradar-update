-- 0.9.555 (фойдаланувчи, 23.11.2026): текширувни ўтказаётган аудиторлик ташкилоти ва аудиторлар — расмий сўровнома ва
-- ёзма ахборот шу ташкилот ва аудиторлар номидан чиқади.
CREATE TABLE IF NOT EXISTS audit_firm (
    id         BIGSERIAL PRIMARY KEY,
    name       TEXT        NOT NULL,
    tin        TEXT,
    address    TEXT,
    director   TEXT,
    cert       TEXT,                    -- аудиторлик ташкилотлари реестридаги рақами / малака сертификати
    active     BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE audit_engagement ADD COLUMN IF NOT EXISTS firm_id BIGINT REFERENCES audit_firm(id) ON DELETE SET NULL;
ALTER TABLE audit_engagement ADD COLUMN IF NOT EXISTS team_ids BIGINT[];
