-- 0.9.559 (фойдаланувчи, 23.11.2026): хизмат шартномалари реестри (аудит ва аутсорсинг), асосий хизмат кўрсатувчи ташкилот,
-- холислик текшируви: бухгалтериясини юритаётган / юритган мижозга аудит шартномаси тузилмайди (аудитдан кейин бухгалтерия — мумкин).
ALTER TABLE audit_firm ADD COLUMN IF NOT EXISTS is_default BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS service_contract (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    firm_id       BIGINT REFERENCES audit_firm(id) ON DELETE SET NULL,
    kind          TEXT        NOT NULL,           -- A1..A5 (аудит), B1..B6 (аутсорсинг/консалтинг), ADD (қўшимча келишув)
    parent_id     BIGINT REFERENCES service_contract(id) ON DELETE SET NULL,
    contract_no   TEXT,
    contract_date DATE,
    period_from   DATE,                           -- хизмат кўрсатиладиган (текшириладиган / юритиладиган) давр
    period_to     DATE,
    valid_to      DATE,                           -- шартнома амал қилиш муддати (NULL — муддатсиз)
    amount        NUMERIC(18,2),
    note          TEXT,
    status        TEXT        NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','CLOSED','CANCELLED')),
    file_name     TEXT,
    file_sha256   TEXT,
    file_data     BYTEA,
    hist          JSONB       NOT NULL DEFAULT '[]'::jsonb,
    warn_note     TEXT,                           -- огоҳлантиришга аудитор изоҳи
    created_by    BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_service_contract_tp ON service_contract(taxpayer_id, contract_date DESC);
ALTER TABLE audit_engagement ADD COLUMN IF NOT EXISTS service_contract_id BIGINT REFERENCES service_contract(id) ON DELETE SET NULL;
