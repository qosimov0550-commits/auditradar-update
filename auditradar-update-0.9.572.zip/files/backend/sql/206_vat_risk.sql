-- 0.9.561: my.soliq «ҚҚС сертификатини тўхтатиш хавфи» мезонлари (кенгайтма очиқ саҳифадан ўқийди) — ҳолатлар тарихи.
CREATE TABLE IF NOT EXISTS vat_risk_snapshot (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    as_of       DATE,
    level       TEXT,
    items       JSONB       NOT NULL,
    url         TEXT,
    taken_by    BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    taken_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_vat_risk_tp ON vat_risk_snapshot(taxpayer_id, taken_at DESC);
