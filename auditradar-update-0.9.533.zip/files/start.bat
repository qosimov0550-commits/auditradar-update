@echo off
rem Аудит Радар: фон режимида ишга тушириш ва браузерда очиш (қора ойнасиз)
start "" "%~dp0venv\Scripts\pythonw.exe" "%~dp0backend\launcher.py" --open
