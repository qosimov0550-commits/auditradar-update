@echo off
chcp 65001 >nul
rem Аудит Радар: платформани компьютер ёқилганда (Windows'га кирмасдан) ишга тушириш.  off — ўчириш
rem Натижа хабар ойнасида чиқади; қора ойна кўринмайди.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\setup_autostart.ps1" %1
