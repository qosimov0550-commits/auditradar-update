-- Солиқ тўловчи тақвими: ҳисобот мажбуриятлари (админ таҳрирлайди), мижоз бўйича истиснолар ва қўлда белгилар
CREATE TABLE IF NOT EXISTS tax_obligation (
    id          SERIAL PRIMARY KEY,
    code        TEXT UNIQUE,
    name        TEXT NOT NULL,
    applies     TEXT NOT NULL DEFAULT 'ALL' CHECK (applies IN ('ALL', 'QQS', 'AOS', 'PROFIT', 'DATA', 'NONE')),
    freq        TEXT NOT NULL CHECK (freq IN ('M', 'Q', 'Y', 'QY')),   -- QY — чоракларда (I–III) ва йил якунида
    due_day     INT  NOT NULL DEFAULT 20 CHECK (due_day BETWEEN 1 AND 31),          -- ой/чорак учун: даврдан кейинги ойнинг шу куни
    year_month  INT  CHECK (year_month BETWEEN 1 AND 12),                            -- йиллик: муддат ойи
    year_day    INT  CHECK (year_day BETWEEN 1 AND 31),                              -- йиллик: муддат куни
    year_offset INT  NOT NULL DEFAULT 1 CHECK (year_offset IN (0, 1)),               -- йиллик: 1 — кейинги йил, 0 — шу йил
    source      TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('vat', 'aos', 'report', 'manual')),
    codes       TEXT[] NOT NULL DEFAULT '{}',                                        -- my3 ҳисобот шакли кодлари (package_code)
    note        TEXT,
    active      BOOLEAN NOT NULL DEFAULT TRUE,
    sort        INT NOT NULL DEFAULT 100,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tax_obligation_client (
    taxpayer_id   INT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    obligation_id INT NOT NULL REFERENCES tax_obligation(id) ON DELETE CASCADE,
    enabled       BOOLEAN NOT NULL,
    PRIMARY KEY (taxpayer_id, obligation_id)
);

CREATE TABLE IF NOT EXISTS tax_filing_mark (
    taxpayer_id   INT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    obligation_id INT NOT NULL REFERENCES tax_obligation(id) ON DELETE CASCADE,
    period        TEXT NOT NULL,                  -- 2026-09 | 2026-Q3 | 2026
    status        TEXT NOT NULL CHECK (status IN ('DONE', 'NA')),
    filed_on      DATE,
    note          TEXT,
    user_id       INT REFERENCES app_user(id) ON DELETE SET NULL,
    marked_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, obligation_id, period)
);

CREATE TABLE IF NOT EXISTS work_holiday (
    day  DATE PRIMARY KEY,
    name TEXT
);

-- асосий мажбуриятлар (Солиқ кодекси бўйича асосий муддатлар — администратор текширади ва таҳрирлайди)
INSERT INTO tax_obligation(code, name, applies, freq, due_day, source, codes, note, sort) VALUES
 ('VAT', 'ҚҚС ҳисоботи', 'QQS', 'M', 20, 'vat', '{}', 'Ҳисобот ойидан кейинги ойнинг 20-кунидан кечиктирмай', 10),
 ('AOS', 'Айланмадан олинадиган солиқ ҳисоботи', 'AOS', 'Q', 20, 'aos', '{}', 'Чоракдан кейинги ойнинг 20-кунидан кечиктирмай (ойлик бўлса — даврни «Ой» қилинг)', 20),
 ('PIT', 'ЖШДС ва ижтимоий солиқ ҳисоб-китоби', 'ALL', 'M', 15, 'report', '{11101}', 'Ҳисобот ойидан кейинги ойнинг 15-кунидан кечиктирмай', 30),
 ('RENT', 'Мол-мулк ижараси бўйича тўлов манбаида ушланган даромад солиғи', 'DATA', 'M', 15, 'report', '{11104}', 'Шундай ҳисобот топширилган мижозларда', 35)
ON CONFLICT (code) DO NOTHING;
INSERT INTO tax_obligation(code, name, applies, freq, due_day, year_month, year_day, year_offset, source, note, sort) VALUES
 ('PROFIT', 'Фойда солиғи ҳисоб-китоби', 'PROFIT', 'QY', 20, 3, 25, 1, 'manual', 'Чораклар — кейинги ойнинг 20-куни; йиллик — кейинги йилнинг 25 марти', 40),
 ('FIN', 'Молиявий ҳисобот (1, 2-шакллар)', 'ALL', 'QY', 25, 3, 15, 1, 'manual', 'Чораклар — кейинги ойнинг 25-куни; йиллик — кейинги йилнинг 15 марти', 50),
 ('PROP', 'Мол-мулк солиғи ҳисоб-китоби', 'ALL', 'Y', 20, 1, 15, 0, 'manual', 'Жорий йилнинг 15 январи (йиллик ҳисоб-китоб)', 60),
 ('LAND', 'Ер солиғи ҳисоб-китоби', 'ALL', 'Y', 20, 1, 15, 0, 'manual', 'Жорий йилнинг 15 январи', 70),
 ('WATER', 'Сув ресурсларидан фойдаланганлик учун солиқ ҳисоб-китоби', 'ALL', 'Y', 20, 1, 15, 0, 'manual', 'Жорий йилнинг 15 январи', 80)
ON CONFLICT (code) DO NOTHING;
