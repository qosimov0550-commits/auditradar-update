-- 0.9.63: хатлар назорати — my.soliq.uz «Муносабатлар» (кирувчи ва чиқувчи хатлар рўйхати, фақат ўқилади).
-- Хат матни ва иловалари олинмайди; ўқилмаган хат очилмайди (сайтда «ўқилди» бўлиб қолмаслиги учун).
CREATE TABLE IF NOT EXISTS mail_letter (
    id             BIGSERIAL PRIMARY KEY,
    taxpayer_id    BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    direction      VARCHAR(3)  NOT NULL,              -- IN | OUT
    ext_id         TEXT        NOT NULL,
    number         TEXT,
    title          TEXT,
    type_name      TEXT,
    type_code      TEXT,
    sender         TEXT,
    registered_at  TIMESTAMP,
    read_at        TIMESTAMP,
    deadline       DATE,
    answered       BOOLEAN,
    answer_state   TEXT,
    extra          JSONB,
    first_seen     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, direction, ext_id)
);
CREATE INDEX IF NOT EXISTS ix_mail_letter_tp ON mail_letter(taxpayer_id, registered_at DESC);
CREATE TABLE IF NOT EXISTS mail_fetch (
    taxpayer_id  BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    fetched_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    keys_in      TEXT,
    keys_out     TEXT,
    rows         INTEGER
);
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS eri_expires DATE;
INSERT INTO app_setting(key, value) VALUES ('tasks.auto_letters', '1') ON CONFLICT (key) DO NOTHING;
