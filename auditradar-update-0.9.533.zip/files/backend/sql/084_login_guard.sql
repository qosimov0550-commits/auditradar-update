-- 0.9.92: кириш ҳимояси — нотўғри пароллар журнали (вақтинча блоклаш учун) ва сессия версияси
-- (парол алмаштирилса ёки фойдаланувчи ўчирилса — эски сессиялар бекор бўлади)
CREATE TABLE IF NOT EXISTS auth_fail (
    id     BIGSERIAL PRIMARY KEY,
    login  TEXT NOT NULL,
    ip     TEXT,
    at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_auth_fail_login ON auth_fail(login, at DESC);
CREATE INDEX IF NOT EXISTS ix_auth_fail_ip ON auth_fail(ip, at DESC);
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS session_ver INT NOT NULL DEFAULT 0;
