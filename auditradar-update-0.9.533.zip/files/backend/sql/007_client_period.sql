-- Мижоз бўйича таҳлил даври: платформадаги барча маълумотлар (ҚҚС иловалари, шакллар, ЭҲФ, журнал,
-- топилмалар, Excel) шу давр бўйича шакллантирилади. Бўш — барча даврлар.
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS period_from DATE;
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS period_to   DATE;
