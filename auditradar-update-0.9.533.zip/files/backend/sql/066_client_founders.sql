-- my.soliq.uz «Устав капитали»: таъсисчилар (номи, СТИР, улуш, сумма) — очиқ маълумот; ЖШШИР сақланмайди
ALTER TABLE client_profile ADD COLUMN IF NOT EXISTS founders JSONB;
ALTER TABLE client_profile ADD COLUMN IF NOT EXISTS founders_at TIMESTAMPTZ;
