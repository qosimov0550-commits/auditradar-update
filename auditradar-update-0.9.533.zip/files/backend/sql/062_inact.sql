-- Кирувчи далолатномалар (ЭҲФсиз кирим): таъсисчидан, норезидент хизматлари (импорт), жисмоний шахсдан, бошқа резидентдан.
-- Проводкалар (gl.py, манба ACT), дебитор-кредитор (arap.py) ва топилмаларга манба бўлади.
CREATE TABLE IF NOT EXISTS inact (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL CHECK (kind IN ('FOUNDER_CAP', 'FOUNDER_GIFT', 'FOUNDER_PAID', 'IMPORT_SVC', 'PERSON', 'RESIDENT')),
    act_no        TEXT NOT NULL DEFAULT '',
    act_date      DATE NOT NULL,
    cp_name       TEXT NOT NULL DEFAULT '',
    cp_tin        TEXT NOT NULL DEFAULT '',          -- СТИР (9) ёки ЖШШИР (14); норезидентда бўш бўлиши мумкин
    cp_country    TEXT NOT NULL DEFAULT '',
    contract_no   TEXT NOT NULL DEFAULT '',
    contract_date DATE,
    currency      TEXT NOT NULL DEFAULT 'UZS',
    rate          NUMERIC(18,6) NOT NULL DEFAULT 1,  -- валюта курси (сўмга), акт санасидаги МБ курси
    items         JSONB NOT NULL DEFAULT '[]',       -- [{name, item_kind: goods|service|asset, qty, unit, price, amount (валютада), account}]
    total_cur     NUMERIC(20,2) NOT NULL DEFAULT 0,  -- валютада жами
    total         NUMERIC(20,2) NOT NULL DEFAULT 0,  -- сўмда жами (ҚҚС ва ушланадиган солиқдан олдин, шартнома суммаси)
    vat_rate      NUMERIC(5,2),                      -- тескари ҚҚС (импорт хизмати), % ; NULL — йўқ
    wht_rate      NUMERIC(5,2),                      -- тўлов манбаида ушланадиган солиқ (норезидент даромади / ЖШДС), %
    social_rate   NUMERIC(5,2),                      -- ижтимоий солиқ (жисмоний шахс билан фуқаровий-ҳуқуқий шартнома), %
    gross_up      BOOLEAN NOT NULL DEFAULT FALSE,    -- шартнома суммаси солиқсиз (норезидентга тўлиқ тўланади, солиқ устига)
    taxes         JSONB NOT NULL DEFAULT '{}',       -- ҳисобланган: {vat, wht, social, payable}
    note          TEXT NOT NULL DEFAULT '',
    files         JSONB NOT NULL DEFAULT '[]',       -- [{name, path, size, uploaded_at}]
    source        TEXT NOT NULL DEFAULT 'form',      -- form | excel
    created_by    BIGINT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS inact_tp ON inact (taxpayer_id, act_date);
