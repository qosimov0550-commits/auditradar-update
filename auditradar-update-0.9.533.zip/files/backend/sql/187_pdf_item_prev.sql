-- 0.9.467: БЮД нусхаси товари — 37-графа (процедура, масалан «40 74» — божхона омборидан эркин муомалага) ва
-- 40-графа (олдинги ҳужжат: БЮД рақами, товар №, брутто/нетто). ИМ74 → ИМ40 ни аниқ боғлаш учун.
ALTER TABLE ft_decl_pdf_item ADD COLUMN IF NOT EXISTS proc TEXT;
ALTER TABLE ft_decl_pdf_item ADD COLUMN IF NOT EXISTS prev JSONB NOT NULL DEFAULT '[]'::jsonb;
