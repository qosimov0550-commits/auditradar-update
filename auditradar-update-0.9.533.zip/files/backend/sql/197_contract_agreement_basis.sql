-- 0.9.529: E-CONTRACT қўшимча келишувлари (API: шартнома картаси xlsx ва /contract/get agreements[])
CREATE TABLE IF NOT EXISTS ft_contract_agreement (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    idn         TEXT   NOT NULL,
    serial_no   TEXT   NOT NULL DEFAULT '',
    doc_no      TEXT,
    doc_date    DATE,
    subject     TEXT,
    source      VARCHAR(8) NOT NULL DEFAULT 'API',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, idn, serial_no)
);
CREATE INDEX IF NOT EXISTS ix_ft_contract_agreement ON ft_contract_agreement(taxpayer_id, idn);

-- 0.9.529: носавдо / реэкспорт (ЭК11, 24-графа 81–89) БЮДлари учун асос ҳужжати (3 томонлама битим, воситачилик
-- шартномаси, хат, ДХР …) — PDF асл нусхаси юкланса «ҳужжатни кўриб чиқинг» огоҳлантириши ёпилади
CREATE TABLE IF NOT EXISTS ft_decl_basis (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    decl_no     INT,
    decl_date   DATE,
    idn         TEXT,
    file_name   TEXT NOT NULL,
    file_path   TEXT NOT NULL,
    sha256      TEXT NOT NULL,
    user_id     BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, sha256)
);
CREATE INDEX IF NOT EXISTS ix_ft_decl_basis ON ft_decl_basis(taxpayer_id, decl_no);

SELECT ar_ver_attach();
