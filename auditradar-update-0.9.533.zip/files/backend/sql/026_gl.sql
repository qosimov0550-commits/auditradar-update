-- Бухгалтерия ҳисоби (21-сон БҲМС счётлар режаси, 54-сон низом): счётлар, тасниф қоидалари, автомат проводкалар.
CREATE TABLE IF NOT EXISTS gl_account (
    code     TEXT PRIMARY KEY,
    name     TEXT NOT NULL,
    kind     TEXT NOT NULL DEFAULT 'AP',   -- A актив, P пассив, AP актив-пассив, T транзит (9000-счётлар)
    section  TEXT                          -- баланс/молиявий натижа бўлими
);

-- Тасниф қоидалари: калит (масалан, 'bank.fee', 'wage.service') ёки матн бўйича намуна → счёт.
-- taxpayer_id NULL — умумий қоида; мижоз учун алоҳида қоида умумийдан устун.
CREATE TABLE IF NOT EXISTS gl_rule (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind         TEXT    NOT NULL DEFAULT 'KEY',   -- KEY | BUY_PATTERN
    rule_key     TEXT,                              -- KEY учун
    pattern      TEXT,                              -- BUY_PATTERN учун (регуляр ифода, ЭҲФ товар номи/МХИК номи)
    profile      TEXT,                              -- NULL — барча; service | trade | production
    item         TEXT,                              -- NULL — барча; service (иш/хизмат) | goods (товар)
    account      TEXT    NOT NULL,
    priority     INTEGER NOT NULL DEFAULT 100,
    note         TEXT,
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_gl_rule_key ON gl_rule(COALESCE(taxpayer_id, 0), rule_key) WHERE kind = 'KEY';

CREATE TABLE IF NOT EXISTS gl_settings (
    taxpayer_id  BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    profile      TEXT,             -- service | trade | production (NULL — ЭҲФдан аниқланади)
    built_at     TIMESTAMPTZ,
    note         TEXT
);

CREATE TABLE IF NOT EXISTS gl_entry (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    op_date      DATE    NOT NULL,
    dt           TEXT    NOT NULL,
    kt           TEXT    NOT NULL,
    amount       NUMERIC(20,2) NOT NULL,
    source       TEXT    NOT NULL,          -- ESF | BANK | PAYROLL | KLS | CLOSE
    source_id    BIGINT,
    cp_tin       TEXT,
    cp_name      TEXT,
    text         TEXT,
    rule         TEXT                       -- қайси қоида билан
);
CREATE INDEX IF NOT EXISTS ix_gl_entry_tp ON gl_entry(taxpayer_id, op_date);
CREATE INDEX IF NOT EXISTS ix_gl_entry_dt ON gl_entry(taxpayer_id, dt);
CREATE INDEX IF NOT EXISTS ix_gl_entry_kt ON gl_entry(taxpayer_id, kt);

-- 1С айланма-сальдо ведомостидан бошланғич қолдиқ (2-босқич)
CREATE TABLE IF NOT EXISTS gl_opening (
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    as_of        DATE    NOT NULL,
    account      TEXT    NOT NULL,
    debit        NUMERIC(20,2) NOT NULL DEFAULT 0,
    credit       NUMERIC(20,2) NOT NULL DEFAULT 0,
    PRIMARY KEY (taxpayer_id, account)
);
