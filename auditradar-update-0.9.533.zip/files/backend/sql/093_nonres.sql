-- 0.9.131: my.soliq.uz «Норезидентларнинг даромадидан солиқ агенти томонидан тўлов манбаидан ушлаб қолинадиган фойда
-- солиғининг ҳисоб-китоби» (қабул қилинган ҳисоботлар). Ҳисоб-китоб йил бошидан ўсиб борувчи: йил бўйича энг охирги
-- ҳисобот олинади ва шу йил тўловлари унинг маълумотидан қайта ёзилади. Раҳбар/бош ҳисобчи ЖШШИР ва Ф.И.Ш. сақланмайди.
CREATE TABLE IF NOT EXISTS ft_nonres_report (
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    report_id     TEXT   NOT NULL,
    year          INT    NOT NULL,
    period        INT,
    report_type   TEXT,
    state         TEXT,
    total_income  NUMERIC(20,2),
    tax_base      NUMERIC(20,2),
    tax           NUMERIC(20,2),
    lines         JSONB,                       -- {сатр коди: [даромад, база, солиқ]}
    loaded        BOOLEAN NOT NULL DEFAULT FALSE,
    fetched_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, report_id)
);
CREATE TABLE IF NOT EXISTS ft_nonres_income (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    year          INT    NOT NULL,
    seq           INT,
    recipient     TEXT,
    income_type   TEXT,
    pay_date      DATE,
    country       TEXT,
    country_code  TEXT,
    contract_no   TEXT,
    contract_date DATE,
    idn           TEXT,
    amount        NUMERIC(20,2),
    benefit_amount NUMERIC(20,2),
    benefit_basis TEXT,
    pe_amount     NUMERIC(20,2),
    treaty_rate   NUMERIC(8,2),
    treaty_exempt NUMERIC(20,2),
    treaty_basis  TEXT,
    tax_base      NUMERIC(20,2),
    tax_rate      NUMERIC(8,2),
    tax           NUMERIC(20,2),
    report_id     TEXT
);
CREATE INDEX IF NOT EXISTS ix_ft_nonres_income ON ft_nonres_income(taxpayer_id, year, pay_date);
