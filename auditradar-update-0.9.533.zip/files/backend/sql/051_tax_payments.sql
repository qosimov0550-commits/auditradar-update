-- Тўлов муддатлари (ҳисоботдан ташқари): фойда солиғи ойлик бўнаги, мол-мулк, ер ва сув солиқлари бўнак тўловлари
ALTER TABLE tax_obligation ADD COLUMN IF NOT EXISTS kind    TEXT NOT NULL DEFAULT 'REPORT';   -- REPORT | PAY
ALTER TABLE tax_obligation ADD COLUMN IF NOT EXISTS jan_day INT;                              -- январ ойи учун бошқа кун (масалан, 20)

ALTER TABLE tax_obligation DROP CONSTRAINT IF EXISTS tax_obligation_freq_check;
ALTER TABLE tax_obligation ADD CONSTRAINT tax_obligation_freq_check CHECK (freq IN ('M', 'Q', 'Y', 'QY', 'MC', 'QC'));
ALTER TABLE tax_obligation DROP CONSTRAINT IF EXISTS tax_obligation_applies_check;
ALTER TABLE tax_obligation ADD CONSTRAINT tax_obligation_applies_check
    CHECK (applies IN ('ALL', 'QQS', 'AOS', 'PROFIT', 'DATA', 'NONE', 'NOAOS', 'BIG'));

INSERT INTO tax_obligation(code, name, kind, applies, freq, due_day, jan_day, source, tax_codes, article, note, sort) VALUES
 ('PROFIT_ADV', 'Фойда солиғи — ойлик бўнак тўлови', 'PAY', 'BIG', 'MC', 23, NULL, 'manual', '{32}', '340',
  'Олдинги йил жами даромади 20 млрд сўмдан ошган мижозлар — ҳар ойнинг 23-кунидан кечиктирмай (СК 340-модда). Айланма рўйхатдан олинади', 41),
 ('PROP_PAY_M', 'Мол-мулк солиғи — бўнак тўлови (1/12)', 'PAY', 'NOAOS', 'MC', 10, 20, 'manual', '{44}', '417',
  'Айланма солиғи тўловчи бўлмаганлар — ҳар ойнинг 10-куни, январ учун 20 январ (СК 417-модда)', 61),
 ('PROP_PAY_Q', 'Мол-мулк солиғи — бўнак тўлови (1/4)', 'PAY', 'AOS', 'QC', 20, NULL, 'manual', '{44}', '417',
  'Айланма солиғи тўловчилар — ҳар чорак учинчи ойининг 20-куни (СК 417-модда)', 62),
 ('LAND_PAY_M', 'Ер солиғи — тўлов (1/12)', 'PAY', 'NOAOS', 'MC', 10, 20, 'manual', '{53}', '432',
  'Қишлоқ хўжалигига мўлжалланмаган ерлар, айланма солиғи тўловчи бўлмаганлар — ҳар ойнинг 10-куни, январ учун 20 январ (СК 432-модда)', 71),
 ('LAND_PAY_Q', 'Ер солиғи — тўлов (1/4)', 'PAY', 'AOS', 'QC', 20, NULL, 'manual', '{53}', '432',
  'Айланма солиғи тўловчилар — ҳар чорак учинчи ойининг 20-куни (СК 432-модда)', 72),
 ('WATER_PAY_M', 'Сув солиғи — бўнак тўлови (1/12)', 'PAY', 'NOAOS', 'MC', 20, NULL, 'manual', '{52}', '448',
  'Йиллик солиқ 200 БҲМ дан ортиқ юридик шахслар — ҳар ойнинг 20-куни (СК 448-модда). 200 БҲМ дан кам бўлса — мижоз бўйича чораклик тўловга ўтказинг', 81),
 ('WATER_PAY_Q', 'Сув солиғи — бўнак тўлови (1/4)', 'PAY', 'AOS', 'QC', 20, NULL, 'manual', '{52}', '448',
  'Айланма солиғи тўловчилар ва 200 БҲМ дан кам бўлганлар — ҳар чорак учинчи ойининг 20-куни (СК 448-модда)', 82)
ON CONFLICT (code) DO NOTHING;

INSERT INTO tax_obligation(code, name, kind, applies, freq, due_day, year_month, year_day, year_offset, source, tax_codes, article, note, sort) VALUES
 ('PROP_REF', 'Мол-мулк солиғи — бўнак ҳақида маълумотнома', 'REPORT', 'NONE', 'Y', 20, 1, 20, 0, 'manual', '{44}', '417',
  'Жорий йилнинг 20 январи; янги ташкил этилганлар — рўйхатдан ўтгандан 30 кун ичида (СК 417-модда)', 59),
 ('WATER_REF', 'Сув солиғи — бўнак ҳақида маълумотнома', 'REPORT', 'NONE', 'Y', 20, 1, 20, 0, 'manual', '{52}', '448',
  'Жорий йилнинг 20 январи (СК 448-модда)', 79)
ON CONFLICT (code) DO NOTHING;
