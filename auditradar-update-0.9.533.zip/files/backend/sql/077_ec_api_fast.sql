-- 0.9.58: E-CONTRACT API тезлаштириш — шартнома бўйича охирги API синхронлаш вақти ва рўйхат қатори хеши
-- (ўзгармаган шартномалар қайта сўралмайди), хом жавоблар фақат ўзгарганда сақланади.
ALTER TABLE ft_contract ADD COLUMN IF NOT EXISTS api_synced_at TIMESTAMPTZ;
ALTER TABLE ft_contract ADD COLUMN IF NOT EXISTS api_list_hash TEXT;
ALTER TABLE ft_api_raw ADD COLUMN IF NOT EXISTS payload_hash TEXT;
CREATE INDEX IF NOT EXISTS ix_ft_api_raw_key ON ft_api_raw(taxpayer_id, endpoint, idn, page, id DESC);
INSERT INTO app_setting(key, value) VALUES ('ec.auto', '1') ON CONFLICT (key) DO NOTHING;
