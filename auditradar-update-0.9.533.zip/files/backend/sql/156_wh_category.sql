-- 0.9.335: омбор туркумлари (фойдаланувчи рўйхати) ва МХИК бўйича туркумлаш қоидалари.
-- stock=TRUE — омборда қолдиқ юритиладиган (FIFO) туркум; FALSE — харажат ёки асосий восита (фақат харид).
CREATE TABLE IF NOT EXISTS wh_category (
    code   TEXT PRIMARY KEY,
    name   TEXT NOT NULL,
    stock  BOOLEAN NOT NULL DEFAULT TRUE,
    sort   INTEGER NOT NULL DEFAULT 100
);
INSERT INTO wh_category(code, name, stock, sort) VALUES
 ('01', 'Асосий воситалар', FALSE, 1),
 ('02', 'ЁММ', FALSE, 2),
 ('03', 'Коммунал хизматлар', FALSE, 3),
 ('04', 'Кўрсатилган хизматлар', FALSE, 4),
 ('05', 'Қайта сотиш учун олинган товарлар', TRUE, 5),
 ('06', 'Хом ашё ва материаллар', TRUE, 6),
 ('07', 'Бошқа харажатлар', FALSE, 7),
 ('08', 'Қурилиш материаллари (ўз эҳтиёжи учун)', TRUE, 8),
 ('09', 'Суғурта хизматлари', FALSE, 9),
 ('10', 'Тайёр ва ярим тайёр маҳсулотлар', TRUE, 10),
 ('11', 'Тугалланмаган ишлаб чиқариш', TRUE, 11),
 ('12', 'Эҳтиёт қисмлар', TRUE, 12),
 ('13', 'Қайта ишлашга берилган товарлар', TRUE, 13)
ON CONFLICT (code) DO NOTHING;

-- МХИК (ёки унинг бошланғич қисми) -> туркум. taxpayer_id NULL — барча мижозлар учун; мижоз қоидаси устун.
CREATE TABLE IF NOT EXISTS wh_cat_rule (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT REFERENCES taxpayer(id) ON DELETE CASCADE,
    mxik         TEXT NOT NULL,
    category     TEXT NOT NULL REFERENCES wh_category(code),
    user_id      BIGINT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_wh_cat_rule ON wh_cat_rule(COALESCE(taxpayer_id, 0), mxik);
