-- Контрагентларнинг давлат реестридаги ҳолати (ihamkor.uz очиқ қидируви) — барча мижозлар учун умумий кэш.
CREATE TABLE IF NOT EXISTS cp_registry (
    tin            TEXT PRIMARY KEY,
    found          BOOLEAN     NOT NULL DEFAULT FALSE,
    name           TEXT,
    address        TEXT,
    state_id       TEXT,                  -- "0" — фаол
    state_title    TEXT,
    registered_at  DATE,
    liquidated_at  DATE,
    checked_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    source         TEXT        NOT NULL DEFAULT 'ihamkor.uz'
);
