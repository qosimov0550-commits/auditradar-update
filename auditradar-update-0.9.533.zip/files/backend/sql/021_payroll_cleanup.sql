-- 0.6.7–0.6.9 да 11104 каби бошқа 111xx пакетлари иш ҳақи ҳисоботи ўрнига ёзилиб қолган бўш ёзувлар олиб ташланади.
DELETE FROM payroll_report WHERE NOT has_rows AND income_ytd IS NULL;
