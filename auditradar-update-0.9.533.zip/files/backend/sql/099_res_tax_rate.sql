-- 0.9.150: ресурс солиқлари ставкалари (ер, мол-мулк, сув, ер қаъри) — «Норматив ҳужжатлар» да кўрсатилади; администратор таҳрирлайди.
CREATE TABLE IF NOT EXISTS res_tax_rate (
    id         BIGSERIAL PRIMARY KEY,
    tax        TEXT    NOT NULL,          -- land | property | water | subsoil
    payer      TEXT    NOT NULL,          -- legal | individual | all
    grp        TEXT,                      -- кичик гуруҳ (масалан, «Қишлоқ хўжалигига мўлжалланмаган ерлар»)
    item       TEXT    NOT NULL,
    year       INT     NOT NULL,
    value      NUMERIC(20,4),
    prev       NUMERIC(20,4),             -- олдинги йил қиймати (таққослаш учун)
    unit       TEXT,
    note       TEXT,
    source     TEXT,
    verified   BOOLEAN NOT NULL DEFAULT TRUE,
    sort       INT     NOT NULL DEFAULT 0,
    updated_by BIGINT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_res_tax_rate ON res_tax_rate(tax, payer, (COALESCE(grp, '')), item, year);
