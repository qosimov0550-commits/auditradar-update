-- 0.9.406 (фойдаланувчи, 10.11.2026): таҳрирланган чек таркибини платформа ўзи алмаштирмайди — чеклар сайтнинг ойлик Excel'идан
-- қайта олинади. 0.9.370–0.9.405 да таҳрирлар рўйхати бўйича алмаштирилган чеклар бор ойлар — кейинги йиғишда қайта олинади.
INSERT INTO nkm_recollect(taxpayer_id, y, m)
SELECT DISTINCT taxpayer_id, EXTRACT(YEAR FROM paid_at)::smallint, EXTRACT(MONTH FROM paid_at)::smallint
  FROM nkm_edit WHERE source = 'MY' AND applied
ON CONFLICT (taxpayer_id, y, m) DO UPDATE SET requested_at = now();
