-- 0.9.419: марказлашган ташкилотлар (умумий маълумотнома) ва мижоз бўйича бухгалтер қарори; ғазна орқали «иш ҳақидан ушланма»

-- Эски (туман/шаҳар) СТИР -> бош ташкилот СТИРи. Барча мижозлар учун битта рўйхат.
CREATE TABLE IF NOT EXISTS cp_central (
    member_tin   TEXT PRIMARY KEY,
    member_name  TEXT,
    head_tin     TEXT NOT NULL,
    head_name    TEXT,
    region       TEXT,
    merged_on    DATE,
    note         TEXT,
    user_id      BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (member_tin <> head_tin)
);
CREATE INDEX IF NOT EXISTS ix_cp_central_head ON cp_central(head_tin);

-- Мижоз бўйича: бухгалтер қарори билан шу бош ташкилот бўйича ҳисоб-китоблар ягона ҳисобга жамланади
CREATE TABLE IF NOT EXISTS cp_central_client (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    head_tin     TEXT   NOT NULL,
    enabled      BOOLEAN NOT NULL DEFAULT TRUE,
    since        DATE,
    basis        TEXT,
    note         TEXT,
    user_id      BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, head_tin)
);

-- Ғазна орқали тўлов — ходимнинг иш ҳақидан ушланма (ўқиш, алимент/ижро, кредит…): шахсий ҳисоб бўйича (txn_key NULL)
-- ёки битта тўлов бўйича. ЖШШИР шахсий маълумот — фақат шу мижозда сақланади.
CREATE TABLE IF NOT EXISTS treasury_salary (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    ls           TEXT   NOT NULL,
    txn_key      TEXT,
    pinfl        TEXT,
    fio          TEXT,
    sub          TEXT   NOT NULL DEFAULT 'OTHER' CHECK (sub IN ('STUDY', 'ALIMONY', 'LOAN', 'OTHER')),
    note         TEXT,
    user_id      BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_treasury_salary ON treasury_salary(taxpayer_id, ls, COALESCE(txn_key, ''));
