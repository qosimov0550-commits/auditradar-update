-- ЭҲФ ↔ реестр: жисмоний шахсларга ЭҲФ (реестрда СТИР бўш қолади) ҳам солиштирилади
DROP VIEW IF EXISTS v_esf_vs_register;
CREATE VIEW v_esf_vs_register AS
WITH reg AS (
    SELECT taxpayer_id, variant, register, counterparty_tin, invoice_key, invoice_date,
           MIN(period_year * 100 + period_month) AS reg_period,
           SUM(net_amount) AS net_amount, SUM(vat_amount) AS vat_amount
    FROM v_reg_invoice
    GROUP BY 1, 2, 3, 4, 5, 6
)
SELECT
    e.taxpayer_id,
    e.direction,
    e.id                                                  AS esf_id,
    e.external_id,
    COALESCE(c.tin, c.pinfl)                              AS counterparty_tin,
    COALESCE(c.name, '')                                  AS counterparty_name,
    e.esf_no, e.esf_date, e.esf_type, e.status_raw, e.sent_at, e.signed_at, e.operator_host,
    e.total_net, e.total_vat,
    EXTRACT(YEAR FROM e.esf_date) * 100 + EXTRACT(MONTH FROM e.esf_date) AS esf_period,
    rs.reg_period  AS report_period, rs.vat_amount AS report_vat,
    rg.reg_period  AS form_period,   rg.vat_amount AS form_vat
FROM esf e
JOIN counterparty c ON c.id = e.counterparty_id
LEFT JOIN reg rs ON rs.taxpayer_id = e.taxpayer_id AND rs.variant = 'SUBMITTED'
                AND rs.register = CASE e.direction WHEN 'IN' THEN 'PURCHASE' ELSE 'SALE' END
                AND (rs.counterparty_tin = COALESCE(c.tin, c.pinfl)
                     OR (rs.counterparty_tin IS NULL AND c.tin IS NULL))  -- жисмоний шахс: реестрда СТИР бўш
                AND rs.invoice_key = norm_doc_no(e.esf_no) AND rs.invoice_date = e.esf_date
LEFT JOIN reg rg ON rg.taxpayer_id = e.taxpayer_id AND rg.variant = 'GENERATED'
                AND rg.register = CASE e.direction WHEN 'IN' THEN 'PURCHASE' ELSE 'SALE' END
                AND (rg.counterparty_tin = COALESCE(c.tin, c.pinfl)
                     OR (rg.counterparty_tin IS NULL AND c.tin IS NULL))  -- жисмоний шахс: реестрда СТИР бўш
                AND rg.invoice_key = norm_doc_no(e.esf_no) AND rg.invoice_date = e.esf_date;

