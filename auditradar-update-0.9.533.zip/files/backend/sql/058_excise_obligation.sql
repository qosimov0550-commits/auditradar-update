-- Акциз ҳисоботи мажбурияти: 10824 пакетини топширган мижозларга ўзи ёқилади, топширилганлиги tax_report дан олинади
UPDATE tax_obligation SET applies='DATA', source='report', codes='{10824}', note='Ҳар ойда, кейинги ойнинг 10-куни (СК 292-модда); акциз ҳисоботи (10824 пакети) топширган мижозларга ўзи ёқилади'
WHERE code='EXCISE';
UPDATE tax_report SET kind='EXCISE' WHERE package_code='10824';
