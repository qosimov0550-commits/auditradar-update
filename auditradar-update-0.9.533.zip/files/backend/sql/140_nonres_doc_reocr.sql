-- 0.9.286: хитой сертификатида ички қавсли ном («Alqun (Tianjin) …») тўлиқ олинади — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
