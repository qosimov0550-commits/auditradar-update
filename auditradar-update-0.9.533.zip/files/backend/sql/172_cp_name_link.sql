-- 0.9.430: контрагентни номи бўйича боғлаш — платформа автомат топгани (AUTO), бухгалтер тасдиқлагани (CONFIRMED) ёки
-- рад этгани (REJECTED, tin NULL — алоҳида контрагент). CONFIRMED / REJECTED қотирилади: кейин автомат изланмайди.
CREATE TABLE IF NOT EXISTS cp_name_link (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    name_key     TEXT   NOT NULL,
    cp_name      TEXT,
    tin          TEXT,
    status       TEXT   NOT NULL CHECK (status IN ('AUTO', 'CONFIRMED', 'REJECTED')),
    source       TEXT,
    user_id      BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, name_key)
);
