-- 0.9.240: е-ижара (ijara.soliq.uz) — рўйхатга олинган кўчмас мулк ижара шартномалари (фақат ўқиш).
-- direction: IN — корхона ижарачи (кирувчи), OUT — корхона ижарага берувчи (чиқувчи). Телефон ва паспорт сақланмайди.
CREATE TABLE IF NOT EXISTS ijara_contract (
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    ext_id        BIGINT NOT NULL,
    direction     TEXT   NOT NULL CHECK (direction IN ('IN', 'OUT')),
    state         INTEGER,
    state_name    TEXT,
    date_begin    DATE,
    date_end      DATE,
    date_deact    DATE,
    month_sum     NUMERIC(20,2),
    all_sum       NUMERIC(20,2),
    currency      INTEGER,
    object_code   TEXT,
    object_type   TEXT,
    object_address TEXT,
    place_type    INTEGER,
    rent_field    NUMERIC(16,2),
    all_field     NUMERIC(16,2),
    cp_tin        TEXT,          -- контрагент СТИРи ёки ЖШШИРи (жисмоний шахс — 0.9.236 қоида истисноси)
    cp_name       TEXT,
    cp_type       TEXT,
    parent_id     BIGINT,
    registered_at TIMESTAMP,
    collected_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, ext_id)
);
