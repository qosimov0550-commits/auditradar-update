-- Хавфсизлик ва касб одоби сиёсати: танишганлик, манфаатлар тўқнашуви (ўзини четлатиш), 11.10.2026
CREATE TABLE IF NOT EXISTS policy_acceptance (
    user_id      BIGINT      NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    version      VARCHAR(16) NOT NULL,
    accepted_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    ip           TEXT,
    PRIMARY KEY (user_id, version)
);

CREATE TABLE IF NOT EXISTS client_recusal (
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    user_id      BIGINT      NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    reason       TEXT        NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, user_id)
);
