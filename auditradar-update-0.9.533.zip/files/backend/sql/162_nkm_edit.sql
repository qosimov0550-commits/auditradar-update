-- 0.9.369 (фойдаланувчи, 08.11.2026): ОНКМ чеклари бошқа ресурсларда таҳрирланади (кассир техник хатолари: товар, миқдор, МХИК;
-- чек рақами, санаси ва суммаси ўзгармайди). Платформа чекни таҳрирламайди — қайта йиғишда эски ва янги таркибни солиштириб,
-- таҳрирланган чекларни кўрсатади (омбор ҳисоботи янги таркиб бўйича).
CREATE TABLE IF NOT EXISTS nkm_recollect (
    taxpayer_id  BIGINT   NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    y            SMALLINT NOT NULL,
    m            SMALLINT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    requested_by BIGINT,
    PRIMARY KEY (taxpayer_id, y, m)
);
-- қайта юкланаётган ойнинг эски таркиби (ой тўлиқ юклангач ўчирилади)
CREATE TABLE IF NOT EXISTS nkm_snap (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    terminal_id TEXT   NOT NULL,
    subtype     TEXT   NOT NULL,
    receipt_no  TEXT   NOT NULL,
    paid_at     TIMESTAMP NOT NULL,
    items       JSONB  NOT NULL,
    PRIMARY KEY (taxpayer_id, terminal_id, subtype, receipt_no, paid_at)
);
CREATE TABLE IF NOT EXISTS nkm_edit (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    terminal_id TEXT   NOT NULL,
    subtype     TEXT   NOT NULL,
    receipt_no  TEXT   NOT NULL,
    paid_at     TIMESTAMP NOT NULL,
    old_items   JSONB  NOT NULL,
    new_items   JSONB  NOT NULL,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_nkm_edit ON nkm_edit(taxpayer_id, paid_at);
-- 0.9.370: my.soliq.uz «Таҳрирланган ва қайтарилган чеклар» (Excel: Eski / Yangi қаторлари) — манба, ҳолат, қўлланганлиги
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS source  TEXT NOT NULL DEFAULT 'RELOAD';    -- RELOAD | MY (my.soliq.uz рўйхати)
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS status  TEXT;                             -- сайтдаги ҳолат (Yangi, Qabul qilingan, …)
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS sent_at TIMESTAMP;
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS accepted_at TIMESTAMP;
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS applied BOOLEAN NOT NULL DEFAULT FALSE;  -- чек таркиби алмаштирилди
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS editor_tin TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS ux_nkm_edit_my ON nkm_edit(taxpayer_id, terminal_id, receipt_no, paid_at) WHERE source='MY';
