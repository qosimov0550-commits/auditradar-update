-- Солиқ қўмитасининг «шубҳали» корхоналар рўйхати (old.soliq.uz «Лозим даражадаги эҳтиёткорлик») ва
-- контрагентнинг солиқ қарзи бўйича қўлда текширувлар (капча сабабли автомат эмас)

CREATE TABLE IF NOT EXISTS risk_company (
    tin           TEXT PRIMARY KEY,
    name          TEXT,
    region        TEXT,
    registered_at DATE,                       -- корхона давлат рўйхатидан ўтган сана (рўйхатга тушган сана эмас)
    founder       TEXT,
    first_seen    DATE NOT NULL DEFAULT CURRENT_DATE,   -- платформа рўйхатда биринчи кўрган кун
    last_seen     DATE NOT NULL DEFAULT CURRENT_DATE,
    removed_at    DATE                        -- рўйхатдан чиққан (охирги юклашда йўқ)
);

CREATE TABLE IF NOT EXISTS risk_import (
    id          SERIAL PRIMARY KEY,
    imported_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    source      TEXT NOT NULL,                -- auto | upload
    ok          BOOLEAN NOT NULL,
    total       INT,
    added       INT,
    removed     INT,
    error       TEXT,
    user_id     INT REFERENCES app_user(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS cp_debt_check (
    id          SERIAL PRIMARY KEY,
    tin         TEXT NOT NULL,
    taxpayer_id INT REFERENCES taxpayer(id) ON DELETE SET NULL,
    has_debt    BOOLEAN NOT NULL,
    amount      NUMERIC(18,2),
    note        TEXT,
    checked_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id     INT REFERENCES app_user(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS cp_debt_check_tin ON cp_debt_check (tin, checked_at DESC);
