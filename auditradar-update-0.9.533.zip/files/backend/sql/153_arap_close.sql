-- 0.9.322: ЭҲФ келмайдиган хизматлар (давлат хизмати, таълим, аъзолик бадали…) бўйича дебитор/кредиторни бухгалтер
-- изоҳ билан ёпади — қолдиқ 0 бўлади. amount > 0 — дебиторлик ёпилди (харид/харажат каби), < 0 — кредиторлик ёпилди.
CREATE TABLE IF NOT EXISTS arap_close (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    cp_tin       TEXT NOT NULL,
    cp_name      TEXT,
    amount       NUMERIC(20,2) NOT NULL,
    close_date   DATE NOT NULL,
    category     TEXT NOT NULL,
    reason       TEXT NOT NULL,
    created_by   INTEGER,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_arap_close ON arap_close(taxpayer_id, cp_tin);
