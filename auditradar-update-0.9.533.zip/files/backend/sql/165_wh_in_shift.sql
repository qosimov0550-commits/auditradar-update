-- 0.9.392: харид кирими даври — бухгалтер ҳисоботи якуний (фойдаланувчи, 09.11.2026).
-- ЭҲФ товар жўнатилгандан кейин 10 кун ичида ёзилиши мумкин: ой охиридаги (ёки кейинги ой бошидаги) харид ЭҲФи товар келган ойдан
-- бошқа ойга тушади. Бухгалтер омбор ҳисоботидаги ой кирими билан сумма бўйича аниқ мос келган ЭҲФ қаторлари
-- бухгалтер ойига кўчирилади: омбор FIFO, «Товарлар ҳаракати» ва 2910 проводкаси шу санада.
CREATE TABLE IF NOT EXISTS wh_in_shift (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    esf_item_id  BIGINT NOT NULL,
    esf_id       BIGINT,
    ikpu_code    TEXT,
    orig_date    DATE   NOT NULL,
    eff_date     DATE   NOT NULL,
    amount       NUMERIC(22,2),
    reason       TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, esf_item_id)
);
-- «HAYOT BIRJA» — лотин «Xayot», чизиқча ва қўшиб ёзилиши
UPDATE intermediary SET name_re = 'h[aа]yot[\s\-"«»]*birj|x[aа]yot[\s\-"«»]*birj|ҳаёт[\s\-"«»]*бирж|хаёт[\s\-"«»]*бирж|hayotbirja'
 WHERE tin = '306712636';
