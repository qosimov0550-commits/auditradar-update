-- Платформанинг умумий созламалари (калит → қиймат). Биринчиси: Chrome Web Store'даги кенгайтма ID'си (10.10.2026).
CREATE TABLE IF NOT EXISTS app_setting (
    key        TEXT PRIMARY KEY,
    value      TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
