-- Иш ҳақи: ЖШДС ва ижтимоий солиқ ҳисоб-китоби (пакет 111xx) ва унинг иловасидаги ходимлар жадвали.
CREATE TABLE IF NOT EXISTS payroll_report (
    id             BIGSERIAL PRIMARY KEY,
    taxpayer_id    BIGINT   NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    y              SMALLINT NOT NULL,
    m              SMALLINT NOT NULL,            -- ҳисобот даври охирги ойи
    report_no      TEXT,
    package        TEXT,
    file_names     TEXT,
    income_ytd     NUMERIC(20,2),               -- 011-сатр: меҳнатга ҳақ тўлаш даромадлари, йил бошидан
    income_period  NUMERIC(20,2),               -- 0110-сатр: шундан ҳисобот даврида
    other_ytd      NUMERIC(20,2),               -- 012-сатр: меҳнатга ҳақ тўлаш билан боғлиқ бўлмаган даромадлар
    soc_ytd        NUMERIC(20,2),               -- 060-сатр: ҳисобланган ижтимоий солиқ
    pit_ytd        NUMERIC(20,2),               -- 060-сатр: ҳисобланган ЖШДС
    inps_ytd       NUMERIC(20,2),               -- 060-сатр: ШЖБПҲ (ИНПС) бадаллари
    soc_rate       NUMERIC(8,3),
    pit_rate       NUMERIC(8,3),
    avg_staff      NUMERIC(12,2),
    rows_wage      INTEGER  NOT NULL DEFAULT 0,
    rows_other     INTEGER  NOT NULL DEFAULT 0,
    has_rows       BOOLEAN  NOT NULL DEFAULT FALSE,   -- илова (ходимлар жадвали) ўқилганми
    imported_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, y, m)
);

CREATE TABLE IF NOT EXISTS payroll_row (
    id             BIGSERIAL PRIMARY KEY,
    report_id      BIGINT   NOT NULL REFERENCES payroll_report(id) ON DELETE CASCADE,
    taxpayer_id    BIGINT   NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    y              SMALLINT NOT NULL,
    m              SMALLINT NOT NULL,
    kind           TEXT     NOT NULL,           -- WAGE (меҳнатга ҳақ тўлаш) | OTHER (мулкий, ижара, моддий наф ва ҳ.к.)
    row_no         INTEGER,
    fio            TEXT,
    position       TEXT,
    pinfl          TEXT,
    inn            TEXT,
    resident       SMALLINT,                    -- 1 резидент, 2 норезидент
    status         SMALLINT,                    -- 1 ишлаб келмоқда, 2 шартнома бекор бўлган ...
    contract       SMALLINT,                    -- 1 асосий, 2 ўриндош, 3 фуқаролик-ҳуқуқий ...
    rate           NUMERIC(6,3),                -- иш вақти (ставка)
    job_date       TEXT,
    income_type    SMALLINT,                    -- OTHER учун: 1 мулкий, 2 ижара, 3 моддий наф ...
    income_ytd     NUMERIC(20,2) NOT NULL DEFAULT 0,
    income_period  NUMERIC(20,2) NOT NULL DEFAULT 0,
    tax_ytd        NUMERIC(20,2) NOT NULL DEFAULT 0,
    tax_period     NUMERIC(20,2) NOT NULL DEFAULT 0,
    exempt_ytd     NUMERIC(20,2) NOT NULL DEFAULT 0,
    exempt_period  NUMERIC(20,2) NOT NULL DEFAULT 0,
    inps_period    NUMERIC(20,2),
    official_name  TEXT,                        -- солиқ органи базасидаги Ф.И.Ш.
    similarity     NUMERIC(6,2)
);
CREATE INDEX IF NOT EXISTS ix_payroll_row ON payroll_row(taxpayer_id, y, m);
CREATE INDEX IF NOT EXISTS ix_payroll_row_pinfl ON payroll_row(taxpayer_id, pinfl);
