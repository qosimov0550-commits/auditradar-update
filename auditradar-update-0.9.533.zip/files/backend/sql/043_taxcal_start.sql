-- Тақвим жорий қилинган сана: ундан олдинги муддатлар бўйича қўлда белгиланмаган ҳисоботлар «муддати ўтган» деб кўрсатилмайди
INSERT INTO app_setting(key, value) VALUES ('taxcal_start', CURRENT_DATE::text) ON CONFLICT (key) DO NOTHING;
