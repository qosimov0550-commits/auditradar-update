-- Акт-сверкадаги сальдолар (dep.customs.uz/qarzdor): ҳар ҳудуд (божхона бошқармаси) бўйича корхона маблағи қолдиғи.
-- kind: O — давр бошидаги сальдо (шу кун ҳаракатларидан олдин), C — давр охиридаги сальдо. Мусбат — корхона фойдасига.
CREATE TABLE ft_customs_act_balance (
    id             BIGSERIAL PRIMARY KEY,
    taxpayer_id    BIGINT        NOT NULL REFERENCES taxpayer(id),
    region         TEXT          NOT NULL,
    as_of          DATE          NOT NULL,
    kind           CHAR(1)       NOT NULL CHECK (kind IN ('O', 'C')),
    balance        NUMERIC(20,2) NOT NULL,
    data_import_id BIGINT        REFERENCES data_import(id),
    updated_at     TIMESTAMPTZ   NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, region, as_of, kind)
);

-- Аввал юкланган актлар: сальдо импорт изоҳида сақланган («бош сальдо 01.01.2026: 123.45; охирги сальдо ...»)
INSERT INTO ft_customs_act_balance(taxpayer_id, region, as_of, kind, balance, data_import_id)
SELECT i.taxpayer_id, r.region, to_date(m.v[1], 'DD.MM.YYYY'), 'O', m.v[2]::numeric, i.id
FROM data_import i
JOIN LATERAL (SELECT MIN(region) AS region FROM ft_customs_act_row a WHERE a.data_import_id = i.id) r ON r.region IS NOT NULL
JOIN LATERAL (SELECT regexp_match(i.note, 'бош сальдо (\d{2}\.\d{2}\.\d{4}): (-?[0-9]+\.?[0-9]*)') AS v) m ON m.v IS NOT NULL
WHERE i.source = 'CUSTOMS_ACT'
ON CONFLICT DO NOTHING;

INSERT INTO ft_customs_act_balance(taxpayer_id, region, as_of, kind, balance, data_import_id)
SELECT i.taxpayer_id, r.region, to_date(m.v[1], 'DD.MM.YYYY'), 'C', m.v[2]::numeric, i.id
FROM data_import i
JOIN LATERAL (SELECT MIN(region) AS region FROM ft_customs_act_row a WHERE a.data_import_id = i.id) r ON r.region IS NOT NULL
JOIN LATERAL (SELECT regexp_match(i.note, 'охирги сальдо (\d{2}\.\d{2}\.\d{4}): (-?[0-9]+\.?[0-9]*)') AS v) m ON m.v IS NOT NULL
WHERE i.source = 'CUSTOMS_ACT'
ON CONFLICT DO NOTHING;
