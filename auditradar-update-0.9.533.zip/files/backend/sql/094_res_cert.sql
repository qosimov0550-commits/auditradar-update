-- 0.9.133: норезидентларнинг резидентлик сертификатлари (халқаро солиқ битими бўйича озод қилиш / камайтирилган ставка асоси).
-- Аудитор ҳар бир хорижий ҳамкор ва йил бўйича сертификатни (рақами, берилган санаси, нусхаси) тасдиқлайди.
CREATE TABLE IF NOT EXISTS ft_res_cert (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    partner_key   TEXT   NOT NULL,
    partner_name  TEXT   NOT NULL,
    year          INT    NOT NULL,
    cert_no       TEXT,
    issue_date    DATE,
    note          TEXT,
    file_name     TEXT,
    file_path     TEXT,
    user_id       BIGINT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, partner_key, year)
);
