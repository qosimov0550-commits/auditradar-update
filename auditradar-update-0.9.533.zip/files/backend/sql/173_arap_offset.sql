-- 0.9.431: уч томонлама шартнома (қарзни ўтказиш / учинчи шахс орқали тўлов / цессия) — бир контрагент қолдиғи
-- (amount: дебитор > 0, кредитор < 0) иккинчисига ўтади: from_tin қолдиғи −amount, to_tin қолдиғи +amount.
CREATE TABLE IF NOT EXISTS arap_offset (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    doc_no       TEXT   NOT NULL,
    doc_date     DATE   NOT NULL,
    from_tin     TEXT   NOT NULL,
    from_name    TEXT,
    to_tin       TEXT   NOT NULL,
    to_name      TEXT,
    amount       NUMERIC(20,2) NOT NULL,
    note         TEXT,
    user_id      BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (from_tin <> to_tin)
);
CREATE INDEX IF NOT EXISTS ix_arap_offset ON arap_offset(taxpayer_id, doc_date);
