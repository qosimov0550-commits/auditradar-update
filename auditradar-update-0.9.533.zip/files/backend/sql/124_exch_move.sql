-- 0.9.246: биржа кўчирмаси — тўлов мақсади коди 00642 («Переброска денежных средств») ҳисобварақлар ўртасидаги ички ўтказма,
-- банкдан келган/кетган пул эмас (аввал DEPOSIT/WITHDRAW деб ёзилган эди)
UPDATE exchange_txn SET kind='MOVE' WHERE platform_tin='200933985' AND kind IN ('DEPOSIT','WITHDRAW')
   AND (details ~ '^\s*00642' OR details ~* 'переброск');
