-- 0.9.317: солиштирма далолатнома → new.soliqservis.uz «Сақланганлар» (қоралама, status template; имзоланмайди)
CREATE TABLE IF NOT EXISTS soliq_act (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    partner_tin  TEXT NOT NULL,
    partner_name TEXT,
    df           DATE NOT NULL,
    dt           DATE NOT NULL,
    act_no       TEXT,
    close_amount NUMERIC(20,2),
    payload      JSONB NOT NULL,
    state        TEXT NOT NULL DEFAULT 'QUEUED',   -- QUEUED | SAVED | ERROR
    soliq_id     TEXT,
    error        TEXT,
    created_by   INTEGER,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_soliq_act ON soliq_act(taxpayer_id, partner_tin);
