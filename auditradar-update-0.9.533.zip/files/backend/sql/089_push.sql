-- 0.9.114: телефонга push-хабарнома (Web Push, VAPID). Хабарда матн юборилмайди (тўлиқ бўш push) — Google/Apple серверлари
-- орқали ҳеч қандай мижоз маълумоти ўтмайди; телефон push олгач хабар матнини ўзи серверимиздан (Tailscale орқали) олади.
CREATE TABLE IF NOT EXISTS push_sub (
    id          BIGSERIAL PRIMARY KEY,
    user_id     BIGINT      NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    endpoint    TEXT        NOT NULL UNIQUE,
    label       TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_ok_at  TIMESTAMPTZ,
    last_err    TEXT,
    fails       INT         NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS push_sub_user ON push_sub(user_id);
-- фойдаланувчига охирги кўрсатилган (push орқали) билдиришнома
CREATE TABLE IF NOT EXISTS push_state (
    user_id     BIGINT PRIMARY KEY REFERENCES app_user(id) ON DELETE CASCADE,
    last_id     BIGINT NOT NULL DEFAULT 0
);
