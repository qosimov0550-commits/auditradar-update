-- 0.9.274: иш ҳақи — фойда солиғида чегирилмайдиган бўлиши мумкин бўлган ходимларга тўловлар бўйича бухгалтер/аудитор қарори
CREATE TABLE IF NOT EXISTS wage_nd_mark (
    taxpayer_id INT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    txn_key     TEXT NOT NULL,
    verdict     TEXT NOT NULL CHECK (verdict IN ('ND', 'D')),
    note        TEXT,
    user_id     INT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, txn_key)
);
