-- акциз ҳисоботида ҳажм 6 хонагача (тонна: 15.408300)
ALTER TABLE excise_row ALTER COLUMN realization TYPE NUMERIC(18,6), ALTER COLUMN own_use TYPE NUMERIC(18,6),
    ALTER COLUMN other TYPE NUMERIC(18,6), ALTER COLUMN base TYPE NUMERIC(18,6);
