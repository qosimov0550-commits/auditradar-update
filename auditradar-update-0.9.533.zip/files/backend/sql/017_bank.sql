-- Банк кўчирмалари: юкланган файллар, ўтказмалар (автомат «таҳлил» таснифи билан) ва текширув хулосаси.
CREATE TABLE IF NOT EXISTS bank_file (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    file_name    TEXT        NOT NULL,
    path         TEXT        NOT NULL,
    sha256       TEXT        NOT NULL,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id      BIGINT,
    bank         TEXT,
    date_from    DATE,
    date_to      DATE,
    row_count    INTEGER     NOT NULL DEFAULT 0,
    status       TEXT        NOT NULL DEFAULT 'OK',     -- OK | FOREIGN (бошқа корхона кўчирмаси) | ERROR
    note         TEXT,
    UNIQUE (taxpayer_id, sha256)
);

CREATE TABLE IF NOT EXISTS bank_txn (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    op_date      DATE        NOT NULL,
    account      TEXT        NOT NULL,          -- ўз ҳисоб рақами
    currency     TEXT        NOT NULL DEFAULT 'UZS',
    doc_no       TEXT,
    debit        NUMERIC(20,2) NOT NULL DEFAULT 0,   -- чиқим
    credit       NUMERIC(20,2) NOT NULL DEFAULT 0,   -- кирим
    k_name       TEXT,
    k_tin        TEXT,
    k_mfo        TEXT,
    k_account    TEXT,
    purpose      TEXT,
    category     TEXT        NOT NULL,          -- «таҳлил»
    reason       TEXT,                          -- тасниф асоси
    t_name       TEXT,                          -- таҳлил учун контрагент (ғазна орқали тўловда — асл олувчи)
    t_tin        TEXT,
    trade_date   DATE,
    file_name    TEXT
);
CREATE INDEX IF NOT EXISTS ix_bank_txn_tp ON bank_txn(taxpayer_id, op_date);
CREATE INDEX IF NOT EXISTS ix_bank_txn_cat ON bank_txn(taxpayer_id, category);

CREATE TABLE IF NOT EXISTS bank_summary (
    taxpayer_id  BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    data         JSONB       NOT NULL,
    built_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
