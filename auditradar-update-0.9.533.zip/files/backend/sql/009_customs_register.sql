-- Аудиторнинг БЮД реестри (қўлда, БЮД асл нусхаларидан): товар кесими, божхона тўловлари.
-- ft_declaration_goods кенгайтирилади; расмийлаштирилган БЮДлар рўйхати иккала манбадан (E-CONTRACT операциялари
-- ва товар реестри) бирлаштирилади.

ALTER TABLE data_import DROP CONSTRAINT IF EXISTS data_import_source_check;
ALTER TABLE data_import ADD CONSTRAINT data_import_source_check CHECK (source IN (
    'MY3_VAT_SUBMITTED', 'MY3_VAT_GENERATED', 'ESF_SOLIQSERVIS', 'ESF_FAKTURA', 'ESF_OTHER', 'MY3_KKM',
    'ECONTRACT_CONTRACTS', 'ECONTRACT_OPERATIONS', 'ECONTRACT_GOODS', 'CUSTOMS_REGISTER'));

ALTER TABLE ft_declaration_goods
    ADD COLUMN source          VARCHAR(20) NOT NULL DEFAULT 'ECONTRACT',   -- ECONTRACT | AUDITOR
    ADD COLUMN contract_no     TEXT,
    ADD COLUMN contract_date   DATE,
    ADD COLUMN partner_name    TEXT,
    ADD COLUMN delivery_terms  TEXT,            -- 20-графа
    ADD COLUMN deal_nature     TEXT,            -- 24-графа (битим хусусияти)
    ADD COLUMN tax_year        INTEGER,
    ADD COLUMN tax_month       INTEGER,
    ADD COLUMN price           NUMERIC(20,4),   -- бирлик нархи (валютада)
    ADD COLUMN stat_value      NUMERIC(20,2),   -- статистик қиймат (минг $)
    ADD COLUMN rate_usd        NUMERIC(20,4),   -- 13-графа
    ADD COLUMN invoice_value_uzs NUMERIC(20,2),
    ADD COLUMN fee_uzs         NUMERIC(20,2),   -- божхона йиғими (10)
    ADD COLUMN other_uzs       NUMERIC(20,2),   -- бошқа тўлов (12)
    ADD COLUMN total_payments_uzs NUMERIC(20,2),
    ADD COLUMN reg_net         NUMERIC(20,2),   -- аудитор реестрида: етказиб бериш қиймати (ҚҚСсиз)
    ADD COLUMN reg_vat         NUMERIC(20,2);   -- аудитор реестрида: ҚҚС суммаси

-- Битта БЮД — битта қатор (товар қаторлари жамланади)
CREATE VIEW v_ft_goods_declaration AS
SELECT taxpayer_id, kind, MAX(regime) AS regime, decl_post, decl_no, decl_date,
       MAX(decl_full_no) AS decl_full_no, string_agg(DISTINCT idn, ', ') AS idn, MAX(partner_name) AS partner_name,
       MAX(currency) AS currency, SUM(invoice_value) AS invoice_value, SUM(customs_value) AS customs_value,
       SUM(invoice_value_uzs) AS invoice_value_uzs, SUM(customs_value_uzs) AS customs_value_uzs,
       SUM(duty_uzs) AS duty_uzs, SUM(excise_uzs) AS excise_uzs, SUM(vat_uzs) AS vat_uzs, SUM(fee_uzs) AS fee_uzs,
       SUM(net_kg) AS net_kg, COUNT(*) AS n_lines, MAX(source) AS source,
       MAX(reg_vat) AS reg_vat, MAX(reg_net) AS reg_net
FROM ft_declaration_goods
WHERE decl_no IS NOT NULL AND decl_date IS NOT NULL
GROUP BY taxpayer_id, kind, decl_post, decl_no, decl_date;

-- Барча манбалардан расмийлаштирилган БЮДлар (солиштириш учун)
CREATE VIEW v_ft_declaration_all AS
SELECT taxpayer_id, kind, regime, decl_post, decl_no, decl_date, sys_no, idn, partner_name, currency1, amount1,
       reissued, 'ECONTRACT' AS source
FROM v_ft_declaration
UNION ALL
SELECT g.taxpayer_id, g.kind, g.regime, g.decl_post, g.decl_no, g.decl_date, g.decl_full_no, g.idn, g.partner_name,
       g.currency, g.invoice_value, FALSE, g.source
FROM v_ft_goods_declaration g
-- E-CONTRACT да шу рақамли БЮД (шу йилда) бўлса, реестрдаги (қўлда ёзилган) сана эмас, E-CONTRACT санаси олинади
WHERE NOT EXISTS (SELECT 1 FROM v_ft_declaration d WHERE d.taxpayer_id = g.taxpayer_id AND d.kind = g.kind
                    AND d.decl_no = g.decl_no
                    AND EXTRACT(YEAR FROM d.decl_date) = EXTRACT(YEAR FROM g.decl_date));
