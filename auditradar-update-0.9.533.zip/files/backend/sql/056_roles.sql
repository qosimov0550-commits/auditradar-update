-- роллар (диссертация 3.32-жадвал): масъул бухгалтер (accountant), текширувчи (checker), раҳбар (head), мижоз вакили (client_rep)
ALTER TABLE app_user DROP CONSTRAINT IF EXISTS app_user_role_check;
ALTER TABLE app_user ADD CONSTRAINT app_user_role_check CHECK (role IN ('admin','auditor','accountant','checker','head','client_rep'));
