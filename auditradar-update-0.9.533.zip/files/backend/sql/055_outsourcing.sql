-- Диссертация III боб (2026 йил октябрь таҳрири) таклифлари: мижоз картаси (3.31), функциялар тақсимоти (3.1–3.5),
-- реестр статуслари (3.9) ва автомат камчиликлар, тармоқ бандлари (3.11), 2410 таннарх (3.38–3.39), роллар (3.32).

CREATE TABLE IF NOT EXISTS client_card (
    taxpayer_id     BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    industry        TEXT,                    -- production | trade | construction | transport | catering | service
    policy_date     DATE,                    -- ҳисоб сиёсати тасдиқланган сана
    policy_methods  TEXT,                    -- асосий усуллар (ТМЗ баҳолаш, амортизация …)
    policy_outsrc   BOOLEAN NOT NULL DEFAULT FALSE,   -- ҳисоб сиёсатида «аутсорсинг асосида юритиш» бўлими бор
    chart_version   TEXT,                    -- ишчи ҳисобварақлар режаси версияси
    analytic_dims   TEXT,                    -- асосий аналитик кесимлар
    contract_no     TEXT,
    contract_date   DATE,
    fee_monthly     NUMERIC(18,2),           -- ойлик хизмат ҳақи (ҚҚСсиз)
    docs_due_day    INTEGER NOT NULL DEFAULT 5,    -- буюртмачи ҳужжатларни кейинги ойнинг шу кунигача топширади
    post_days       INTEGER NOT NULL DEFAULT 5,    -- аутсорсер келган ҳужжатни шунча кунда ҳисобга олади
    close_due_day   INTEGER NOT NULL DEFAULT 15,   -- давр кейинги ойнинг шу кунигача ёпилади
    client_rep      TEXT,                    -- буюртмачи вакили
    accountant_id   BIGINT REFERENCES app_user(id),
    checker_id      BIGINT REFERENCES app_user(id),
    open_issues     TEXT,
    updated_by      BIGINT,
    updated_at      TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS func_template (
    id              SERIAL PRIMARY KEY,
    cycle           TEXT NOT NULL,           -- жараён / цикл
    stage           TEXT NOT NULL DEFAULT '',
    client_task     TEXT NOT NULL,
    outsourcer_task TEXT NOT NULL,
    control         TEXT NOT NULL,
    industry        TEXT,                    -- NULL — умумий ядро; акс ҳолда тармоқ банди (3.2-жадвал)
    source          TEXT,                    -- диссертациядаги жадвал
    sort            INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_func_template ON func_template(cycle, stage, COALESCE(industry, ''));

CREATE TABLE IF NOT EXISTS client_func (
    taxpayer_id     BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    template_id     INTEGER NOT NULL REFERENCES func_template(id) ON DELETE CASCADE,
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    client_task     TEXT,
    outsourcer_task TEXT,
    control         TEXT,
    note            TEXT,
    updated_by      BIGINT,
    updated_at      TIMESTAMPTZ,
    PRIMARY KEY (taxpayer_id, template_id)
);

ALTER TABLE doc_defect ADD COLUMN IF NOT EXISTS auto BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE doc_register ADD COLUMN IF NOT EXISTS ref_key TEXT;      -- BANK: ҳисоб рақами; ECONTRACT: шартнома id
CREATE UNIQUE INDEX IF NOT EXISTS ux_doc_register_ref ON doc_register(taxpayer_id, period, source, ref_key) WHERE ref_key IS NOT NULL;
ALTER TABLE close_period ADD COLUMN IF NOT EXISTS corrections INTEGER;  -- тузатувчи ёзувлар сони (1С журналидан)
ALTER TABLE close_period ADD COLUMN IF NOT EXISTS entries INTEGER;      -- жами ёзувлар сони (1С журналидан)

-- 2410: ойлик билвосита харажатлар (2510) ва мижоз бўйича тўғри харажатлар
CREATE TABLE IF NOT EXISTS cost_pool (
    period          DATE PRIMARY KEY,
    indirect_total  NUMERIC(18,2) NOT NULL DEFAULT 0,
    margin_r        NUMERIC(6,4) NOT NULL DEFAULT 0.2,
    note            TEXT,
    updated_by      BIGINT,
    updated_at      TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS client_cost (
    period          DATE NOT NULL,
    taxpayer_id     BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    direct          NUMERIC(18,2),          -- масъул бухгалтер иш ҳақи + ижтимоий солиқ, мижозга тегишли хизматлар
    hours           NUMERIC(8,2),           -- норматив соат (муқобил база)
    revenue         NUMERIC(18,2),          -- бу ойда тан олинган даромад (бўш — картадаги ойлик ҳақ)
    PRIMARY KEY (period, taxpayer_id)
);

-- роллар (3.32): масъул бухгалтер, текширувчи, раҳбар, мижоз вакили
CREATE TABLE IF NOT EXISTS user_client (
    user_id         BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    taxpayer_id     BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, taxpayer_id)
);

INSERT INTO func_template(cycle, stage, client_task, outsourcer_task, control, industry, source, sort) VALUES
 ('Бирламчи ҳужжатлар', '', 'Ҳужжатни шакллантириш ва ўз вақтида тақдим этиш', 'Реквизитлар тўлиқлигини текшириш', 'Икки томон', NULL, '3.1', 10),
 ('Харид операциялари', '', 'Шартнома ва тасдиқловчи ҳужжатларни тақдим этиш', 'Ҳисобварақларда акс эттириш', 'Аутсорсер', NULL, '3.1', 20),
 ('Сотув операциялари', '', 'Реализация маълумотларини тақдим этиш', 'Даромад ва қарздорликни ҳисобга олиш', 'Аутсорсер', NULL, '3.1', 30),
 ('Банк операциялари', '', 'Тўловни тасдиқлаш', 'Банк кўчирмаси асосида ҳисобга олиш', 'Икки томон', NULL, '3.1', 40),
 ('Иш ҳақи', '', 'Табель ва ходимлар маълумотлари', 'Ҳисоб-китоб ва ажратмаларни ҳисоблаш', 'Икки томон', NULL, '3.1', 50),
 ('ТМЗ', '', 'Кирим-чиқим ҳужжатлари, инвентаризация', 'Синтетик ва аналитик ҳисобни юритиш', 'Икки томон', NULL, '3.1', 60),
 ('Асосий воситалар', '', 'Қабул қилиш/чиқариш ҳужжатлари', 'Амортизация ва регистрлар', 'Аутсорсер', NULL, '3.1', 70),
 ('Солиқлар', '', 'Бирламчи маълумотларни тақдим этиш', 'Ҳисоб-китоб ва декларация тайёрлаш', 'Икки томон', NULL, '3.1', 80),
 ('Молиявий ҳисобот', '', 'Кўриб чиқиш ва тасдиқлаш', 'Ҳисоботни шакллантириш', 'Икки томон', NULL, '3.1', 90),
 ('Харид ва кредиторлик', 'Шартнома', 'Шартномани тузади ва тақдим этади', 'Ҳисоб учун зарур реквизитларни кўриб чиқади', 'Контрагент ва шартнома идентификация қилинган', NULL, '3.3', 110),
 ('Харид ва кредиторлик', 'Товар/хизмат қабул қилиш', 'Қабул қилишни тасдиқлайди', 'Бирламчи ҳужжатни текширади', 'Ҳужжат ҳисобга олишга тайёр', NULL, '3.3', 111),
 ('Харид ва кредиторлик', 'Ҳисобда акс эттириш', 'Қўшимча изоҳ беради', 'Проводка ва аналитик ҳисобни шакллантиради', 'Кредиторлик қарздорлиги қайд этилган', NULL, '3.3', 112),
 ('Харид ва кредиторлик', 'Тўлов', 'Тўловни тасдиқлайди', 'Банк операциясини ҳисобда акс эттиради', 'Қарздорлик камайиши акс этган', NULL, '3.3', 113),
 ('Харид ва кредиторлик', 'Ой якуни', 'Зарур тасдиқларни беради', 'Кредиторликни таҳлил ва солиштиради', 'Очиқ қарздорлик рўйхати шаклланган', NULL, '3.3', 114),
 ('Сотув ва дебиторлик', 'Буюртма/шартнома', 'Нарх ва шартларни тасдиқлайди', 'Ҳисоб учун зарур маълумотларни қабул қилади', 'Шартнома мавжуд', NULL, '3.4', 120),
 ('Сотув ва дебиторлик', 'Реализация', 'Товар/хизмат топширилганини тасдиқлайди', 'Даромад ва дебиторликни ҳисобга олади', 'Реализация ҳужжати мавжуд', NULL, '3.4', 121),
 ('Сотув ва дебиторлик', 'Тўлов тушуми', 'Тушум ҳақида қўшимча маълумот беради', 'Банк тушумини қарздорлик билан ёпади', 'Очиқ дебиторлик янгиланган', NULL, '3.4', 122),
 ('Сотув ва дебиторлик', 'Қайтариш/тузатиш', 'Операцияни тасдиқлайди', 'Тузатиш ёзувини киритади', 'Асословчи ҳужжат мавжуд', NULL, '3.4', 123),
 ('Сотув ва дебиторлик', 'Ой якуни', 'Баҳсли қарздорлик бўйича изоҳ беради', 'Дебиторликни ёш бўйича таҳлил қилади', 'Солиштириш рўйхати тайёр', NULL, '3.4', 124),
 ('Иш ҳақи цикли', 'Ходим таркиби', 'Ишга қабул/бўшатиш буйруғи', 'Ходим карточкасини янгилаш', 'Буйруқ ва сана мослиги', NULL, '3.5', 130),
 ('Иш ҳақи цикли', 'Иш вақти', 'Тасдиқланган табель', 'Иш ҳақи ҳисоблаш', 'Табель тўлиқ', NULL, '3.5', 131),
 ('Иш ҳақи цикли', 'Таътил/касаллик', 'Асословчи ҳужжат', 'Тегишли ҳисоб-китоб', 'Давр ва сумма текширилди', NULL, '3.5', 132),
 ('Иш ҳақи цикли', 'Устама/мукофот', 'Раҳбар қарори', 'Ҳисоб-китобга киритиш', 'Ваколатли тасдиқ мавжуд', NULL, '3.5', 133),
 ('Иш ҳақи цикли', 'Ой якуни', 'Якуний тасдиқ', 'Ведомость ва мажбуриятларни шакллантириш', 'Жами сумма қайта текширилди', NULL, '3.5', 134),
 ('Тармоқ: ишлаб чиқариш', '', 'Материаллар сарфи ва тайёр маҳсулот ҳужжатлари', 'Ишлаб чиқариш харажатлари, тайёр маҳсулот ва таннарх ҳисоби', 'Омбор маълумотлари ва ҳисоб регистрлари мувофиқлиги', 'production', '3.2', 200),
 ('Тармоқ: савдо', '', 'Товар кирими-чиқими ҳужжатлари', 'Товар ҳаракати, реализация ва қарздорлик ҳисоби', 'Товар қолдиғи ва реализация маълумотлари', 'trade', '3.2', 210),
 ('Тармоқ: қурилиш', '', 'Бажарилган ишлар далолатномалари, аванс шартлари', 'Бажарилган ишлар, аванслар ва материаллар ҳисоби', 'Шартнома, далолатнома ва ҳисоб ёзувлари', 'construction', '3.2', 220),
 ('Тармоқ: транспорт/такси', '', 'Хизмат тушуми ва ҳайдовчилар маълумотлари', 'Тушум ва ҳайдовчилар билан ҳисоб-китоблар', 'Аналитик ҳисоб ва тушум тўлиқлиги', 'transport', '3.2', 230),
 ('Тармоқ: умумий овқатланиш', '', 'Хомашё ва сарф ҳужжатлари', 'Хомашё, сарф ва тушум ҳисоби', 'Хомашё ҳаракати ва қолдиқлар', 'catering', '3.2', 240)
ON CONFLICT DO NOTHING;
