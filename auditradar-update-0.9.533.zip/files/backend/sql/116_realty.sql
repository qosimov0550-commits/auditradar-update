-- 0.9.234: «Омбор» — кўчмас мулк сотуви (нотариал идора реестри): ЭҲФ, банк тушуми, нарх ва боғлиқ шахслар билан солиштириш.
-- ЖШШИР (14 хона) очиқ сақланмайди — фақат HMAC хэши (buyer_hash); юридик шахс СТИРи (9 хона) очиқ.
CREATE TABLE IF NOT EXISTS realty_file (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    file_name    TEXT,
    rows_n       INTEGER NOT NULL DEFAULT 0,
    uploaded_by  BIGINT,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_realty_file_tp ON realty_file(taxpayer_id);

CREATE TABLE IF NOT EXISTS realty_sale (
    file_id        BIGINT NOT NULL REFERENCES realty_file(id) ON DELETE CASCADE,
    row_no         INTEGER NOT NULL,
    buyer_name     TEXT,
    buyer_hash     TEXT,            -- ЖШШИР хэши
    buyer_tin      TEXT,            -- юридик шахс СТИРи
    kind           TEXT,            -- турар / нотурар
    cadastre       TEXT,
    area           NUMERIC(14,2),
    cadastre_value NUMERIC(20,2),
    price          NUMERIC(20,2),
    address        TEXT,
    contract_date  DATE,
    act_date       DATE,            -- қабул қилиб олиш-топшириш далолатномаси (СК 242-м.), бўлса
    state          TEXT,            -- ACTIVE | CANCELLED
    registry_no    TEXT,
    PRIMARY KEY (file_id, row_no)
);
