-- 0.9.273 (фойдаланувчи 30.10.2026): иш ҳақи бўйича 6710-счёт — давр бошига / охирига қолдиқлар (1С ОСВ ёки жадвал)
-- ва нақд пулда берилган иш ҳақи ведомостлари (Excel). Ходим кесимида ҳисоб-китоб шу маълумотлардан бошланади.
CREATE TABLE IF NOT EXISTS wage_balance (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id INT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind        TEXT NOT NULL CHECK (kind IN ('OPEN', 'CLOSE')),
    as_of       DATE NOT NULL,
    fio         TEXT NOT NULL DEFAULT '',
    pinfl       TEXT,
    debit       NUMERIC(20, 2) NOT NULL DEFAULT 0,
    credit      NUMERIC(20, 2) NOT NULL DEFAULT 0,
    file_name   TEXT,
    user_id     INT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_wage_balance ON wage_balance(taxpayer_id, kind, as_of);

CREATE TABLE IF NOT EXISTS wage_cash (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id INT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    doc_no      TEXT,
    doc_date    DATE NOT NULL,
    fio         TEXT NOT NULL DEFAULT '',
    pinfl       TEXT,
    amount      NUMERIC(20, 2) NOT NULL,
    file_name   TEXT NOT NULL DEFAULT '',
    user_id     INT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_wage_cash ON wage_cash(taxpayer_id, doc_date);
