-- Вазифалар ва ижро назорати (3-босқич)
CREATE TABLE IF NOT EXISTS task (
    id              BIGSERIAL PRIMARY KEY,
    title           TEXT NOT NULL,
    body            TEXT,
    taxpayer_id     BIGINT REFERENCES taxpayer(id) ON DELETE SET NULL,
    created_by      BIGINT REFERENCES app_user(id) ON DELETE SET NULL,     -- NULL — платформа (автоматик)
    assignee_id     BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    due_date        DATE,
    priority        TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal', 'high', 'urgent')),
    status          TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_progress', 'review', 'done', 'returned', 'cancelled')),
    source          TEXT NOT NULL DEFAULT 'manual',                        -- manual | taxcal | letter | finding
    source_ref      TEXT UNIQUE,
    result          TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at      TIMESTAMPTZ,
    submitted_at    TIMESTAMPTZ,
    done_at         TIMESTAMPTZ,
    returns         INTEGER NOT NULL DEFAULT 0,
    remind_on       DATE,                                                  -- эслатма юборилган кун (такрорланмасин)
    overdue_on      DATE
);
CREATE INDEX IF NOT EXISTS ix_task_assignee ON task(assignee_id, status);
CREATE INDEX IF NOT EXISTS ix_task_due ON task(due_date);

CREATE TABLE IF NOT EXISTS task_event (
    id          BIGSERIAL PRIMARY KEY,
    task_id     BIGINT NOT NULL REFERENCES task(id) ON DELETE CASCADE,
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    kind        TEXT NOT NULL,                  -- create | status | comment | assign | due | auto
    text        TEXT,
    st_from     TEXT,
    st_to       TEXT
);
CREATE INDEX IF NOT EXISTS ix_task_event ON task_event(task_id, at);

INSERT INTO app_setting(key, value) VALUES ('tasks.auto_taxcal', '1') ON CONFLICT (key) DO NOTHING;
