-- 0.9.189: аудиторлик текшируви (солиқ хатарлари текшируви) — текширув, аудит дастури процедуралари ва хулосалар
CREATE TABLE IF NOT EXISTS audit_engagement (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind        TEXT        NOT NULL DEFAULT 'TAX_RISK',
    period_from DATE        NOT NULL,
    period_to   DATE        NOT NULL,
    status      TEXT        NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'CLOSED')),
    lead_id     BIGINT,
    materiality NUMERIC(20,2),
    contract_no TEXT,
    contract_date DATE,
    conclusion  TEXT,
    created_by  BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_audit_engagement ON audit_engagement(taxpayer_id, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_proc (
    engagement_id BIGINT NOT NULL REFERENCES audit_engagement(id) ON DELETE CASCADE,
    code        TEXT        NOT NULL,
    status      TEXT        NOT NULL DEFAULT 'TODO' CHECK (status IN ('TODO', 'WIP', 'DONE', 'NA')),
    result      TEXT        CHECK (result IN ('OK', 'ISSUES', 'LIMIT')),
    conclusion  TEXT,
    prepared_by BIGINT,
    prepared_at TIMESTAMPTZ,
    reviewed_by BIGINT,
    reviewed_at TIMESTAMPTZ,
    PRIMARY KEY (engagement_id, code)
);
