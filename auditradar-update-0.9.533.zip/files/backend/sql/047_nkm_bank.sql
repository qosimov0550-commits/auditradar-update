-- ОНКМ ↔ банк солиштирмаси: банк ҳисоб рақами (пластик / нақд топшириладиган) → савдо нуқтаси (касса манзили)
CREATE TABLE IF NOT EXISTS nkm_bank_map (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    bank_key    TEXT   NOT NULL,                       -- ҳисоб рақами (пластик тушумда — 235.. ҳисоби)
    kind        TEXT   NOT NULL CHECK (kind IN ('card', 'cash')),
    point_key   TEXT   NOT NULL,                       -- савдо нуқтаси калити; '' — солиштирмага кирмайди
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, bank_key, kind)
);

-- савдо нуқтаси кассасидаги нақд пул қолдиғи таҳлил даври бошига
CREATE TABLE IF NOT EXISTS nkm_cash_open (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    point_key   TEXT   NOT NULL,
    as_of       DATE   NOT NULL,
    amount      NUMERIC(20,2) NOT NULL DEFAULT 0,
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, point_key, as_of)
);
