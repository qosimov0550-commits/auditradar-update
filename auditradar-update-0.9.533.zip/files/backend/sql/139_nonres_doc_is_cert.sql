-- 0.9.285: ҳужжат резидентлик сертификатими (баъзан бошқа ҳужжат — масалан, баҳолаш ҳисоботи — илова қилинган)
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_is_cert BOOLEAN;
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
