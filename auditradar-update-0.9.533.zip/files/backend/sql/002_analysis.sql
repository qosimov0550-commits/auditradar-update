-- =====================================================================
-- Аудит хатарлари платформаси — таҳлил қатлами
-- 1-қисм: ҚҚС ҳисоботи, қайта шакллантирилган шакл ва ЭҲФлар солиштируви
-- schema_01_qqs_ehf_nkm.sql дан кейин юкланади.
-- =====================================================================

DROP VIEW IF EXISTS v_vat_resubmissions, v_esf_vs_register, v_report_vs_form, v_reg_invoice CASCADE;

-- Ҳужжат рақамини солиштириш учун нормаллаштириш: бўшлиқлар олиб ташланади, катта ҳарфга ўтказилади
-- ("344-Янги Тошкент-Метро  Лот 4" ва "344-Янги Тошкент-Метро Лот 4" бир хил ҳисобланади)
CREATE OR REPLACE FUNCTION norm_doc_no(t TEXT) RETURNS TEXT
    LANGUAGE SQL IMMUTABLE AS $$ SELECT regexp_replace(upper(t), '\s+', '', 'g') $$;

-- ---------------------------------------------------------------------
-- A. Реестр қаторларини фактура калити бўйича йиғиш
--    Калит: контрагент СТИР + фактура рақами + санаси.
--    * бир фактура реестрда бир неча қатор бўлиши мумкин (банк ҳужжатлари ва ҳ.к.);
--    * бир кунда турли контрагентларга бир хил рақамли фактура бўлиши мумкин;
--    * топширилган ҳисоботда СТИР бўш қолган қаторлар шаклдаги ягона мос СТИР билан тўлдирилади.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_reg_invoice AS
WITH base AS (
    SELECT r.taxpayer_id, r.variant, l.register, r.period_year, r.period_month,
           norm_doc_no(l.invoice_no) AS invoice_key, l.invoice_no, l.invoice_date,
           l.counterparty_tin, l.counterparty_name, l.is_kkm,
           l.net_amount, l.vat_amount, l.nondeductible_net, l.nondeductible_vat, l.nondeductible_reason
    FROM vat_register_row l
    JOIN vat_return r ON r.id = l.vat_return_id AND r.is_latest
), fill AS (
    SELECT taxpayer_id, register, period_year, period_month, invoice_key, invoice_date,
           MIN(counterparty_tin) AS tin
    FROM base
    WHERE variant = 'GENERATED' AND counterparty_tin IS NOT NULL
    GROUP BY 1, 2, 3, 4, 5, 6
    HAVING COUNT(DISTINCT counterparty_tin) = 1
)
SELECT
    b.taxpayer_id,
    b.variant,
    b.register,
    b.period_year,
    b.period_month,
    b.invoice_key,
    b.invoice_date,
    COALESCE(b.counterparty_tin, f.tin)       AS counterparty_tin,
    MIN(b.invoice_no)                         AS invoice_no,
    BOOL_OR(b.counterparty_tin IS NULL)       AS tin_missing_in_source,
    MAX(b.counterparty_name)                  AS counterparty_name,
    BOOL_OR(b.is_kkm)                         AS is_kkm,
    COUNT(*)                                  AS row_count,
    SUM(b.net_amount)                         AS net_amount,
    SUM(b.vat_amount)                         AS vat_amount,
    SUM(COALESCE(b.nondeductible_net, 0))     AS nondeductible_net,
    SUM(COALESCE(b.nondeductible_vat, 0))     AS nondeductible_vat,
    MAX(b.nondeductible_reason)               AS nondeductible_reason
FROM base b
LEFT JOIN fill f
       ON f.taxpayer_id = b.taxpayer_id AND f.register = b.register
      AND f.period_year = b.period_year AND f.period_month = b.period_month
      AND f.invoice_key = b.invoice_key AND f.invoice_date = b.invoice_date
GROUP BY 1, 2, 3, 4, 5, 6, 7, 8;

-- ---------------------------------------------------------------------
-- B. Топширилган ҳисобот ва қайта шакллантирилган шакл: фактура даражасида
--    Фақат ҳисоботи топширилган ойлар солиштирилади.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_report_vs_form AS
-- Иккала вариант ҳам мавжуд бўлган ойларгина солиштирилади (шакл ҳали олинмаган ой топилма бермайди).
WITH s AS (SELECT v.* FROM v_reg_invoice v
           WHERE v.variant = 'SUBMITTED'
             AND EXISTS (SELECT 1 FROM vat_return x
                         WHERE x.taxpayer_id = v.taxpayer_id AND x.variant = 'GENERATED'
                           AND x.is_latest AND x.period_year = v.period_year
                           AND x.period_month = v.period_month)),
     g AS (SELECT v.* FROM v_reg_invoice v
           WHERE v.variant = 'GENERATED'
             AND EXISTS (SELECT 1 FROM vat_return x
                         WHERE x.taxpayer_id = v.taxpayer_id AND x.variant = 'SUBMITTED'
                           AND x.is_latest AND x.period_year = v.period_year
                           AND x.period_month = v.period_month))
SELECT
    COALESCE(s.taxpayer_id, g.taxpayer_id)            AS taxpayer_id,
    COALESCE(s.register, g.register)                  AS register,
    COALESCE(s.period_year, g.period_year)            AS period_year,
    COALESCE(s.period_month, g.period_month)          AS period_month,
    COALESCE(g.counterparty_tin, s.counterparty_tin)  AS counterparty_tin,
    COALESCE(g.counterparty_name, s.counterparty_name) AS counterparty_name,
    COALESCE(s.invoice_no, g.invoice_no)              AS invoice_no,
    COALESCE(s.invoice_date, g.invoice_date)          AS invoice_date,
    s.net_amount AS report_net,  g.net_amount AS form_net,
    s.vat_amount AS report_vat,  g.vat_amount AS form_vat,
    s.nondeductible_vat AS report_nd_vat, g.nondeductible_vat AS form_nd_vat,
    s.row_count AS report_rows, g.row_count AS form_rows,
    COALESCE(s.nondeductible_reason, g.nondeductible_reason) AS nondeductible_reason,
    COALESCE(s.vat_amount, 0) - COALESCE(s.nondeductible_vat, 0)
      - (COALESCE(g.vat_amount, 0) - COALESCE(g.nondeductible_vat, 0)) AS deductible_vat_excess,
    CASE
        WHEN g.invoice_key IS NULL THEN 'ONLY_IN_REPORT'     -- ҳисоботда бор, шаклда йўқ
        WHEN s.invoice_key IS NULL THEN 'ONLY_IN_FORM'       -- шаклда бор, ҳисоботда йўқ
        WHEN s.vat_amount <> g.vat_amount THEN 'VAT_DIFF'
        WHEN s.nondeductible_vat <> g.nondeductible_vat THEN 'NONDEDUCTIBLE_DIFF'
        WHEN s.net_amount <> g.net_amount THEN 'NET_DIFF'
        ELSE 'MATCH'
    END AS result
FROM s
FULL JOIN g
  ON  g.taxpayer_id  = s.taxpayer_id
 AND  g.register     = s.register
 AND  g.period_year  = s.period_year
 AND  g.period_month = s.period_month
 AND  g.invoice_key  = s.invoice_key
 AND  g.invoice_date = s.invoice_date
 AND  g.counterparty_tin IS NOT DISTINCT FROM s.counterparty_tin;

-- ---------------------------------------------------------------------
-- C. ЭҲФ ва реестрлар: имзоланган/кутилаётган ЭҲФ ҳисоботда акс этганми
--    Калит: контрагент СТИР + ЭҲФ рақами + санаси (ой фарқ қилиши мумкин)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_esf_vs_register AS
WITH reg AS (
    SELECT taxpayer_id, variant, register, counterparty_tin, invoice_key, invoice_date,
           MIN(period_year * 100 + period_month) AS reg_period,
           SUM(net_amount) AS net_amount, SUM(vat_amount) AS vat_amount
    FROM v_reg_invoice
    GROUP BY 1, 2, 3, 4, 5, 6
)
SELECT
    e.taxpayer_id,
    e.direction,
    e.id                                                  AS esf_id,
    e.external_id,
    c.tin                                                 AS counterparty_tin,
    COALESCE(c.name, '')                                  AS counterparty_name,
    e.esf_no, e.esf_date, e.esf_type, e.status_raw, e.sent_at, e.signed_at, e.operator_host,
    e.total_net, e.total_vat,
    EXTRACT(YEAR FROM e.esf_date) * 100 + EXTRACT(MONTH FROM e.esf_date) AS esf_period,
    rs.reg_period  AS report_period, rs.vat_amount AS report_vat,
    rg.reg_period  AS form_period,   rg.vat_amount AS form_vat
FROM esf e
JOIN counterparty c ON c.id = e.counterparty_id
LEFT JOIN reg rs ON rs.taxpayer_id = e.taxpayer_id AND rs.variant = 'SUBMITTED'
                AND rs.register = CASE e.direction WHEN 'IN' THEN 'PURCHASE' ELSE 'SALE' END
                AND rs.counterparty_tin = COALESCE(c.tin, c.pinfl)
                AND rs.invoice_key = norm_doc_no(e.esf_no) AND rs.invoice_date = e.esf_date
LEFT JOIN reg rg ON rg.taxpayer_id = e.taxpayer_id AND rg.variant = 'GENERATED'
                AND rg.register = CASE e.direction WHEN 'IN' THEN 'PURCHASE' ELSE 'SALE' END
                AND rg.counterparty_tin = COALESCE(c.tin, c.pinfl)
                AND rg.invoice_key = norm_doc_no(e.esf_no) AND rg.invoice_date = e.esf_date;

-- ---------------------------------------------------------------------
-- D. Ҳисоботни қайта топшириш (59 мезоннинг 6- ва 24-бандлари билан боғлиқ)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_vat_resubmissions AS
SELECT taxpayer_id, period_year, period_month, report_no, submissions_count, submitted_at,
       make_date(period_year, period_month, 1) + INTERVAL '1 month' + INTERVAL '19 days'
           AS approx_deadline,                         -- тахминий муддат: кейинги ойнинг 20-куни
       submitted_at::DATE - (make_date(period_year, period_month, 1)
                             + INTERVAL '1 month' + INTERVAL '19 days')::DATE AS last_submit_days_after_deadline
       -- эслатма: файлда фақат охирги топшириш санаси бор, дастлабки топшириш санаси эмас
FROM vat_return
WHERE variant = 'SUBMITTED' AND is_latest;
