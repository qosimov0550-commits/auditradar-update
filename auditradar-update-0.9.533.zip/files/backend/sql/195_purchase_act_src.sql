-- 0.9.527: харид далолатномаси манбаи — PDF (my.soliq ёки бошқа), XLS (товар қаторлари билан Excel), LIST (my.soliq рўйхати
-- «Юклаб олиш» — фақат сарлавҳа, товар қаторларисиз; PDF юкланганда алмаштирилади)
ALTER TABLE ft_purchase_act ADD COLUMN IF NOT EXISTS src VARCHAR(8) NOT NULL DEFAULT 'PDF';
