-- Кўприк: 07.10.2026 гача уй компьютерида алоҳида ривожланган 0.4.0 тармоғи (008_customs.sql, 009_econtract.sql:
-- customs_decl, econtract_op, cbu_rate) базасини асосий тармоққа (ft_* жадваллари) ўтказиш.
-- Асосий тармоқ базасида бу файл ҳеч нарсани ўзгартирмайди.
-- Эски тармоқнинг импорт ёзувлари (source = CUSTOMS / ECONTRACT) кейинги миграциялардаги манбалар рўйхатига кирмайди:
-- улар ўчирилади, эски жадваллардаги маълумот эса сақланиб қолади (ишлатилмайди). E-CONTRACT маълумоти расмий API ёки
-- файл юклаш орқали ft_* жадвалларига қайта олинади.
DO $$
BEGIN
    IF to_regclass('public.customs_decl') IS NOT NULL THEN
        UPDATE customs_decl SET import_id = NULL
        WHERE import_id IN (SELECT id FROM data_import WHERE source IN ('CUSTOMS', 'ECONTRACT'));
    END IF;
    IF to_regclass('public.econtract_op') IS NOT NULL THEN
        UPDATE econtract_op SET import_id = NULL
        WHERE import_id IN (SELECT id FROM data_import WHERE source IN ('CUSTOMS', 'ECONTRACT'));
    END IF;
    DELETE FROM data_import WHERE source IN ('CUSTOMS', 'ECONTRACT');
END $$;
