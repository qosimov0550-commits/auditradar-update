-- =====================================================================
-- Аудит Радар — платформа жадваллари: фойдаланувчилар, амаллар журнали,
-- ҳисоботлар журнали (my3.soliq.uz), топилмалар, изоҳлар ва тарих
-- =====================================================================

CREATE TABLE app_user (
    id              BIGSERIAL PRIMARY KEY,
    login           VARCHAR(64)  NOT NULL UNIQUE,
    full_name       TEXT         NOT NULL,
    password_hash   TEXT         NOT NULL,
    role            VARCHAR(16)  NOT NULL DEFAULT 'auditor' CHECK (role IN ('admin', 'auditor')),
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    last_login_at   TIMESTAMPTZ
);

-- Ҳар бир муҳим амал қайд этилади (ким, қачон, нимани)
CREATE TABLE audit_log (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT       REFERENCES app_user(id),
    action          VARCHAR(64)  NOT NULL,
    object_type     VARCHAR(32),
    object_id       BIGINT,
    details         JSONB        NOT NULL DEFAULT '{}',
    ip              TEXT,
    at              TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX ix_audit_log_at ON audit_log(at DESC);

ALTER TABLE taxpayer ADD COLUMN created_by BIGINT REFERENCES app_user(id);
ALTER TABLE taxpayer ADD COLUMN notes TEXT;
ALTER TABLE data_import ADD COLUMN user_id BIGINT REFERENCES app_user(id);

-- my3.soliq.uz «Ҳисоботлар журнали» дан олинган рўйхат (барча ҳолатлар, барча тузатишлар)
CREATE TABLE vat_journal (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT       NOT NULL REFERENCES taxpayer(id),
    report_no       TEXT         NOT NULL,
    package         TEXT,
    period_year     SMALLINT,
    period_month    SMALLINT,
    period_label    TEXT,
    sent_at         TIMESTAMPTZ,
    status_text     TEXT,
    journal_tab     TEXT,                    -- approved, rejected, sent ...
    imported_at     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, report_no)
);

-- Топилмалар: қоидалар натижаси; fingerprint бир хил топилмани қайта яратмаслик учун
CREATE TABLE finding (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT       NOT NULL REFERENCES taxpayer(id),
    rule_code       VARCHAR(32)  NOT NULL,
    fingerprint     TEXT         NOT NULL,
    severity        VARCHAR(12)  NOT NULL CHECK (severity IN ('HIGH', 'MEDIUM', 'LOW', 'OPPORTUNITY')),
    title           TEXT         NOT NULL,
    description     TEXT,
    recommendation  TEXT,
    criterion       TEXT,                    -- солиқ органи мезони ёки асос
    period_label    TEXT,
    period_key      INTEGER,                 -- йил*100+ой, саралаш учун
    amount          NUMERIC(20,2),
    evidence        JSONB        NOT NULL DEFAULT '[]',
    status          VARCHAR(12)  NOT NULL DEFAULT 'NEW' CHECK (status IN ('NEW', 'REVIEW', 'SENT', 'FIXED', 'DISMISSED')),
    assignee_id     BIGINT       REFERENCES app_user(id),
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,   -- сўнгги текширувда ҳам аниқландими
    detected_at     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, fingerprint)
);
CREATE INDEX ix_finding_taxpayer ON finding(taxpayer_id, is_active, status);

CREATE TABLE finding_comment (
    id              BIGSERIAL PRIMARY KEY,
    finding_id      BIGINT       NOT NULL REFERENCES finding(id) ON DELETE CASCADE,
    user_id         BIGINT       REFERENCES app_user(id),
    text            TEXT         NOT NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE finding_event (
    id              BIGSERIAL PRIMARY KEY,
    finding_id      BIGINT       NOT NULL REFERENCES finding(id) ON DELETE CASCADE,
    user_id         BIGINT       REFERENCES app_user(id),
    event           TEXT         NOT NULL,
    at              TIMESTAMPTZ  NOT NULL DEFAULT now()
);
