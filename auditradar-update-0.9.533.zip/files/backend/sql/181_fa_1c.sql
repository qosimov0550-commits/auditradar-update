-- 0.9.446: асосий воситалар — иккинчи манба: 1С «ОСВ по счету» 01хх ва 02хх (Подразделение / Основные средства кесимида).
ALTER TABLE fa_row ADD COLUMN IF NOT EXISTS source       TEXT NOT NULL DEFAULT 'FORM';   -- FORM (Маълумотнома) | 1C
ALTER TABLE fa_row ADD COLUMN IF NOT EXISTS dept         TEXT;
ALTER TABLE fa_row ADD COLUMN IF NOT EXISTS period_start DATE;
ALTER TABLE fa_row ADD COLUMN IF NOT EXISTS dep_out      NUMERIC(20,2) NOT NULL DEFAULT 0;  -- 02 дебет айланмаси (ҳисобдан чиқарилган эскириш)
