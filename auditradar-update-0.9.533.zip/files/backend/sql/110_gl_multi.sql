-- 0.9.186: кўп тармоқли корхона — фаолият турлари ва асосий фаолият (иш ҳақи ва аниқланмаган харидлар учун)
ALTER TABLE gl_settings ADD COLUMN IF NOT EXISTS activities TEXT[];
ALTER TABLE gl_settings ADD COLUMN IF NOT EXISTS main_activity TEXT;
