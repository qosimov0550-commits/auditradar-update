-- 0.9.473: дебитор-кредитор шартномалар кесимида — операцияни шартномага қўлда боғлаш (бухгалтер қарори).
CREATE TABLE IF NOT EXISTS arap_contract_set (
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    skey          TEXT   NOT NULL CHECK (skey IN ('ESF', 'BANK')),   -- операция манбаи
    sid           BIGINT NOT NULL,                                    -- esf.id ёки bank_txn.id
    cp_tin        TEXT,
    contract_no   TEXT   NOT NULL DEFAULT '',                         -- '' — атайлаб «шартномасиз»
    contract_date DATE,
    user_id       BIGINT,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, skey, sid)
);
