-- 0.9.423: турк резидентлик сертификати («mukimlik belgesi») танилмаган эди — «сертификат эмас» деб ўқилганлари қайта ўқилади
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND ocr_is_cert IS FALSE;
