-- my.soliq.uz «Профиль → Ҳисоб маълумотлари» (мижознинг ўз кабинети, ЭРИ билан) — йиғувчи ўқийди
CREATE TABLE IF NOT EXISTS client_profile (
    taxpayer_id BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    pairs       JSONB NOT NULL DEFAULT '[]'::jsonb,     -- [{label, code, value}]
    url         TEXT,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    fetched_by  BIGINT
);
