-- 0.9.384: ўлчов бирликлари реестри (Маълумотномалар → Ўлчов бирликлари).
-- kind: UNIT — ЭҲФ бирлик коди (esf_item.unit_code); PACKAGE — tasnif қадоқ коди (nkm_item.package_code, ЭҲФ қадоқ);
--       NAME — коди йўқ, фақат номи (бухгалтер ҳисоботи, БЮД, қолдиқлар).
-- base/factor/family — канон: миқдор × factor = base бирликда. manual=TRUE бўлса автомат янгиланмайди.
CREATE TABLE IF NOT EXISTS unit_ref (
    kind        TEXT NOT NULL,
    code        TEXT NOT NULL,
    name        TEXT,
    name_ru     TEXT,
    mxik        TEXT,
    base        TEXT,
    factor      NUMERIC(20,6),
    family      TEXT,
    source      TEXT,                      -- data | tasnif | manual
    manual      BOOLEAN NOT NULL DEFAULT FALSE,
    seen_esf    INTEGER NOT NULL DEFAULT 0,
    seen_nkm    INTEGER NOT NULL DEFAULT 0,
    seen_other  INTEGER NOT NULL DEFAULT 0,
    note        TEXT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (kind, code)
);
CREATE INDEX IF NOT EXISTS ix_unit_ref_mxik ON unit_ref(mxik);
