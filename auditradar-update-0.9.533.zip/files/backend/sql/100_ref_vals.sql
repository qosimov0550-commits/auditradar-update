-- 0.9.151: маълумотномалар (ижара ставкалари, табиий йўқотиш нормалари) — устунли қаторлар (зона, мавсум ва ҳ.к.)
ALTER TABLE res_tax_rate ADD COLUMN IF NOT EXISTS vals JSONB;      -- {"1-зона": 1.5, "2-зона": 1.4, ...} — тартиб сақланади
-- эски уникал калит (гуруҳсиз) бўлса — алмаштирилади
ALTER TABLE res_tax_rate DROP CONSTRAINT IF EXISTS res_tax_rate_tax_payer_item_year_key;
CREATE UNIQUE INDEX IF NOT EXISTS ux_res_tax_rate ON res_tax_rate(tax, payer, (COALESCE(grp, '')), item, year);
-- vals — [[калит, қиймат], …] (JSON объекти калитлар тартибини сақламайди)
DELETE FROM res_tax_rate WHERE vals IS NOT NULL AND jsonb_typeof(vals) = 'object';
