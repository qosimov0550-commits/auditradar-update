-- БЮД нусхалари (PDF, божхона тизимидан): 47-графа — ҳар бир товар бўйича аниқ бож, акциз, йиғим, ҚҚС ва бошқа тўловлар
CREATE TABLE IF NOT EXISTS ft_decl_pdf (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    decl_post    VARCHAR(10) NOT NULL,
    decl_no      INTEGER     NOT NULL,
    decl_date    DATE        NOT NULL,
    regime       TEXT,
    kind         VARCHAR(10),
    currency     VARCHAR(5),
    rate         NUMERIC(20,4),
    items        INTEGER     NOT NULL DEFAULT 0,
    totals       JSONB       NOT NULL DEFAULT '{}'::jsonb,     -- {"10": 937500, "29": 50128869.84}
    mismatch     JSONB,
    file_name    TEXT,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id      BIGINT      REFERENCES app_user(id) ON DELETE SET NULL,
    UNIQUE (taxpayer_id, decl_post, decl_no, decl_date)
);
CREATE TABLE IF NOT EXISTS ft_decl_pdf_item (
    pdf_id         BIGINT  NOT NULL REFERENCES ft_decl_pdf(id) ON DELETE CASCADE,
    item_no        INTEGER NOT NULL,
    hs_code        VARCHAR(12),
    goods_name     TEXT,
    net_kg         NUMERIC(20,3),
    invoice_value  NUMERIC(20,2),
    customs_value  NUMERIC(20,2),
    pays           JSONB   NOT NULL DEFAULT '[]'::jsonb,       -- [{"code":"20","base":..,"rate":"30","amount":..,"sp":"БН"}]
    PRIMARY KEY (pdf_id, item_no)
);
CREATE INDEX IF NOT EXISTS ix_ft_decl_pdf_no ON ft_decl_pdf(taxpayer_id, decl_no, decl_date);
