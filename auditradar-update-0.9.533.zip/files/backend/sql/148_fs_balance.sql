-- 0.9.301: бухгалтерия баланси (1-шакл) сатрлари — 330 «Кассадаги пул маблағлари» ва б. (давр боши / охири, сўмда)
CREATE TABLE IF NOT EXISTS fs_balance_line (
    taxpayer_id    BIGINT       NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    tax_report_id  BIGINT       NOT NULL REFERENCES tax_report(id) ON DELETE CASCADE,
    period_year    SMALLINT     NOT NULL,
    period_no      SMALLINT     NOT NULL DEFAULT 0,
    line_code      VARCHAR(10)  NOT NULL,
    v_begin        NUMERIC(20,2),
    v_end          NUMERIC(20,2),
    PRIMARY KEY (tax_report_id, line_code)
);
CREATE INDEX IF NOT EXISTS ix_fs_balance_tp ON fs_balance_line(taxpayer_id, line_code, period_year);
