-- 0.9.221: корпоратив карта орқали харид чеклари (my.soliq.uz «Юридик шахсларнинг корпоратив карталар орқали амалга оширилган
-- тўлов чекларини рўйхатга олиш», /yur-corporate-api/yur-corporate/get-cheques) — харид реестрига ЭҲФсиз тушади.
CREATE TABLE IF NOT EXISTS corp_cheque (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    seller_tin    TEXT,
    fiscal_sign   TEXT,
    terminal_id   TEXT,
    cheque_no     TEXT,
    cheque_date   DATE,
    net           NUMERIC(20,2),
    vat           NUMERIC(20,2),
    total         NUMERIC(20,2),
    registered_at DATE,
    deleted_at    DATE,
    raw           JSONB NOT NULL DEFAULT '{}',
    loaded_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_corp_cheque ON corp_cheque(taxpayer_id, seller_tin, cheque_no);
