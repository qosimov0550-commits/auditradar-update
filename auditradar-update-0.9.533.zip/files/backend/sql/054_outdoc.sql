-- Чиқувчи ҳужжатлар (ЭҲФ конструктори): қоралама → имзо → Didox орқали жўнатиш
CREATE TABLE IF NOT EXISTS outdoc_seller (
    taxpayer_id   INTEGER PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    account       TEXT NOT NULL DEFAULT '',
    mfo           TEXT NOT NULL DEFAULT '',
    address       TEXT NOT NULL DEFAULT '',
    vat_reg_code  TEXT NOT NULL DEFAULT '',
    director      TEXT NOT NULL DEFAULT '',
    accountant    TEXT NOT NULL DEFAULT '',
    oked          TEXT NOT NULL DEFAULT '',
    next_no       INTEGER NOT NULL DEFAULT 1,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Товар/хизмат справочниги (мижоз бўйича): чиқувчи ЭҲФ тарихидан ўзи тўлади + қўлда
CREATE TABLE IF NOT EXISTS product_ref (
    id            SERIAL PRIMARY KEY,
    taxpayer_id   INTEGER NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    ikpu_code     TEXT NOT NULL DEFAULT '',
    ikpu_name     TEXT NOT NULL DEFAULT '',
    package_code  TEXT NOT NULL DEFAULT '',
    package_name  TEXT NOT NULL DEFAULT '',
    price         NUMERIC(18,4),
    vat_rate      NUMERIC(5,2),
    origin        SMALLINT NOT NULL DEFAULT 1,
    source        TEXT NOT NULL DEFAULT 'manual',   -- manual | esf
    used          INTEGER NOT NULL DEFAULT 0,
    last_used     DATE,
    UNIQUE (taxpayer_id, name, ikpu_code, package_code)
);

CREATE TABLE IF NOT EXISTS outdoc (
    id            SERIAL PRIMARY KEY,
    taxpayer_id   INTEGER NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    doc_type      TEXT NOT NULL DEFAULT '002',      -- Didox: 002 ЭҲФ, 005 далолатнома, 006 ишончнома
    template      TEXT NOT NULL DEFAULT 'GOODS',    -- GOODS | SERVICE | RENT
    status        TEXT NOT NULL DEFAULT 'DRAFT',    -- DRAFT | SIGNED | SENT | ACCEPTED | REJECTED | ERROR
    doc_no        TEXT NOT NULL DEFAULT '',
    doc_date      DATE NOT NULL DEFAULT CURRENT_DATE,
    contract_no   TEXT NOT NULL DEFAULT '',
    contract_date DATE,
    buyer_tin     TEXT NOT NULL DEFAULT '',
    buyer_name    TEXT NOT NULL DEFAULT '',
    buyer_account TEXT NOT NULL DEFAULT '',
    buyer_mfo     TEXT NOT NULL DEFAULT '',
    buyer_address TEXT NOT NULL DEFAULT '',
    buyer_vat_code TEXT NOT NULL DEFAULT '',
    items         JSONB NOT NULL DEFAULT '[]',
    flags         JSONB NOT NULL DEFAULT '{}',
    total_net     NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_vat     NUMERIC(18,2) NOT NULL DEFAULT 0,
    total_with_vat NUMERIC(18,2) NOT NULL DEFAULT 0,
    note          TEXT NOT NULL DEFAULT '',
    payload       JSONB,                            -- роуминг (Didox) JSON — жўнатиш олдидан тузилади
    signature     TEXT,                             -- PKCS7 (фақат имзо; калит/парол сақланмайди)
    didox_id      TEXT,
    sent_at       TIMESTAMPTZ,
    error         TEXT,
    created_by    INTEGER REFERENCES app_user(id),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS outdoc_tp ON outdoc(taxpayer_id, doc_date DESC);
