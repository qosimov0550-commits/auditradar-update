-- 0.9.323: даъво муддати (3 йил) ўтган қарзларни ҳисобдан чиқариш: кредиторлик — даромадга (солиққа тортилади);
-- дебиторлик — умидсиз қарз (харажатга). measures — ундириш чоралари кўрилган (судга даъво, ижро иши) — фойда
-- солиғида харажат сифатида чегириш шарти; кўрилмаган бўлса чегирилмайди.
ALTER TABLE arap_close ADD COLUMN IF NOT EXISTS measures BOOLEAN;
ALTER TABLE arap_close ADD COLUMN IF NOT EXISTS measures_doc TEXT;
