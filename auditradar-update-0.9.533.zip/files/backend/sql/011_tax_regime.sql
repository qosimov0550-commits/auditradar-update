-- Солиқ режими тарихи: ҚҚС ↔ айланмадан олинадиган солиқ. Журнал барча ҳисобот турларини сақлайди,
-- ҚҚСдан бошқа ҳисоботлар (айланма солиғи ва ҳ.к.) умумий tax_report жадвалига тушади.

ALTER TABLE vat_journal ADD COLUMN report_name TEXT;

ALTER TABLE data_import DROP CONSTRAINT IF EXISTS data_import_source_check;
ALTER TABLE data_import ADD CONSTRAINT data_import_source_check CHECK (source IN (
    'MY3_VAT_SUBMITTED', 'MY3_VAT_GENERATED', 'ESF_SOLIQSERVIS', 'ESF_FAKTURA', 'ESF_OTHER', 'MY3_KKM',
    'ECONTRACT_CONTRACTS', 'ECONTRACT_OPERATIONS', 'ECONTRACT_GOODS', 'CUSTOMS_REGISTER', 'ECONTRACT_API',
    'MY3_TAX_REPORT'));

CREATE TABLE tax_report (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    import_id       BIGINT      REFERENCES data_import(id),
    package         TEXT        NOT NULL,           -- масалан 10012_7
    package_code    VARCHAR(10) NOT NULL,           -- 10012
    kind            VARCHAR(10) NOT NULL DEFAULT 'OTHER',  -- AOS (айланмадан солиқ) | OTHER
    report_name     TEXT,
    period_year     SMALLINT    NOT NULL,
    period_kind     CHAR(1)     NOT NULL DEFAULT 'M',   -- M ой, Q чорак, Y йил
    period_no       SMALLINT    NOT NULL DEFAULT 0,     -- ой (1-12), чорак (1-4), йил учун 0
    report_no       TEXT,
    correction_no   SMALLINT    NOT NULL DEFAULT 0,
    submitted_at    TIMESTAMPTZ,
    is_latest       BOOLEAN     NOT NULL DEFAULT TRUE,
    file_name       TEXT,
    UNIQUE (taxpayer_id, package_code, period_year, period_kind, period_no, report_no)
);
CREATE INDEX ix_tax_report_period ON tax_report(taxpayer_id, kind, period_year, period_no);

CREATE TABLE tax_report_line (
    id              BIGSERIAL PRIMARY KEY,
    tax_report_id   BIGINT      NOT NULL REFERENCES tax_report(id) ON DELETE CASCADE,
    appendix        VARCHAR(20) NOT NULL,
    line_code       VARCHAR(20) NOT NULL,
    line_name       TEXT,
    v1              NUMERIC(20,2),
    v2              NUMERIC(20,2),
    extra           JSONB,
    UNIQUE (tax_report_id, appendix, line_code)
);

-- Йиғиш созламалари (нима йиғилсин): {"vat":true,"forms":"missing","aos":true,"esf":true,"kkm":false}
ALTER TABLE taxpayer ADD COLUMN collect_options JSONB NOT NULL DEFAULT '{}'::jsonb;

-- Ой бўйича режим: ҚҚС ҳисоботи топширилган ой — QQS; айланма солиғи ҳисоботи қамраган ой — AOS
CREATE VIEW v_regime_month AS
SELECT taxpayer_id, period_year, period_month, 'QQS' AS regime
FROM vat_return WHERE variant = 'SUBMITTED' AND is_latest
UNION
SELECT t.taxpayer_id, t.period_year, m.m, 'AOS'
FROM tax_report t
CROSS JOIN LATERAL (
    SELECT generate_series(CASE t.period_kind WHEN 'M' THEN t.period_no WHEN 'Q' THEN (t.period_no - 1) * 3 + 1 ELSE 1 END,
                           CASE t.period_kind WHEN 'M' THEN t.period_no WHEN 'Q' THEN t.period_no * 3 ELSE 12 END) AS m
) m
WHERE t.kind = 'AOS' AND t.is_latest;
