-- 0.9.152: диссертация III боби билан мослаштириш —
--   3.3.1 муҳимлик чегараси ва «келишув асосида ёпиш»; 3.5.1 (3.22-жадвал) қабул қилиш ва 3.5.2 (3.23, 3.34) топшириш рўйхатлари.
ALTER TABLE client_card ADD COLUMN IF NOT EXISTS materiality_pct NUMERIC(6,3);   -- объект қолдиғига нисбатан, %
ALTER TABLE client_card ADD COLUMN IF NOT EXISTS materiality_abs NUMERIC(18,2);  -- қатъий сумма, сўм
ALTER TABLE client_card ADD COLUMN IF NOT EXISTS onboard_date DATE;              -- аутсорсингга қабул қилинган сана
ALTER TABLE client_card ADD COLUMN IF NOT EXISTS contract_end DATE;              -- шартнома тугаган / тугайдиган сана

ALTER TABLE close_period ADD COLUMN IF NOT EXISTS override_reason TEXT;          -- тафовут билан ёпиш сабаби (муддат устувор)
ALTER TABLE close_period ADD COLUMN IF NOT EXISTS override_agreed TEXT;          -- буюртмачи раҳбари билан келишув (ким, қандай)
ALTER TABLE close_period ADD COLUMN IF NOT EXISTS override_by BIGINT REFERENCES app_user(id);
ALTER TABLE close_period ADD COLUMN IF NOT EXISTS override_open INTEGER;         -- ёпилгандаги очиқ тафовутлар сони
ALTER TABLE close_period ADD COLUMN IF NOT EXISTS amend_done DATE;               -- аниқлаштирилган ҳисобот топширилган сана

CREATE TABLE IF NOT EXISTS client_checklist (
    taxpayer_id BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind        TEXT    NOT NULL CHECK (kind IN ('ONBOARD', 'HANDOVER')),
    item_no     INTEGER NOT NULL,
    status      TEXT    CHECK (status IN ('Y', 'N', 'NA')),
    note        TEXT,
    as_of       DATE,
    updated_by  BIGINT REFERENCES app_user(id),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, kind, item_no)
);
