-- 0.9.481: номоддий активлар (ер ижара ҳуқуқи, лицензия, дастурий таъминот …) ва уларнинг бўлиб тўлаш жадвали.
CREATE TABLE IF NOT EXISTS ia_asset (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    name        TEXT   NOT NULL,
    kind        TEXT   NOT NULL DEFAULT 'OTHER',          -- LAND_LEASE | LICENSE | SOFTWARE | TRADEMARK | OTHER
    rec_date    DATE   NOT NULL,                           -- ҳисобга олинган (ҳуқуқ рўйхатдан ўтган) сана
    cost        NUMERIC(20,2) NOT NULL,
    months      INTEGER NOT NULL CHECK (months > 0),       -- фойдали хизмат (ижара) муддати, ой
    doc_no      TEXT, doc_date DATE,
    seller_name TEXT, seller_tin TEXT,
    pay_ref     TEXT,                                      -- тўлов мақсадидаги шахсий ғазна ҳисоби ёки бошқа белги
    note        TEXT,
    off_date    DATE,                                      -- ҳисобдан чиқарилган сана
    user_id     BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ia_asset_tp ON ia_asset(taxpayer_id);
CREATE TABLE IF NOT EXISTS ia_sched (
    id       BIGSERIAL PRIMARY KEY,
    asset_id BIGINT NOT NULL REFERENCES ia_asset(id) ON DELETE CASCADE,
    due_date DATE NOT NULL,
    amount   NUMERIC(20,2) NOT NULL,
    note     TEXT
);
CREATE INDEX IF NOT EXISTS ia_sched_a ON ia_sched(asset_id, due_date);
CREATE TABLE IF NOT EXISTS ia_paid (                     -- банкдан ташқари тўловлар (масалан, e-auksion орқали закалат)
    id       BIGSERIAL PRIMARY KEY,
    asset_id BIGINT NOT NULL REFERENCES ia_asset(id) ON DELETE CASCADE,
    op_date  DATE NOT NULL,
    amount   NUMERIC(20,2) NOT NULL,
    note     TEXT
);
