-- 0.9.88: ташқи API созламалари (E-CONTRACT API, Солиқ API калити) ва сервернинг ташқи IP манзилини кўриш ҳуқуқи —
-- администратор ва администратор рухсат берган аудитор
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS can_manage_api BOOLEAN NOT NULL DEFAULT FALSE;
