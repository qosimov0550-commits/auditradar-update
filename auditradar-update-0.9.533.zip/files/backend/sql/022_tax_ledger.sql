-- my3 «Шахсий ҳисобварақ» (КЛС): юкланган файллар ва операциялар (солиқ даври тузатилган ҳолда).
CREATE TABLE IF NOT EXISTS tax_ledger_file (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    file_name    TEXT        NOT NULL,
    path         TEXT        NOT NULL,
    sha256       TEXT        NOT NULL,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id      BIGINT,
    generated_at TIMESTAMP,                         -- my3 да шакллантирилган вақт (файл сарлавҳасидан)
    years        INTEGER[],                         -- файлдаги йиллик бўлимлар
    row_count    INTEGER     NOT NULL DEFAULT 0,
    status       TEXT        NOT NULL DEFAULT 'OK', -- OK | FOREIGN (бошқа СТИР) | ERROR
    note         TEXT,
    UNIQUE (taxpayer_id, sha256)
);

CREATE TABLE IF NOT EXISTS tax_ledger_row (
    id             BIGSERIAL PRIMARY KEY,
    taxpayer_id    BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    file_id        BIGINT  NOT NULL REFERENCES tax_ledger_file(id) ON DELETE CASCADE,
    seq            INTEGER NOT NULL,                -- файлдаги тартиб
    kind           TEXT    NOT NULL,                -- OPEN | OP | CLOSE
    file_year      INTEGER NOT NULL,                -- my3 йиллик файли (сальдо оралиғи)
    tax_year       INTEGER NOT NULL,                -- ҳақиқий солиқ даври (йил)
    post_close     BOOLEAN NOT NULL DEFAULT FALSE,  -- охирги сальдодан кейин келган (келгуси муддатли) ёзув
    region         TEXT    NOT NULL DEFAULT '',
    tax_code       INTEGER NOT NULL,
    tax_name       TEXT,
    op_date        DATE,
    content        TEXT,
    due_date       DATE,
    period_kind    TEXT,                            -- M | Q (мазмундан)
    period_no      INTEGER,
    period_ref_year INTEGER,
    accrued        NUMERIC(20,2) NOT NULL DEFAULT 0,
    reduced        NUMERIC(20,2) NOT NULL DEFAULT 0,
    paid           NUMERIC(20,2) NOT NULL DEFAULT 0,
    refunded       NUMERIC(20,2) NOT NULL DEFAULT 0,
    debt           NUMERIC(20,2) NOT NULL DEFAULT 0,
    overpay        NUMERIC(20,2) NOT NULL DEFAULT 0,
    neg_diff       NUMERIC(20,2) NOT NULL DEFAULT 0,
    penalty        NUMERIC(20,2) NOT NULL DEFAULT 0,
    penalty_period TEXT,
    penalty_paid   NUMERIC(20,2) NOT NULL DEFAULT 0,
    penalty_left   NUMERIC(20,2) NOT NULL DEFAULT 0,
    overpaid_sum   NUMERIC(20,2) NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS tax_ledger_row_tp ON tax_ledger_row(taxpayer_id, tax_code, tax_year);
