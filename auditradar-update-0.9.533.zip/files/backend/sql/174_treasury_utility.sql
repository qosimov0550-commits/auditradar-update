-- 0.9.431: ғазна шахсий ҳисоби тури «коммунал хизмат (шартнома)» — электр, газ, сув, иссиқлик таъминоти (акциядорлик
-- жамиятлари, фақат ғазна ҳисобидан фойдаланади; бюджет ташкилоти эмас). Ҳисоби бюджет ташкилотидагидек (тўлов шу СТИРга).
ALTER TABLE treasury_ls DROP CONSTRAINT IF EXISTS treasury_ls_kind_check;
ALTER TABLE treasury_ls ADD CONSTRAINT treasury_ls_kind_check CHECK (kind IN ('TAX', 'CUSTOMS', 'BUDGET_ORG', 'UTILITY'));
-- аввал «бюджет ташкилоти» деб боғланган коммунал корхоналар — янги турга
UPDATE treasury_ls SET kind = 'UTILITY'
 WHERE kind = 'BUDGET_ORG' AND tin IS NOT NULL
   AND COALESCE(name, '') ~* '(elektr|электр|hududgaz|худудгаз|ҳудудгаз|gaz ?ta|газ ?та|газоснаб|suv ?ta|сув ?та|suvoqova|сувоқова|водокан|issiqlik|иссиқлик|теплоэн|ТЭТ|ШЭТ|ЭТК)';
