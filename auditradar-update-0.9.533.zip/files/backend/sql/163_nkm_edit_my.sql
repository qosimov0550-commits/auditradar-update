-- 0.9.376: 0.9.370 даги ALTER лар 162 файлига қўшилган эди — сервер 162 ни 0.9.369 да аллақачон бажаргани учун (миграция номи
-- бўйича) улар ишламади: nkm_edit да source/status/applied устунлари йўқ, таҳрирланган чеклар ёзилмади. Шу ерда қайта.
-- 0.9.370: my.soliq.uz «Таҳрирланган ва қайтарилган чеклар» (Excel: Eski / Yangi қаторлари) — манба, ҳолат, қўлланганлиги
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS source  TEXT NOT NULL DEFAULT 'RELOAD';    -- RELOAD | MY (my.soliq.uz рўйхати)
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS status  TEXT;                             -- сайтдаги ҳолат (Yangi, Qabul qilingan, …)
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS sent_at TIMESTAMP;
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS accepted_at TIMESTAMP;
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS applied BOOLEAN NOT NULL DEFAULT FALSE;  -- чек таркиби алмаштирилди
ALTER TABLE nkm_edit ADD COLUMN IF NOT EXISTS editor_tin TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS ux_nkm_edit_my ON nkm_edit(taxpayer_id, terminal_id, receipt_no, paid_at) WHERE source='MY';
