-- 0.9.445: асосий воситалар реестри ва эскириш ҳисоби («Маълумотнома» шакли — ҳар йил учун бир қатор/объект).
CREATE TABLE IF NOT EXISTS fa_row (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT   NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    year         SMALLINT NOT NULL,
    period_end   DATE     NOT NULL,
    row_no       INTEGER  NOT NULL,
    name         TEXT     NOT NULL,
    acq_year     SMALLINT,
    account      TEXT,
    account_name TEXT,
    unit         TEXT,
    open_qty     NUMERIC(18,4) NOT NULL DEFAULT 0,
    open_cost    NUMERIC(20,2) NOT NULL DEFAULT 0,
    open_dep     NUMERIC(20,2) NOT NULL DEFAULT 0,
    in_date      DATE,
    in_qty       NUMERIC(18,4) NOT NULL DEFAULT 0,
    in_cost      NUMERIC(20,2) NOT NULL DEFAULT 0,
    out_date     DATE,
    out_qty      NUMERIC(18,4) NOT NULL DEFAULT 0,
    out_cost     NUMERIC(20,2) NOT NULL DEFAULT 0,
    rate         NUMERIC(8,4)  NOT NULL DEFAULT 0,      -- йиллик, фоизда (20 = 20%)
    dep          NUMERIC(20,2) NOT NULL DEFAULT 0,      -- файлдаги (бухгалтер ҳисоблаган) давр эскириши
    close_qty    NUMERIC(18,4),                         -- файлда кўрсатилган давр охири қолдиғи
    close_cost   NUMERIC(20,2),
    close_dep    NUMERIC(20,2),
    close_net    NUMERIC(20,2),
    file_name    TEXT,
    user_id      BIGINT,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_fa_row ON fa_row(taxpayer_id, year, row_no);

CREATE TABLE IF NOT EXISTS fa_policy (
    taxpayer_id  BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    method       TEXT NOT NULL DEFAULT 'AUTO' CHECK (method IN ('AUTO','DAY','MONTH')),
    user_id      BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
