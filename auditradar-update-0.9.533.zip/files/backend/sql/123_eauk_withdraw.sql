-- 0.9.245: e-auksion «…pul yechish uchun ruxsat berildi» — банкка қайтариш (аввал OTHER деб ёзилган эди)
UPDATE exchange_txn SET kind='WITHDRAW' WHERE platform_tin='305004780' AND kind='OTHER' AND comment ~* 'pul yechish';
