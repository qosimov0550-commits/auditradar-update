-- Payme, Click ва бошқа тўлов тизимлари тушуми «Савдо тушуми (маркетплейс)» билан бирлаштирилди
UPDATE bank_override SET category='Савдо тушуми (маркетплейс)' WHERE category='Савдо тушуми (пайме)';
UPDATE bank_cp_rule  SET category='Савдо тушуми (маркетплейс)' WHERE category='Савдо тушуми (пайме)';
