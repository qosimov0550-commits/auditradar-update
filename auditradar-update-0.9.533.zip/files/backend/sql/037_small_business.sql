-- Кичик тадбиркорлик субъекти: валюта репатриацияси жаримаси 180 кун + 90 кундан кейин (бошқаларга + 45 кун)
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS small_business BOOLEAN;
