-- 0.9.238: my.soliq «Профиль → Асосий воситалар» (фақат ўқиш): кўчмас мулк, ер участкалари, автотранспорт, қишлоқ
-- хўжалиги ерлари, кўчмас мулк ва автотранспорт ижараси (ижарага олинган / берилган). Кўчмас мулк ва ерлар — йиғилган
-- кундаги ҳолат; транспорт ва ижара — йил бўйича. Ҳар бир (мижоз, тур, йил) янги йиғилганда тўлиқ алмаштирилади.
CREATE TABLE IF NOT EXISTS asset_item (
    taxpayer_id     BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind            TEXT    NOT NULL,   -- ESTATE | LAND | AGRI | VEHICLE | RENT_ESTATE_IN | RENT_ESTATE_OUT | RENT_VEH_IN | RENT_VEH_OUT
    year            INTEGER NOT NULL DEFAULT 0,   -- 0 — йиғилган кундаги ҳолат
    row_no          INTEGER NOT NULL,
    code            TEXT,               -- кадастр рақами / давлат рақами
    name            TEXT,
    type            TEXT,
    address         TEXT,
    reg_date        DATE,
    total_area      NUMERIC(16,2),
    production_area NUMERIC(16,2),
    undocumented_area NUMERIC(16,2),
    kadastr_amount  NUMERIC(20,2),
    cp_tin          TEXT,               -- ижара: контрагент СТИР/ЖШШИР
    cp_name         TEXT,
    month_sum       NUMERIC(20,2),
    date_begin      DATE,
    date_end        DATE,
    date_deact      DATE,
    year_of_issue   INTEGER,
    raw             JSONB,
    collected_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, kind, year, row_no)
);
