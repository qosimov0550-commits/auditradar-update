-- Кадрлар: ходим картаси, туғилган кун табриклари (платформа + Telegram), мижозларни тақсимлаш (аудитор)
-- Сақланмайди: паспорт, ЖШШИР, яшаш манзили, оилавий маълумотлар, иш ҳақи, шартнома нусхаси (фақат реквизитлари).
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS can_hr BOOLEAN NOT NULL DEFAULT FALSE;   -- «Кадрлар» ҳуқуқи

CREATE TABLE IF NOT EXISTS staff_card (
    user_id         BIGINT PRIMARY KEY REFERENCES app_user(id) ON DELETE CASCADE,
    position        TEXT,
    hired_on        DATE,
    birth_day       SMALLINT CHECK (birth_day BETWEEN 1 AND 31),
    birth_month     SMALLINT CHECK (birth_month BETWEEN 1 AND 12),
    birth_year      SMALLINT,                       -- ихтиёрий
    phone           TEXT,
    tg_username     TEXT,
    tg_chat_id      BIGINT,                         -- ходим ўзи «/start <код>» орқали улайди
    tg_linked_at    TIMESTAMPTZ,
    contract_no     TEXT,
    contract_date   DATE,
    contract_kind   TEXT,                           -- муддатсиз | муддатли | ўриндошлик | ФҲШ
    contract_until  DATE,
    cert_kind       TEXT,                           -- аудитор малака сертификати, бухгалтер сертификати ва ҳ.к.
    cert_no         TEXT,
    cert_until      DATE,
    training_hours  INTEGER,                        -- жорий йилдаги малака ошириш соатлари
    note            TEXT,
    updated_by      BIGINT,
    updated_at      TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS tg_link_code (
    code        TEXT PRIMARY KEY,
    user_id     BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS greeting_log (
    user_id     BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    year        SMALLINT NOT NULL,
    channel     TEXT NOT NULL,                      -- telegram | notify
    sent_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, year, channel)
);

ALTER TABLE client_card ADD COLUMN IF NOT EXISTS auditor_id BIGINT REFERENCES app_user(id);

INSERT INTO app_setting(key, value) VALUES ('hr.birthday_text',
 'Ҳурматли {исм}! Сизни туғилган кунингиз билан самимий муборакбод этамиз. Сизга мустаҳкам соғлик, оилавий бахт ва касбий муваффақиятлар тилаймиз. «FISCAL AUDIT» жамоаси')
ON CONFLICT (key) DO NOTHING;
