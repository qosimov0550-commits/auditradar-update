-- 0.9.118: БЮД 20-графа «Етказиб бериш шартлари» (Йўриқнома 2773, 7-илова). terms_v — PDF қайси версияда ўқилган
-- (0.9.118 гача юкланган PDF ларда 20-графа ўқилмаган — ed2 орқали кейинги йиғишда қайта олинади).
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS terms   TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS terms_v SMALLINT NOT NULL DEFAULT 0;
