-- 0.9.138: норезидентлар даромадидан фойда солиғи ҳисоб-китобига илова қилинган асос файллари (my.soliq.uz form-payments:
-- reductionCoefficientDocGuid — халқаро битим/резидентлик сертификати, beneficialOwnerDocGuid — ҳақиқий ҳуқуқ эгаси,
-- paymentReductionDocGuid — тўловни камайтириш асоси). Йиғувчи файлни ўзи юклаб олади (GET /api/file-api/file/download/{guid}).
CREATE TABLE IF NOT EXISTS ft_nonres_doc (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    guid          TEXT   NOT NULL,
    kind          TEXT   NOT NULL,
    partner_key   TEXT,
    partner_name  TEXT,
    year          INT,
    pay_date      DATE,
    idn           TEXT,
    doc_no        TEXT,
    doc_date      DATE,
    file_path     TEXT,
    ctype         TEXT,
    size          BIGINT,
    fetched_at    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, guid, kind, pay_date)
);
CREATE INDEX IF NOT EXISTS ix_ft_nonres_doc ON ft_nonres_doc(taxpayer_id, partner_key, year);
