-- 0.9.283: Эстония шакли (сарлавҳадаги «сана nr рақам», «Справка о резидентстве … является резидентом») — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
