-- 0.9.289: Қозоғистон — ички қўштирноқдаги ном (А-Транс) ва «№ МКА-…» рақами — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
