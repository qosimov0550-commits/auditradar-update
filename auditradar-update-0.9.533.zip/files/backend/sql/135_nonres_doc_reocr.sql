-- 0.9.282: Литва (апостиль), Қозоғистон, Швейцария, Хитой (Shenzhen) шакллари учун ўқиш қоидалари кенгайтирилди — сертификатлар қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
