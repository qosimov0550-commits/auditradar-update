-- 0.9.482: ҳисоб натижаларини сақлаш (тезлаштириш). Мижоз маълумоти ўзгарса — натижа эскирган ҳисобланади.
-- Ўзгаришни кодга боғлиқ бўлмаган ҳолда ушлаш: жадвалларга statement-триггер, ўзгарган мижозлар data_ver_log га ёзилади
-- (қатор қулфисиз — фақат INSERT). Белги = мижоз (ва умумий 0) бўйича COUNT + MAX(id).
CREATE TABLE IF NOT EXISTS data_ver_log (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL,             -- 0 — умумий маълумотномалар (қоидалар, курслар …)
    at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS data_ver_log_tp ON data_ver_log(taxpayer_id, id);
CREATE TABLE IF NOT EXISTS calc_cache (
    taxpayer_id BIGINT NOT NULL,
    key         TEXT   NOT NULL,
    fp          TEXT   NOT NULL,
    data        BYTEA  NOT NULL,
    secs        REAL,
    computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, key)
);

CREATE OR REPLACE FUNCTION ar_ver_tp() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO data_ver_log(taxpayer_id) SELECT DISTINCT taxpayer_id FROM ot WHERE taxpayer_id IS NOT NULL;
    ELSE
        INSERT INTO data_ver_log(taxpayer_id) SELECT DISTINCT taxpayer_id FROM nt WHERE taxpayer_id IS NOT NULL;
    END IF;
    RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION ar_ver_id() RETURNS trigger LANGUAGE plpgsql AS $$   -- taxpayer жадвалининг ўзи
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO data_ver_log(taxpayer_id) SELECT DISTINCT id FROM ot;
    ELSE
        INSERT INTO data_ver_log(taxpayer_id) SELECT DISTINCT id FROM nt;
    END IF;
    RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION ar_ver_global() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        IF EXISTS (SELECT 1 FROM ot) THEN INSERT INTO data_ver_log(taxpayer_id) VALUES (0); END IF;
    ELSE
        IF EXISTS (SELECT 1 FROM nt) THEN INSERT INTO data_ver_log(taxpayer_id) VALUES (0); END IF;
    END IF;
    RETURN NULL;
END $$;

-- Триггерларни қўйиш (идемпотент; янги жадваллар учун сервер ишга тушганда ҳам чақирилади).
CREATE OR REPLACE FUNCTION ar_ver_attach() RETURNS integer LANGUAGE plpgsql AS $$
DECLARE
    r RECORD; fn TEXT; n INTEGER := 0;
    skip TEXT[] := ARRAY['data_ver_log','calc_cache','schema_migrations','audit_log','audit_proc','auth_fail','app_user','api_token',
        'login_qr','notification','notification_read','push_state','push_sub','user_device','greeting_log','tg_link_code','soliq_api_call',
        'license_check','license_doc','backup_run','backup_target','collect_run','quick_run','task','task_event','finding','finding_comment',
        'finding_event','mail_fetch','mail_letter','policy_acceptance','staff_card','user_client','risk_import','mxik_fetch','gl_entry',
        'gl_settings','bank_summary','normdoc','counterparty','cp_soliq','person_tin','app_setting','client_checklist',
        -- болалар жадваллари: доим ота жадвал (taxpayer_id ли) билан бирга ёзилади
        'esf_item','esf_item_marking','receipt','receipt_item','receipt_item_marking','nkm_item','ft_decl_pdf_item','ia_sched','ia_paid',
        'kkm_daily','kkm_monthly','merge_line','stock_balance','tax_report_line','vat_register_row','vat_return_line',
        'vat_return_appendix_row','realty_sale'];
BEGIN
    FOR r IN SELECT t.table_name,
                    EXISTS (SELECT 1 FROM information_schema.columns c WHERE c.table_schema='public' AND c.table_name=t.table_name
                                                                         AND c.column_name='taxpayer_id') has_tp
             FROM information_schema.tables t WHERE t.table_schema='public' AND t.table_type='BASE TABLE'
    LOOP
        CONTINUE WHEN r.table_name = ANY(skip);
        CONTINUE WHEN EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'ar_ver_i' AND tgrelid = ('public.' || quote_ident(r.table_name))::regclass);
        fn := CASE WHEN r.table_name = 'taxpayer' THEN 'ar_ver_id' WHEN r.has_tp THEN 'ar_ver_tp' ELSE 'ar_ver_global' END;
        EXECUTE format('CREATE TRIGGER ar_ver_i AFTER INSERT ON public.%I REFERENCING NEW TABLE AS nt FOR EACH STATEMENT EXECUTE FUNCTION %s()', r.table_name, fn);
        EXECUTE format('CREATE TRIGGER ar_ver_u AFTER UPDATE ON public.%I REFERENCING NEW TABLE AS nt FOR EACH STATEMENT EXECUTE FUNCTION %s()', r.table_name, fn);
        EXECUTE format('CREATE TRIGGER ar_ver_d AFTER DELETE ON public.%I REFERENCING OLD TABLE AS ot FOR EACH STATEMENT EXECUTE FUNCTION %s()', r.table_name, fn);
        n := n + 1;
    END LOOP;
    RETURN n;
END $$;

SELECT ar_ver_attach();
