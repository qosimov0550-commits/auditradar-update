-- 0.9.103: солиқ органи қабул қилмаган қайтариш чеклари.
-- my.soliq.uz «Кунлик ҳисобот» (cashregister-reports-api/reports/get-ofd-reports, tab=daily) — корхона × кун бўйича
-- жами сотув ва қайтаришлар. Шу кунги қайтариш чеклари ҳисоботдан кўп бўлса — ортиқча қисмга тенг келадиган чеклар
-- «солиқ қабул қилмаган» (tax_rejected) деб белгиланади: сотув кучда қолади (тушум ва омбордан айирилмайди).
-- Сотув чекига бириктирилмаган қайтаришлар алоҳида тур — REFUND_FREE (солиқ ҳисоботига кирмайди, тушумдан айирилмайди).
ALTER TABLE nkm_receipt ADD COLUMN IF NOT EXISTS tax_rejected BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS nkm_day_report (
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    check_type   VARCHAR(30) NOT NULL,
    commission   BOOLEAN     NOT NULL DEFAULT FALSE,
    d            DATE        NOT NULL,
    total        NUMERIC(20,2), vat NUMERIC(20,2),
    refund_total NUMERIC(20,2), refund_vat NUMERIC(20,2),
    checks       INTEGER,
    fetched_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, check_type, commission, d)
);
