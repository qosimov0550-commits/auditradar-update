-- 0.9.85: шифрланган кечки захира нусхалари ва захира масканлари (офис ва уй компьютерлари — pull агент)
CREATE TABLE IF NOT EXISTS backup_run (
    id           BIGSERIAL PRIMARY KEY,
    kind         TEXT        NOT NULL,                 -- FULL | INC
    trigger      TEXT        NOT NULL DEFAULT 'schedule',   -- schedule | manual | test
    user_id      BIGINT      REFERENCES app_user(id),
    status       TEXT        NOT NULL DEFAULT 'RUNNING',    -- RUNNING | OK | FAILED
    started_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at  TIMESTAMPTZ,
    file         TEXT,
    size         BIGINT,
    sha256       TEXT,
    files        INTEGER,
    files_bytes  BIGINT,
    test_ok      BOOLEAN,
    test_at      TIMESTAMPTZ,
    error        TEXT,
    detail       JSONB
);
CREATE INDEX IF NOT EXISTS backup_run_started ON backup_run(started_at DESC);

CREATE TABLE IF NOT EXISTS backup_target (
    id           BIGSERIAL PRIMARY KEY,
    name         TEXT        NOT NULL,
    kind         TEXT        NOT NULL,                 -- office | home | other
    server_url   TEXT        NOT NULL,
    dest         TEXT,
    token_hash   TEXT        NOT NULL UNIQUE,          -- калитнинг ўзи сақланмайди
    created_by   BIGINT      REFERENCES app_user(id),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at TIMESTAMPTZ,
    last_ok_at   TIMESTAMPTZ,
    last_ip      TEXT,
    last_file    TEXT,
    have         INTEGER,
    free_bytes   BIGINT,
    total_bytes  BIGINT,
    host         TEXT,
    last_error   TEXT,
    revoked      BOOLEAN     NOT NULL DEFAULT FALSE
);
ALTER TABLE backup_target ADD COLUMN IF NOT EXISTS agent_time TEXT;
