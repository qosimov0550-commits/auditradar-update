-- 0.9.167: ғазначилик шахсий ҳисоблари маълумотномаси (барча мижозлар учун битта): шахсий ҳисоб -> олувчи (бюджет ташкилоти,
-- солиқ органи, божхона). Банк тўлов мақсадидаги «~ШАХСИЙ_ҲИСОБ~СТИР~» дан ўрганилади ёки аудитор қўлда боғлайди.
CREATE TABLE IF NOT EXISTS treasury_ls (
    ls          TEXT PRIMARY KEY,
    tin         TEXT,
    name        TEXT,
    kind        TEXT NOT NULL DEFAULT 'BUDGET_ORG' CHECK (kind IN ('TAX', 'CUSTOMS', 'BUDGET_ORG')),
    source      TEXT NOT NULL DEFAULT 'BANK' CHECK (source IN ('BANK', 'MANUAL')),
    n           INT  NOT NULL DEFAULT 0,
    conflict    TEXT,                       -- банкда бошқа СТИР ҳам учраган бўлса
    updated_by  BIGINT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
