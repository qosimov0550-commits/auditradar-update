-- my3 дан олинган ҳисоботлар (ҳисобот рақами бўйича). Ҳисобот рақами ўзгармайди (тузатиш — янги рақам), шунинг учун
-- бир марта олинган ҳисобот қайта юклаб олинмайди — шакли танилмаган ёки иловаси йўқ бўлса ҳам (аввал улар ҳар йиғишда
-- қайта олинарди).
CREATE TABLE IF NOT EXISTS my3_report_fetch (
    taxpayer_id BIGINT      NOT NULL REFERENCES taxpayer(id),
    report_no   VARCHAR(40) NOT NULL,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, report_no)
);
INSERT INTO my3_report_fetch(taxpayer_id, report_no)
SELECT taxpayer_id, report_no FROM tax_report WHERE report_no IS NOT NULL
UNION SELECT taxpayer_id, report_no FROM payroll_report WHERE report_no IS NOT NULL AND has_rows
ON CONFLICT DO NOTHING;
