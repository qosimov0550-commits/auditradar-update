-- 0.9.292: Швейцария 2024 шакли (certify that … TIN) — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
