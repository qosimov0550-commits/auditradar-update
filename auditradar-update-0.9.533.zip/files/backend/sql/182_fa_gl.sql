-- 0.9.449: асосий воситалар реестри бухгалтерияга (проводкалар, ОСВ, баланс) уланади.
ALTER TABLE fa_policy ADD COLUMN IF NOT EXISTS gl        BOOLEAN NOT NULL DEFAULT TRUE;   -- проводкаларга ўтказиш
ALTER TABLE fa_policy ADD COLUMN IF NOT EXISTS exp_main  TEXT;    -- бино ва ускуналар (0120, 0130) эскириши счёти; NULL — профил бўйича
ALTER TABLE fa_policy ADD COLUMN IF NOT EXISTS exp_other TEXT;    -- бошқа объектлар эскириши счёти; NULL — 9420
