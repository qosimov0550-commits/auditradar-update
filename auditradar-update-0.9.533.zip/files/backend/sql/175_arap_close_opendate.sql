-- 0.9.433: 0.9.432 да ҳаракатсиз (фақат 1С бошланғич қолдиғи) қаторлар ёпилганда сана бугунги кун бўлиб, танланган
-- даврдан ташқарида қолган — бундай ёпишлар давр боши қолдиғи санасига кўчирилади.
UPDATE arap_close a SET close_date = b.d
FROM (SELECT taxpayer_id, MIN(as_of) d FROM arap_balance WHERE kind='OPEN' GROUP BY taxpayer_id) b
WHERE b.taxpayer_id = a.taxpayer_id AND a.category LIKE 'Солиқ ва божхона тўловлари%'
  AND a.close_date = (a.created_at AT TIME ZONE 'Asia/Tashkent')::date AND b.d < a.close_date;
