-- 0.9.56: ed2.customs.uz «ГТД рўйхати» — БЮДлар ва уларнинг божхонадаги ҳолати (кенгайтма фақат ўқийди).
-- «Справ. номер ГТД» (декларант ЖШШИРи билан бошланади), ПИНФЛ, брокер телефони ва почтаси сақланмайди.
CREATE TABLE IF NOT EXISTS ft_ed2_decl (
    taxpayer_id    BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    decl_uuid      TEXT        NOT NULL,          -- сайтдаги decl_id
    ebr_id         TEXT,                          -- PDF чоп этиш идентификатори (download_print)
    decl_post      VARCHAR(10),
    decl_date      DATE,
    decl_no        INTEGER,
    registered_at  TIMESTAMP,
    regime         VARCHAR(10),
    sender         TEXT,
    receiver       TEXT,
    country        TEXT,
    customs_value  NUMERIC(20,2),
    invoice_value  NUMERIC(20,2),
    n_goods        INTEGER,
    gtd_type       TEXT,
    status_code    SMALLINT,
    status         TEXT,
    first_seen     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen      TIMESTAMPTZ NOT NULL DEFAULT now(),
    status_changed TIMESTAMPTZ,
    prev_status    TEXT,
    PRIMARY KEY (taxpayer_id, decl_uuid)
);
CREATE INDEX IF NOT EXISTS ix_ft_ed2_decl_no ON ft_ed2_decl(taxpayer_id, decl_no, decl_date);
CREATE TABLE IF NOT EXISTS ft_ed2_fetch (
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    status_code  SMALLINT    NOT NULL,
    d_from       DATE        NOT NULL,
    d_to         DATE        NOT NULL,
    rows         INTEGER     NOT NULL DEFAULT 0,
    fetched_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, status_code, d_from)
);
