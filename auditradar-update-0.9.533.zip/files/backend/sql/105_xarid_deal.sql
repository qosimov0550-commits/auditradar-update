-- 0.9.162: Давлат харидлари электрон тизими (xarid.uzex.uz) — «Ҳисоботлар» бўлимидан Excel: аукцион, электрон / миллий дўкон,
-- тўғридан-тўғри харидлар, E-Tender. Ҳар бир битим — бир қатор; корхона ижрочи (сотувчи, SELL) ёки буюртмачи (BUY).
CREATE TABLE IF NOT EXISTS xarid_deal (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id),
    report       TEXT    NOT NULL,          -- AUCTION / SHOP / DIRECT / ETENDER
    trade_type   TEXT,                      -- «Электронный Магазин», «Национальный магазин» ...
    side         VARCHAR(4) NOT NULL CHECK (side IN ('SELL', 'BUY')),
    deal_no      TEXT    NOT NULL,
    lot_no       TEXT    NOT NULL DEFAULT '',
    deal_date    DATE,
    status       TEXT,
    product      TEXT,
    qty          NUMERIC(20,4),
    unit         TEXT,
    start_amount NUMERIC(20,2),
    amount       NUMERIC(20,2) NOT NULL DEFAULT 0,
    currency     TEXT    NOT NULL DEFAULT 'UZS',
    cp_tin       TEXT,                      -- контрагент: сотувда — буюртмачи, харидда — ижрочи
    cp_name      TEXT,
    cp_region    TEXT,
    budget       BOOLEAN,                   -- молиялаштириш манбаи «Бюджет»
    pay_date     DATE,
    cancel_date  DATE,
    end_date     DATE,
    penalty      NUMERIC(20,2) NOT NULL DEFAULT 0,
    penalty_type TEXT,
    penalty_date DATE,
    term_by      TEXT,
    term_reason  TEXT,
    file_name    TEXT,
    loaded_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_xarid_deal ON xarid_deal(taxpayer_id, report, deal_no, lot_no);
CREATE INDEX IF NOT EXISTS ix_xarid_deal_cp ON xarid_deal(taxpayer_id, cp_tin);
-- Юкланган ҳисоботлар (бўш ҳисобот ҳам — «бу турда битим йўқ» деган далил).
CREATE TABLE IF NOT EXISTS xarid_load (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id),
    report       TEXT   NOT NULL,
    period_from  DATE,
    period_to    DATE,
    n            INT    NOT NULL DEFAULT 0,
    file_name    TEXT,
    source       TEXT   NOT NULL DEFAULT 'FILE',
    loaded_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, report)
);
