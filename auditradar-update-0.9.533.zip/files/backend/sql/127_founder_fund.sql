-- 0.9.250: таъсисчи/директор маблағи — корхона ҳисобидан эмас тушган тўловлар бўйича аудитор белгиси (ҳужжат ва ҳал этилиши).
CREATE TABLE IF NOT EXISTS founder_fund (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    src         TEXT   NOT NULL,          -- AUK (e-auksion карта тўлови)
    ref         TEXT   NOT NULL,          -- манбадаги рақам (тўлов чипта рақами)
    status      TEXT   NOT NULL CHECK (status IN ('NONE', 'LOAN', 'CAPITAL', 'REPAID', 'GIFT')),
    note        TEXT,
    set_by      BIGINT,
    set_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, src, ref)
);
