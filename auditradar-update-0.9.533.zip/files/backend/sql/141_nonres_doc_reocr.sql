-- 0.9.287: Беларусь — справка рақами, шакл ёрлиқлари ном сифатида олинмайди — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
