-- Солиқ қўмитаси марказий маълумотлар базаси API (оферта; X-API-KEY): контрагент маълумотлари кеши ва сўровлар ҳисоби
CREATE TABLE IF NOT EXISTS cp_soliq (
    tin              TEXT PRIMARY KEY,
    found            BOOLEAN NOT NULL,
    name             TEXT,
    status_code      TEXT,
    status_name      TEXT,
    status_updated   DATE,
    registered_at    DATE,
    liquidated_at    DATE,
    tax_mode         TEXT,
    vat_number       TEXT,
    oked             TEXT,
    oked_name        TEXT,
    business_fund    NUMERIC(20,2),
    address          TEXT,
    raw              JSONB,
    checked_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS soliq_api_call (
    id        SERIAL PRIMARY KEY,
    called_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    tin       TEXT,
    http      INT,
    ok        BOOLEAN NOT NULL,
    error     TEXT
);
CREATE INDEX IF NOT EXISTS soliq_api_call_day ON soliq_api_call (called_at);
