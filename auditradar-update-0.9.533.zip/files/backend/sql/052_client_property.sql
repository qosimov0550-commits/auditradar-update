-- Мижоз мол-мулки / ер участкалари (мол-мулк ва ер солиғи мажбуриятлари учун): манзил, мулк ҳуқуқи вужудга келган сана, ҳудуд
CREATE TABLE IF NOT EXISTS client_property (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    address     TEXT   NOT NULL,
    since       DATE,
    region      TEXT,
    note        TEXT,
    source      TEXT   NOT NULL DEFAULT 'list',
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_client_property_tp ON client_property(taxpayer_id);

-- сув солиғи: мижозларнинг барчаси чоракда тўлайди (фойдаланувчи қарори) — ойлик бўнак ўчирилади, чораклик — ҳаммага
UPDATE tax_obligation SET active=FALSE WHERE code='WATER_PAY_M';
UPDATE tax_obligation SET applies='ALL', name='Сув солиғи — бўнак тўлови (чораклик, 1/4)',
       note='Ҳар чорак учинчи ойининг 20-куни, йиллик солиқ суммасининг 1/4 қисми (СК 448-модда). Ойлик тўловчи мижоз бўлса — «Сув солиғи (1/12)» ни шу мижозга ёқинг'
 WHERE code='WATER_PAY_Q' AND applies='AOS';
-- мол-мулк ва ер: ҳисобот ва тўловлар — мол-мулки (ер участкаси) рўйхатда бор ёки шахсий ҳисобварағида шу солиқ бор мижозларга
UPDATE tax_obligation SET applies='ALL' WHERE code IN ('PROP', 'LAND') AND applies='ALL';
UPDATE tax_obligation SET applies='ALL' WHERE code='PROP_REF' AND applies='NONE';
UPDATE tax_obligation SET applies='ALL' WHERE code='WATER_REF' AND applies='NONE';
