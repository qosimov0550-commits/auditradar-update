-- Ҳисоб назорати (диссертация 2, 4, 5-иловалари): ҳужжатлар реестри, камчиликлар, даврни ёпиш, солиштириш.
CREATE TABLE IF NOT EXISTS doc_register (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    period       DATE    NOT NULL,                  -- ҳисобот ойи (1-кун)
    doc_name     TEXT    NOT NULL,
    doc_no       TEXT,
    doc_date     DATE,
    counterparty TEXT,
    amount       NUMERIC(20,2),
    received_at  DATE,                              -- келган сана
    due_at       DATE,                              -- ҳисобга олиш муддати (келишилган)
    checked_at   DATE,                              -- текширилган сана
    posted_at    DATE,                              -- ҳисобга олинган сана
    status       TEXT    NOT NULL DEFAULT 'RECEIVED', -- RECEIVED | CHECKING | RETURNED | POSTED
    defect_code  TEXT,                              -- H-1 … H-7
    executor_id  BIGINT,
    source       TEXT    NOT NULL DEFAULT 'MANUAL', -- MANUAL | ESF
    esf_id       BIGINT,
    note         TEXT,
    created_by   BIGINT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_doc_register_esf ON doc_register(taxpayer_id, esf_id) WHERE esf_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_doc_register_tp ON doc_register(taxpayer_id, period);

-- 2.1-илова «Камчиликлар ва тузатишлар қайди» ҳамда 3-илова «масъул томон»
CREATE TABLE IF NOT EXISTS doc_defect (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    register_id  BIGINT  REFERENCES doc_register(id) ON DELETE CASCADE,
    period       DATE    NOT NULL,
    found_at     DATE    NOT NULL DEFAULT CURRENT_DATE,
    code         TEXT    NOT NULL,
    description  TEXT,
    party        TEXT    NOT NULL DEFAULT 'UNKNOWN', -- CLIENT | OUTSOURCER | BOTH | UNKNOWN
    fixer_id     BIGINT,
    fix_due      DATE,
    fixed_at     DATE,
    evidence     TEXT,
    created_by   BIGINT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_doc_defect_tp ON doc_defect(taxpayer_id, period);

-- 4.1 / 4.3-илова: даврни ёпиш назорат рўйхати ва календари
CREATE TABLE IF NOT EXISTS close_item (
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    period       DATE    NOT NULL,
    item_no      INTEGER NOT NULL,
    plan_date    DATE,
    executor_id  BIGINT,
    done_at      DATE,
    status       TEXT    NOT NULL DEFAULT 'O',      -- B — бажарилди, O — очиқ, T — татбиқ этилмайди
    evidence     TEXT,
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ,
    PRIMARY KEY (taxpayer_id, period, item_no)
);

-- даврни ёпиш қарори ва ҳисобот муддати (5.1-илова «Ҳисобот ўз вақтида тайёрланди»)
CREATE TABLE IF NOT EXISTS close_period (
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    period       DATE    NOT NULL,
    report_due   DATE,
    report_done  DATE,
    reports_plan INTEGER,
    reports_done INTEGER,
    closed       BOOLEAN NOT NULL DEFAULT FALSE,
    closed_by    BIGINT,
    closed_at    TIMESTAMPTZ,
    checked_by   BIGINT,
    note         TEXT,
    PRIMARY KEY (taxpayer_id, period)
);

-- 4.2-илова: синтетик ва аналитик ҳисобни солиштириш варақаси
CREATE TABLE IF NOT EXISTS recon_row (
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    period       DATE    NOT NULL,
    object       TEXT    NOT NULL,                  -- DEBTORS | CREDITORS | INVENTORY | FIXED | PAYROLL | TAXES
    synthetic    NUMERIC(20,2),
    analytic     NUMERIC(20,2),
    cause        TEXT,
    fixed_note   TEXT,
    fixed_at     DATE,
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ,
    PRIMARY KEY (taxpayer_id, period, object)
);
