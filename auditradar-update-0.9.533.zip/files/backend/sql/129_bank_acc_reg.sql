-- 0.9.262: my.soliq «Банк ҳисобрақамлари рўйхати» — корхонанинг барча банк ҳисоблари (кўчирмаси етишмаётганларни аниқлаш учун)
CREATE TABLE IF NOT EXISTS bank_acc_reg (
    taxpayer_id INT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    account     TEXT NOT NULL,
    bank        TEXT NOT NULL DEFAULT '',
    status      TEXT,
    reg_date    DATE,
    as_of       DATE,
    loaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, account, bank)
);
-- 0.9.262 (фойдаланувчи): биржа кўчирмасидаги 00642 «Переброска денежных средств» — ички ўтказма эмас, биржа ҳисобига
-- келган оддий тушум; банк кўчирмаларида манбаси топилмаса — тақдим этилмаган ҳисобдан бўлиши мумкин
UPDATE exchange_txn SET kind = CASE WHEN COALESCE(credit, 0) > 0 THEN 'DEPOSIT' ELSE 'WITHDRAW' END
 WHERE kind = 'MOVE' AND comment ILIKE 'платеж%' AND (details ~* '^\s*00642' OR details ~* 'переброск');
