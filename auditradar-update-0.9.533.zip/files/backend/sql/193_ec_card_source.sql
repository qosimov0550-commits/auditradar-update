-- 0.9.506: E-CONTRACT «шартнома картаси» (Шартномалар рўйхатидан ҳар бир шартнома учун юкланадиган Excel) — янги манба
ALTER TABLE data_import DROP CONSTRAINT IF EXISTS data_import_source_check;
ALTER TABLE data_import ADD CONSTRAINT data_import_source_check CHECK (source IN (
    'MY3_VAT_SUBMITTED', 'MY3_VAT_GENERATED', 'ESF_SOLIQSERVIS', 'ESF_FAKTURA', 'ESF_OTHER', 'MY3_KKM',
    'ECONTRACT_CONTRACTS', 'ECONTRACT_OPERATIONS', 'ECONTRACT_GOODS', 'CUSTOMS_REGISTER', 'ECONTRACT_API',
    'MY3_TAX_REPORT', 'CUSTOMS_ACT', 'ECONTRACT_CARD'));
