-- 0.9.237: ОНКМ ↔ банк — фаолият манзиллари (солиқ тўловчи белгилайди). Манзил киритилмаса — барча ОНКМ ва банк
-- савдо тушуми ҳисоблари битта манзил (корхона) бўйича солиштирилади. ОНКМ савдо нуқтаси (salePoint ёки ФМ) → манзил;
-- банк ҳисоби → манзил — nkm_bank_map.point_key = 'S:<манзил>'.
CREATE TABLE IF NOT EXISTS nkm_site_point (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    point_key   TEXT   NOT NULL,
    site        TEXT   NOT NULL,
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, point_key)
);
