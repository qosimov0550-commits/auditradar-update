-- 0.9.474: банк тўловининг «мақсади» (товар ёки харажат тури: Полистирол, Пленка, Электр …) — бухгалтер файлидан (TERMO оборотка).
-- Калит — ўтказма калити (txn_key): кўчирма қайта юкланса ҳам сақланади.
CREATE TABLE IF NOT EXISTS bank_tag (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    txn_key     TEXT   NOT NULL,
    tag         TEXT   NOT NULL,
    src         TEXT   NOT NULL DEFAULT 'excel',
    file_name   TEXT,
    user_id     BIGINT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, txn_key)
);
-- 0.9.474: қўлда боғланган банк тўлови — ўтказма калити бўйича (bank_txn.id кўчирма қайта юкланганда ўзгаради).
ALTER TABLE arap_contract_set ADD COLUMN IF NOT EXISTS txn_key TEXT;
UPDATE arap_contract_set s SET txn_key = b.txn_key FROM bank_txn b
 WHERE s.skey = 'BANK' AND s.txn_key IS NULL AND b.id = s.sid AND b.taxpayer_id = s.taxpayer_id;
