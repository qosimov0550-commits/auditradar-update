-- 0.9.188: ички дебитор-кредитор — давр бошига (OPEN) ва охирига (CLOSE) қолдиқлар, контрагентлар кесимида (1С ёки Excel)
CREATE TABLE IF NOT EXISTS arap_balance (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind        TEXT        NOT NULL CHECK (kind IN ('OPEN', 'CLOSE')),
    as_of       DATE        NOT NULL,
    account     TEXT,
    cp_tin      TEXT,
    cp_name     TEXT,
    debit       NUMERIC(20,2) NOT NULL DEFAULT 0,
    credit      NUMERIC(20,2) NOT NULL DEFAULT 0,
    by_name     BOOLEAN     NOT NULL DEFAULT FALSE,
    file_name   TEXT,
    user_id     BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_arap_balance ON arap_balance(taxpayer_id, kind, as_of);
