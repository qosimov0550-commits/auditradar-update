-- КЛС: солиқ даврининг ойи (мазмундаги «за N м./кв.» бўйича; тўлов ва пеняда — операция ойи).
ALTER TABLE tax_ledger_row ADD COLUMN IF NOT EXISTS tax_month INTEGER;
