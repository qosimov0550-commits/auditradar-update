-- Онлайн-НКМ: чек қаторининг қўшимча майдонлари (сайтдаги маҳсулот ID ва б.) ва сайт кўрсатган чеклар сони (тўлиқ юкланганини текшириш)
ALTER TABLE nkm_item ADD COLUMN IF NOT EXISTS extra JSONB;
ALTER TABLE nkm_month ADD COLUMN IF NOT EXISTS site_total INT;
