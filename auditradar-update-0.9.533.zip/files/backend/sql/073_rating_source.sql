-- Барқарорлик рейтинги: бирламчи манба — Савдо-саноат палатаси очиқ сервиси (рейтинг ва балл, сервер ҳар куни олади);
-- гуруҳ ва мезонлар бўйича батафсил маълумот — my.soliq.uz (ЭРИ йиғишида кенгайтма)
ALTER TABLE client_rating ADD COLUMN IF NOT EXISTS source     TEXT;          -- chamber | my3
ALTER TABLE client_rating ADD COLUMN IF NOT EXISTS chamber_at TIMESTAMPTZ;
ALTER TABLE client_rating ADD COLUMN IF NOT EXISTS my3_at     TIMESTAMPTZ;
UPDATE client_rating SET source='my3', my3_at=fetched_at WHERE source IS NULL;
