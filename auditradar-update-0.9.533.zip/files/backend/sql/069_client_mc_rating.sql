-- Соҳавий қурилиш-пудрат ва лойиҳа-қидирув ташкилотлари рейтинги (reyting.mc.uz, ВМҚ-699 09.11.2020) — очиқ маълумот
CREATE TABLE IF NOT EXISTS client_mc_rating (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    category    SMALLINT NOT NULL,      -- reyting.mc.uz/ratings/{category}/{СТИР}: 0 умумқурилиш-ижтимоий, 1 мелиорация, 2 автомобиль йўллари, 3 лойиҳа
    as_of       DATE NOT NULL,
    grade       TEXT,
    score       NUMERIC(12,6),
    region      TEXT,
    details     JSONB,                  -- [{source, name, value, ball, max}]
    url         TEXT,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, category, as_of)
);
-- охирги текширув (топилмаган мижозлар ойда бир марта қайта текширилади)
CREATE TABLE IF NOT EXISTS client_mc_check (
    taxpayer_id BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    checked_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    found       INT NOT NULL DEFAULT 0
);
