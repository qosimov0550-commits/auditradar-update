-- 0.9.154: биржа (client.uzex.uz) шахсий ҳисоб кўчирмаси — «Историческая выписка из лицевого счёта клиента».
CREATE TABLE IF NOT EXISTS exchange_account (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    platform_tin TEXT   NOT NULL,
    account_no   TEXT   NOT NULL,              -- шахсий ҳисоб (ИНП), масалан 747690
    bank_info    TEXT,                         -- биржанинг ҳисоб-китоб ҳисоби ва валюта
    currency     TEXT   NOT NULL DEFAULT 'UZS',
    period_from  DATE,
    period_to    DATE,
    opening      NUMERIC(20,2),
    closing      NUMERIC(20,2),
    file_name    TEXT,
    source       TEXT   NOT NULL DEFAULT 'FILE', -- FILE | COLLECT
    loaded_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, platform_tin, account_no, currency)
);
CREATE TABLE IF NOT EXISTS exchange_txn (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    platform_tin TEXT   NOT NULL,
    account_no   TEXT   NOT NULL,
    currency     TEXT   NOT NULL DEFAULT 'UZS',
    txn_no       TEXT,
    op_date      DATE   NOT NULL,
    comment      TEXT,
    details      TEXT,
    bk1          TEXT,
    bk2          TEXT,
    debit        NUMERIC(20,2) NOT NULL DEFAULT 0,
    credit       NUMERIC(20,2) NOT NULL DEFAULT 0,
    contract     TEXT,
    kind         TEXT   NOT NULL,              -- DEPOSIT | WITHDRAW | FEE | DEAL | PENALTY | OTHER
    deal_no      TEXT,
    cp_tin       TEXT,
    cp_name      TEXT,
    doc_no       TEXT,
    doc_date     DATE
);
CREATE INDEX IF NOT EXISTS ix_exchange_txn_tp ON exchange_txn(taxpayer_id, platform_tin, op_date);
CREATE UNIQUE INDEX IF NOT EXISTS ux_exchange_txn ON exchange_txn(taxpayer_id, platform_tin, account_no, currency, txn_no, kind, debit, credit)
    WHERE txn_no IS NOT NULL;
