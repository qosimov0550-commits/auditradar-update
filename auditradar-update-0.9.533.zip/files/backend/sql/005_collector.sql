-- Chrome кенгайтмаси (йиғувчи) учун калитлар ва йиғиш сессиялари

CREATE TABLE api_token (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT       NOT NULL REFERENCES app_user(id),
    token_hash      TEXT         NOT NULL UNIQUE,      -- калитнинг ўзи сақланмайди, фақат SHA-256
    label           TEXT         NOT NULL DEFAULT 'chrome',
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    last_used_at    TIMESTAMPTZ,
    revoked         BOOLEAN      NOT NULL DEFAULT FALSE
);

CREATE TABLE collect_run (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT       NOT NULL REFERENCES taxpayer(id),
    user_id         BIGINT       REFERENCES app_user(id),
    source          TEXT         NOT NULL DEFAULT 'my3',
    started_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    finished_at     TIMESTAMPTZ,
    status          TEXT         NOT NULL DEFAULT 'RUNNING',   -- RUNNING, DONE, FAILED
    summary         JSONB        NOT NULL DEFAULT '{}'
);
CREATE INDEX collect_run_tp ON collect_run(taxpayer_id, started_at DESC);
