-- 0.9.75: my.soliq.uz «Кунлик ҳисобот → Фискал модул рақами» (cashregister-reports-api/reports/get-ofd-terminal-reports):
-- модул × ой бўйича жами суммалар. Чеклар фақат суммаси бор модул-ойлар учун сўралади; суммалар назорат учун сақланади.
CREATE TABLE IF NOT EXISTS nkm_report (
    taxpayer_id  BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    check_type   VARCHAR(30) NOT NULL,          -- NKM_CHECK | MARKETPLACE_CHECK | TAXI_CHECK
    commission   BOOLEAN     NOT NULL DEFAULT FALSE,
    y            SMALLINT    NOT NULL,
    m            SMALLINT    NOT NULL,
    terminal_id  VARCHAR(40) NOT NULL,          -- '*' — шу ой ҳисоботи олинганлиги белгиси (модуллар бўлмаса ҳам)
    total        NUMERIC(20,2), cash NUMERIC(20,2), card NUMERIC(20,2), vat NUMERIC(20,2),
    refund_total NUMERIC(20,2), refund_vat NUMERIC(20,2), commission_total NUMERIC(20,2),
    fetched_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, check_type, commission, y, m, terminal_id)
);
