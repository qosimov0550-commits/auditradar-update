-- 0.9.171: банк ҳисоби бошланғич қолдиғи қўлда (кўчирмада бўлмаса ёки аудит даври бошига): сана бошидаги қолдиқ.
CREATE TABLE IF NOT EXISTS bank_opening (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    account      TEXT   NOT NULL,
    as_of        DATE   NOT NULL,              -- шу кун бошидаги қолдиқ
    amount       NUMERIC(20,2) NOT NULL,
    note         TEXT,
    user_id      BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, account)
);
