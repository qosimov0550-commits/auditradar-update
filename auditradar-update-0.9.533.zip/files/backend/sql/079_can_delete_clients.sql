-- 0.9.68: мижозни ўчириш ҳуқуқи (админ аудиторга беради); ўчириш журнали audit_log да қолади
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS can_delete_clients BOOLEAN NOT NULL DEFAULT FALSE;
