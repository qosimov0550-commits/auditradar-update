-- Фақат имзоланган ва имзоланиши кутилаётган ЭҲФлар сақланади: ҳақиқий эмас (not_real),
-- бекор қилинган (аннулирован) ва рад этилган ЭҲФлар ҳисобга олинмайди.
UPDATE esf SET corrected_esf_id = NULL
 WHERE corrected_esf_id IN (SELECT id FROM esf WHERE status NOT IN ('ACCEPTED', 'PENDING'));
DELETE FROM esf WHERE status NOT IN ('ACCEPTED', 'PENDING');
UPDATE finding SET is_active = FALSE WHERE rule_code = 'ESF_IN_NOT_REAL';
