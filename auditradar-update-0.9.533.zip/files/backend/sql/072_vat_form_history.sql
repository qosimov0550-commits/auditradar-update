-- ҚҚС шакллари тарихи: мазмун хеши (бир хил шакл қайта сақланмайди), охирги текширув вақти, олдинги шаклдан фарқ
ALTER TABLE vat_return ADD COLUMN IF NOT EXISTS content_hash TEXT;
ALTER TABLE vat_return ADD COLUMN IF NOT EXISTS checked_at   TIMESTAMPTZ;
ALTER TABLE vat_return ADD COLUMN IF NOT EXISTS diff         JSONB;
CREATE INDEX IF NOT EXISTS ix_vat_return_period ON vat_return(taxpayer_id, variant, period_year, period_month);
-- кенгайтма ҳар йиғишда шунча эски ойни навбат билан қайта текширади (сабаби бор ойлардан ташқари)
INSERT INTO app_setting(key, value) VALUES ('forms.rotate_per_run', '3') ON CONFLICT (key) DO NOTHING;
INSERT INTO app_setting(key, value) VALUES ('forms.recheck_days', '30') ON CONFLICT (key) DO NOTHING;
-- E-CONTRACT операцияси платформага биринчи марта қачон тушган (эски санали БЮД кечикиб пайдо бўлишини билиш учун)
ALTER TABLE ft_operation ADD COLUMN IF NOT EXISTS first_seen TIMESTAMPTZ;
UPDATE ft_operation o SET first_seen = i.imported_at FROM data_import i WHERE i.id = o.data_import_id AND o.first_seen IS NULL;
ALTER TABLE ft_operation ALTER COLUMN first_seen SET DEFAULT now();
