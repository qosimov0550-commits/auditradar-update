-- Билдиришномалар: янгиланишлар, эълонлар, муҳим ҳодисалар (10.10.2026)
CREATE TABLE IF NOT EXISTS notification (
    id              BIGSERIAL PRIMARY KEY,
    kind            VARCHAR(24)  NOT NULL,                 -- announce | update | update_ready | collect | findings | control | backup | extension
    level           VARCHAR(10)  NOT NULL DEFAULT 'info' CHECK (level IN ('info', 'important', 'urgent')),
    title           TEXT         NOT NULL,
    body            TEXT,
    link            TEXT,                                  -- платформа ичидаги йўл (/clients/5 ва ҳ.к.)
    target_role     VARCHAR(16),                           -- NULL — ҳамма роль
    target_user_id  BIGINT       REFERENCES app_user(id) ON DELETE CASCADE,  -- NULL — ҳамма фойдаланувчи
    taxpayer_id     BIGINT       REFERENCES taxpayer(id) ON DELETE CASCADE,
    created_by      BIGINT       REFERENCES app_user(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    expires_at      TIMESTAMPTZ,
    dedup_key       TEXT         UNIQUE                    -- бир ҳодиса учун такрор билдиришнома ёзилмайди
);
CREATE INDEX IF NOT EXISTS ix_notification_created ON notification(created_at DESC);

CREATE TABLE IF NOT EXISTS notification_read (
    notification_id BIGINT       NOT NULL REFERENCES notification(id) ON DELETE CASCADE,
    user_id         BIGINT       NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    read_at         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    PRIMARY KEY (notification_id, user_id)
);

-- эълон ёзиш ҳуқуқи (админдан ташқари фойдаланувчиларга админ беради)
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS can_announce BOOLEAN NOT NULL DEFAULT FALSE;
