-- «Бухгалтер» роли (ҳуқуқлари аудитор билан бир хил; фарқ — фақат номи). 10.10.2026: админ 1, аудитор 3, бухгалтер 6.
DO $$
DECLARE c text;
BEGIN
  FOR c IN SELECT conname FROM pg_constraint
           WHERE conrelid = 'app_user'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) ILIKE '%role%'
  LOOP
    EXECUTE format('ALTER TABLE app_user DROP CONSTRAINT %I', c);
  END LOOP;
END $$;
ALTER TABLE app_user ADD CONSTRAINT app_user_role_check CHECK (role IN ('admin', 'auditor', 'accountant'));
