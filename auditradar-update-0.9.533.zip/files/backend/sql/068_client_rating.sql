-- Тадбиркорлик субъектининг барқарорлик рейтинги (my.soliq.uz → remotes-services/sustainability-rating), кунлар кесимида тарихи билан
CREATE TABLE IF NOT EXISTS client_rating (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    as_of       DATE NOT NULL,
    grade       TEXT,                 -- AAA … D (ўртача рейтинг)
    score       NUMERIC(6,2),         -- балл (охирги 30 кун ўртачаси)
    daily       NUMERIC(6,2),         -- жами кунлик балл
    groups      JSONB,                -- [{name, kind: general|minus|plus, norm, actual}]
    criteria    JSONB,                -- [{no, name, kind, norm, actual}]
    url         TEXT,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, as_of)
);
