-- Банк таснифи: қатламлар (қўлда тузатиш → контрагент қоидаси → контрагент тарихи → ҳисоб тури + мазмун → мазмун),
-- ишончлилик, кўриб чиқиш ва ойлар бўйича «Қоралама → Кўриб чиқилди → Тасдиқланди»
ALTER TABLE bank_txn ADD COLUMN IF NOT EXISTS txn_key       TEXT;
ALTER TABLE bank_txn ADD COLUMN IF NOT EXISTS source        TEXT NOT NULL DEFAULT 'auto';   -- auto | history | rule | manual | approved
ALTER TABLE bank_txn ADD COLUMN IF NOT EXISTS confidence    TEXT;                          -- high | medium | low
ALTER TABLE bank_txn ADD COLUMN IF NOT EXISTS auto_category TEXT;                          -- таснифлагич таклифи
ALTER TABLE bank_txn ADD COLUMN IF NOT EXISTS k_type        TEXT;                          -- контрагент ҳисобининг баланс коди (5 рақам)
CREATE INDEX IF NOT EXISTS ix_bank_txn_key ON bank_txn(taxpayer_id, txn_key);

-- битта ўтказмани қўлда тузатиш (кўчирма қайта юкланса ҳам сақланади)
CREATE TABLE IF NOT EXISTS bank_override (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    txn_key     TEXT   NOT NULL,
    category    TEXT   NOT NULL,
    kind        TEXT   NOT NULL DEFAULT 'manual' CHECK (kind IN ('manual', 'approved')),
    note        TEXT,
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, txn_key)
);

-- контрагент бўйича қоида («бундан кейин ҳам қўллансин»): СТИР ёки ҳисоб рақам, йўналиш
CREATE TABLE IF NOT EXISTS bank_cp_rule (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    match_type  TEXT   NOT NULL CHECK (match_type IN ('TIN', 'ACCOUNT')),
    match_value TEXT   NOT NULL,
    direction   TEXT   NOT NULL DEFAULT 'ANY' CHECK (direction IN ('IN', 'OUT', 'ANY')),
    category    TEXT   NOT NULL,
    note        TEXT,
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, match_type, match_value, direction)
);

CREATE TABLE IF NOT EXISTS bank_period (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    y           INT    NOT NULL,
    m           INT    NOT NULL,
    status      TEXT   NOT NULL CHECK (status IN ('DRAFT', 'REVIEWED', 'APPROVED')),
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    changed_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, y, m)
);
