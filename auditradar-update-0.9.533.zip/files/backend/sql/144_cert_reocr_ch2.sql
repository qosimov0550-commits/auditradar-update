-- 0.9.291: Швейцария (Windows OCR: UlD/lDE ёрлиқлари, «Januar\nan. 2026») — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
