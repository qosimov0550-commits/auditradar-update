-- Онлайн-НКМ: катта ойлар (ўн минглаб чек) бир йиғишда тугамаса — қаерда тўхтагани сақланади ва кейинги йиғиш шу жойдан давом этади
CREATE TABLE IF NOT EXISTS nkm_partial (
    taxpayer_id INT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    terminal_id TEXT NOT NULL,
    y           INT  NOT NULL,
    m           INT  NOT NULL,
    subtype     TEXT NOT NULL,
    page        INT  NOT NULL,          -- сайтдан навбатдаги сўраладиган саҳифа (20 тадан)
    total       INT,                    -- сайт кўрсатган жами чек (totalElements) — ўзгарса, ой бошидан олинади
    received    INT  NOT NULL DEFAULT 0,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, terminal_id, y, m, subtype)
);
CREATE INDEX IF NOT EXISTS ix_nkm_receipt_no ON nkm_receipt(taxpayer_id, terminal_id, receipt_no);
