-- 0.9.153: биржа ва аукционлар — воситачи платформалар орқали тўланган маблағлар (банк кўчирмасида кўринмайди).
CREATE TABLE IF NOT EXISTS intermediary (
    tin        TEXT PRIMARY KEY,
    name       TEXT NOT NULL,
    kind       TEXT NOT NULL CHECK (kind IN ('EXCHANGE', 'AUCTION', 'TENDER')),
    name_re    TEXT,                       -- кўчирмада СТИР ёзилмаса — контрагент номи бўйича
    builtin    BOOLEAN NOT NULL DEFAULT FALSE
);
INSERT INTO intermediary(tin, name, kind, name_re, builtin) VALUES
 ('200933985', 'Ўзбекистон Республикаси товар-хомашё биржаси (УзРТСБ)', 'EXCHANGE', 'РТСБ|RTSB|РТХБ|RTXB|товарно.?сырьев|tovar.?xom', TRUE),
 ('306712636', '«HAYOT BIRJA» АЖ', 'EXCHANGE', 'hayot\s*birj|ҳаёт\s*бирж|хаёт\s*бирж', TRUE),
 ('305004780', 'Электрон онлайн-аукционларни ташкил этиш АЖ (E-auksion)', 'AUCTION', 'аукционлар.{0,20}ташкил|auksionlarni|e-?auksion', TRUE),
 ('307442330', 'Электрон кооперация портали', 'TENDER', 'кооперац.{0,10}портал|kooperats.{0,10}portal', TRUE),
 ('307145565', 'Қурилиш соҳасида АКТ маркази (тендер платформаси)', 'TENDER', 'qurilish\s+sohasida\s+axborot|курилиш\s+сохасида\s+ахборот', TRUE)
ON CONFLICT (tin) DO NOTHING;

CREATE TABLE IF NOT EXISTS exchange_settle (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    platform_tin TEXT   NOT NULL,
    cp_tin       TEXT   NOT NULL,          -- етказиб берувчи (биржа уни тўлаган)
    cp_name      TEXT,
    esf_id       BIGINT REFERENCES esf(id) ON DELETE CASCADE,
    amount       NUMERIC(20,2) NOT NULL CHECK (amount > 0),
    op_date      DATE   NOT NULL,
    deal_no      TEXT,
    source       TEXT   NOT NULL CHECK (source IN ('AUTO', 'MANUAL')),
    status       TEXT   NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'REJECTED', 'CONFIRMED')),
    basis        TEXT,                     -- автомат ёпиш асоси
    note         TEXT,
    created_by   BIGINT REFERENCES app_user(id),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_exchange_settle_tp ON exchange_settle(taxpayer_id, status);
CREATE UNIQUE INDEX IF NOT EXISTS ux_exchange_settle_auto ON exchange_settle(taxpayer_id, esf_id) WHERE source = 'AUTO';
