-- 0.9.306: Didox «Кенгайтирилган реестр» (Excel) — ҳужжатлар товар қаторлари билан: шартномалар (маҳсулот, МХИК, миқдор,
-- нарх) ва ҳисоб-фактуралар. Олинган аванс бўйича ЭҲФ таклифи (шартнома қолдиғи, омбор, таннарх) учун.
CREATE TABLE IF NOT EXISTS didox_doc_line (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    didox_id      TEXT   NOT NULL,
    roaming_id    TEXT,
    direction     TEXT,              -- OUT | IN
    status        TEXT,
    doc_type      TEXT,
    subtype       TEXT,
    doc_no        TEXT,
    doc_date      DATE,
    contract_no   TEXT,
    contract_date DATE,
    cp_tin        TEXT,
    cp_name       TEXT,
    row_no        INTEGER,
    item_name     TEXT,
    ikpu_code     TEXT,
    ikpu_name     TEXT,
    unit          TEXT,
    qty           NUMERIC(24,6),
    price         NUMERIC(24,4),
    net           NUMERIC(20,2),
    vat_rate      NUMERIC(6,2),
    vat           NUMERIC(20,2),
    total         NUMERIC(20,2),
    origin        TEXT,
    file_name     TEXT,
    uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_didox_doc_line ON didox_doc_line(taxpayer_id, cp_tin);
CREATE INDEX IF NOT EXISTS ix_didox_doc_line_id ON didox_doc_line(taxpayer_id, didox_id);
