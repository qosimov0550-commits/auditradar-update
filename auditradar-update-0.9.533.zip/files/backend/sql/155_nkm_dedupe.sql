-- 0.9.333: Онлайн-НКМ — эҳтиёт чораси: саҳифалаб йиғишда (жорий ой, янги чеклар қўшилиб саҳифалар сурилганда) бир чек икки
-- марта ёзилиши мумкин. Бир ФМ, бир рақам, бир тур ва бир вақтдаги чек — битта; ортиқчалари (товар қаторлари билан) ўчирилади.
DELETE FROM nkm_receipt r USING nkm_receipt d
 WHERE r.taxpayer_id = d.taxpayer_id AND r.terminal_id = d.terminal_id AND r.receipt_no = d.receipt_no
   AND r.subtype = d.subtype AND r.paid_at = d.paid_at AND r.receipt_no <> '?' AND r.id > d.id;
