-- 0.9.307: чиқувчи ЭҲФ қораламасини new.soliqservis.uz «Сақланганлар» бўлимига юклаш (кенгайтма, мижоз ЭРИси билан кирилган
-- сессияда; фақат қоралама — POST /api/factura {dataJson}; имзолаш/жўнатиш — бухгалтернинг ўзи).
ALTER TABLE outdoc ADD COLUMN IF NOT EXISTS soliq_state TEXT;        -- QUEUED | SAVED | ERROR
ALTER TABLE outdoc ADD COLUMN IF NOT EXISTS soliq_id TEXT;
ALTER TABLE outdoc ADD COLUMN IF NOT EXISTS soliq_at TIMESTAMPTZ;
ALTER TABLE outdoc ADD COLUMN IF NOT EXISTS soliq_error TEXT;
