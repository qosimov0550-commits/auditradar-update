-- E-CONTRACT ташқи API (расмий): мижоз кабинетида яратилган API фойдаланувчиси билан сервер маълумотни ўзи олади.
CREATE TABLE ft_api_credential (
    taxpayer_id     BIGINT      PRIMARY KEY REFERENCES taxpayer(id),
    host            TEXT        NOT NULL DEFAULT 'https://contract.customs.uz',
    username        TEXT        NOT NULL,
    password_enc    TEXT        NOT NULL,       -- платформа калити билан шифрланган
    ip              TEXT,                       -- E-CONTRACT да рўйхатга олинган IP
    date_from       DATE,                       -- шартномалар рўйхати қайси санадан олинади
    last_sync_at    TIMESTAMPTZ,
    last_status     TEXT,                       -- OK / ERROR
    last_message    TEXT,
    updated_by      BIGINT      REFERENCES app_user(id),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Хом жавоблар: майдонлар тузилиши ҳали расмий ҳужжатда йўқ, шунинг учун ҳар бир жавоб сақланади
CREATE TABLE ft_api_raw (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    endpoint        TEXT        NOT NULL,       -- list / card / journal / declaration / specification / notify
    idn             VARCHAR(40),
    page            INTEGER,
    payload         JSONB       NOT NULL,
    fetched_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_ft_api_raw ON ft_api_raw(taxpayer_id, endpoint, idn, fetched_at DESC);

ALTER TABLE data_import DROP CONSTRAINT IF EXISTS data_import_source_check;
ALTER TABLE data_import ADD CONSTRAINT data_import_source_check CHECK (source IN (
    'MY3_VAT_SUBMITTED', 'MY3_VAT_GENERATED', 'ESF_SOLIQSERVIS', 'ESF_FAKTURA', 'ESF_OTHER', 'MY3_KKM',
    'ECONTRACT_CONTRACTS', 'ECONTRACT_OPERATIONS', 'ECONTRACT_GOODS', 'CUSTOMS_REGISTER', 'ECONTRACT_API'));
