-- 0.9.211: my.mehnat.uz (Ягона миллий меҳнат тизими) — меҳнат шартномалари ва ФҲШ шартномалари; солиқ иш ҳақи ҳисоботи билан солиштириш.
-- ЖШШИР очиқ сақланмайди: pin_hash = HMAC(сервер калити, ЖШШИР). Паспорт, телефон, маош олинмайди.
CREATE TABLE IF NOT EXISTS mehnat_contract (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    src           TEXT    NOT NULL,          -- ACTIVE | ARCHIVE | GPH_ACTIVE | GPH_HISTORY
    ext_id        TEXT,
    pin_hash      TEXT,
    fio           TEXT,
    position      TEXT,
    structure     TEXT,
    work_type     SMALLINT,                  -- сайт: 2 — ўриндошлик, бошқаси — асосий
    rate          NUMERIC(6,3),
    contract_no   TEXT,
    contract_date DATE,
    date_start    DATE,
    date_stop     DATE,
    loaded_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_mehnat_contract ON mehnat_contract(taxpayer_id, pin_hash);

-- Сайтнинг ўз солиштирмаси (ой бўйича): HAS_NOT_YAMMT — солиқда бор, ЯММТда йўқ; NOT_SOLIQ — ЯММТда бор, солиқда йўқ
CREATE TABLE IF NOT EXISTS mehnat_site_check (
    taxpayer_id   BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    y             SMALLINT NOT NULL,
    m             SMALLINT NOT NULL,
    kind          TEXT    NOT NULL,
    n             INTEGER NOT NULL DEFAULT 0,
    rows          JSONB   NOT NULL DEFAULT '[]',
    loaded_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, y, m, kind)
);

CREATE TABLE IF NOT EXISTS mehnat_load (
    taxpayer_id   BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    loaded_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    active_n      INTEGER, archive_n INTEGER, gph_n INTEGER
);
