-- 0.9.450: ЭҲФ / БЮД харидларидан автомат шаклланадиган асосий воситалар — бухгалтер қарорлари (тасдиқ, ишга тушириш санаси, гуруҳ, ставка).
CREATE TABLE IF NOT EXISTS fa_obj (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    src          TEXT   NOT NULL CHECK (src IN ('ESF','CUSTOMS')),
    src_key      TEXT   NOT NULL,                 -- ESF: esf_item.id; CUSTOMS: БЮД рақами|сана|қатор
    status       TEXT   CHECK (status IN ('OK','NO')),   -- NULL — қарор йўқ (омбор туркуми бўйича)
    start_date   DATE,                            -- ишга тушириш санаси (NULL — ҳужжат санаси)
    grp          TEXT,                            -- амортизация гуруҳи (NULL — автомат)
    rate         NUMERIC(8,4),                    -- йиллик ставка, % (NULL — гуруҳ ставкаси)
    user_id      BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, src, src_key)
);
ALTER TABLE fa_policy ADD COLUMN IF NOT EXISTS rates JSONB;   -- {гуруҳ: ставка} — мижоз ҳисоб сиёсати (йўқлари — Солиқ кодекси 306-м. чегараси)
