-- 0.9.281: резидентлик сертификатидан ўқилган эгаси номи ва давлат (Contracting state) — сертификат айнан шу хорижий
-- ҳамкорга ва шу йилга тегишлилигини текшириш учун (тўлиқ матн сақланмайди)
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_name TEXT;
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_country TEXT;
-- янги ўқиш қоидалари билан ҳаммаси қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
