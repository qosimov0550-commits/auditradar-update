-- Солиқ ставкалари ва кўрсаткичлар (санадан бошлаб амал қилади) — «Норматив ҳужжатлар» → «Солиқ ставкалари»
CREATE TABLE IF NOT EXISTS tax_rate (
    code        TEXT NOT NULL,
    valid_from  DATE NOT NULL,
    value       NUMERIC(18,4) NOT NULL,
    note        TEXT,
    source      TEXT NOT NULL DEFAULT 'manual',   -- seed — платформадаги бошланғич қиймат, manual — администратор
    updated_by  BIGINT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (code, valid_from)
);
-- Платформа кодида шу пайтгача ишлатилган қийматлар (ўзгаришсиз кўчирилди)
INSERT INTO tax_rate(code, valid_from, value, note, source) VALUES
  ('vat',          '2019-10-01', 15, 'Платформада 2023 йилгача ишлатилган ставка', 'seed'),
  ('vat',          '2023-01-01', 12, NULL, 'seed'),
  ('pit',          '2022-01-01', 12, NULL, 'seed'),
  ('social',       '2022-01-01', 12, NULL, 'seed'),
  ('profit',       '2022-01-01', 15, 'Умумий ставка; банклар ва айрим фаолият турлари учун бошқа ставка — мижоз созламасида', 'seed'),
  ('nonres_int',   '2022-01-01', 10, NULL, 'seed'),
  ('nonres_other', '2022-01-01', 20, NULL, 'seed')
ON CONFLICT DO NOTHING;
