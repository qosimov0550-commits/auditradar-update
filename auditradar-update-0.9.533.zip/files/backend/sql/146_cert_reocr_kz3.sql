-- 0.9.293: ёпилмаган қўштирноқдаги ном (Қозоғистон) — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
