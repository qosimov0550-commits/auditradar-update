-- 0.9.295: Беларусь (русча OCR) — справка рақами ва ном — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
