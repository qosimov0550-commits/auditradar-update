-- Ташқи савдо: E-CONTRACT (contract.customs.uz, ЕЭИСВО) ҳисоботлари — шартномалар, операциялар, БЮДлар.
-- Манба: «Ҳисоботлар» бўлимидан юклаб олинган Excel файллар (Реестр контрактов, Отчет по операциям,
-- БЮД бўйича товарлар ҳисоботи). Кейинчалик кенгайтма орқали тўғридан-тўғри олинади.

ALTER TABLE data_import DROP CONSTRAINT IF EXISTS data_import_source_check;
ALTER TABLE data_import ADD CONSTRAINT data_import_source_check CHECK (source IN (
    'MY3_VAT_SUBMITTED', 'MY3_VAT_GENERATED', 'ESF_SOLIQSERVIS', 'ESF_FAKTURA', 'ESF_OTHER', 'MY3_KKM',
    'ECONTRACT_CONTRACTS', 'ECONTRACT_OPERATIONS', 'ECONTRACT_GOODS'));

-- Ташқи савдо шартномалари (ИДН бўйича битта ёзув; ҳар юклашда янгиланади)
CREATE TABLE ft_contract (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    idn             VARCHAR(40) NOT NULL,
    kind            VARCHAR(10) NOT NULL CHECK (kind IN ('IMPORT', 'EXPORT')),
    bank_mfo        VARCHAR(10),
    bank_name       TEXT,
    contract_no     TEXT,
    contract_date   DATE,
    partner_name    TEXT,
    partner_country TEXT,
    subject         TEXT,
    currency1       VARCHAR(5),
    amount1         NUMERIC(20,2),
    paid1           NUMERIC(20,2),
    shipped1        NUMERIC(20,2),
    debtor1         NUMERIC(20,2),
    debtor_90       NUMERIC(20,2),      -- дебиторлик: 90 кунгача
    debtor_150      NUMERIC(20,2),      -- 91–150
    debtor_180      NUMERIC(20,2),      -- 151–180
    debtor_over180  NUMERIC(20,2),      -- 180 кундан ортиқ (муддати ўтган)
    creditor1       NUMERIC(20,2),
    creditor_180    NUMERIC(20,2),
    creditor_365    NUMERIC(20,2),
    creditor_over365 NUMERIC(20,2),
    currency2       VARCHAR(5),
    amount2         NUMERIC(20,2),
    status          TEXT,
    delivery_basis  TEXT,
    data_import_id  BIGINT      REFERENCES data_import(id),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, idn)
);

-- Операциялар журнали (ҳар қатор — битта ҳаракат: БЮД расмийлаштириш, тўлов, қайтариш...)
CREATE TABLE ft_operation (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    idn             VARCHAR(40) NOT NULL,
    kind            VARCHAR(10) NOT NULL CHECK (kind IN ('IMPORT', 'EXPORT')),
    op_type         TEXT        NOT NULL,       -- «Оформление ИМ40», «Оплата по контракту (Импорт)»...
    regime          VARCHAR(10),                -- ИМ40, ЭК10... (расмийлаштиришда)
    sys_no          TEXT,                       -- тизимдаги рақами (БЮД: ПППППОО/КК/ЙЙНННННН)
    abs_no          TEXT,                       -- АБСдаги рақами (тўлов ҳужжати)
    op_date         DATE,
    decl_post       VARCHAR(10),                -- БЮД: пост
    decl_no         INTEGER,                    -- БЮД: рақами (реестрдаги рақам билан мос)
    amount1         NUMERIC(20,2),
    amount2         NUMERIC(20,2),
    currency1       VARCHAR(5),
    debtor1         NUMERIC(20,2),
    creditor1       NUMERIC(20,2),
    overdue_debtor_usd   NUMERIC(20,2),
    overdue_creditor_usd NUMERIC(20,2),
    partner_name    TEXT,
    partner_country TEXT,
    row_key         VARCHAR(64) NOT NULL,       -- такрорни олдини олиш учун (idn+тур+рақам+сана+сумма)
    data_import_id  BIGINT      REFERENCES data_import(id),
    UNIQUE (taxpayer_id, row_key)
);
CREATE INDEX ix_ft_operation_decl ON ft_operation(taxpayer_id, decl_no, op_date);
CREATE INDEX ix_ft_operation_idn ON ft_operation(taxpayer_id, idn);

-- БЮД товар қаторлари («БЮД бўйича товарлар ҳисоботи» дан)
CREATE TABLE ft_declaration_goods (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    idn             VARCHAR(40),
    kind            VARCHAR(10) CHECK (kind IN ('IMPORT', 'EXPORT')),
    regime          VARCHAR(10),
    decl_full_no    TEXT,
    decl_post       VARCHAR(10),
    decl_date       DATE,
    decl_no         INTEGER,
    line_no         INTEGER,
    hs_code         VARCHAR(12),                -- ТИФ ТН
    goods_name      TEXT,
    origin_country  TEXT,
    qty             NUMERIC(20,4),
    unit            TEXT,
    net_kg          NUMERIC(20,3),
    invoice_value   NUMERIC(20,2),
    customs_value   NUMERIC(20,2),
    currency        VARCHAR(5),
    rate            NUMERIC(20,4),
    customs_value_uzs NUMERIC(20,2),
    duty_uzs        NUMERIC(20,2),
    excise_uzs      NUMERIC(20,2),
    vat_uzs         NUMERIC(20,2),
    raw             JSONB,
    row_key         VARCHAR(64) NOT NULL,
    data_import_id  BIGINT      REFERENCES data_import(id),
    UNIQUE (taxpayer_id, row_key)
);
CREATE INDEX ix_ft_goods_decl ON ft_declaration_goods(taxpayer_id, decl_no, decl_date);

-- Расмийлаштирилган БЮДлар (операциялардан): битта БЮД — битта қатор.
-- Шартнома банкдан банкка ўтказилганда («Переведенный») бир БЮД бир нечта ИДН остида такрорланади —
-- шунинг учун сумма SUM эмас, MAX билан олинади, ИДНлар рўйхат қилинади.
CREATE VIEW v_ft_declaration AS
SELECT taxpayer_id, kind, regime, decl_post, decl_no, op_date AS decl_date, sys_no,
       string_agg(DISTINCT idn, ', ') AS idn, MAX(partner_name) AS partner_name, MAX(currency1) AS currency1,
       MAX(amount1) AS amount1, COUNT(*) AS n_rows,
       bool_or(position('Переоформ' in op_type) = 1) AS reissued
FROM ft_operation
WHERE decl_no IS NOT NULL
GROUP BY taxpayer_id, kind, regime, decl_post, decl_no, op_date, sys_no;
