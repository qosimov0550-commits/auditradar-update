-- 0.9.258: «Банк ТАХЛИЛ» Excel қайта юкланганда аудитор/бухгалтер тузатишлари (таҳлил, СТИР, контрагент номи, ФИШ, ЖШШИР)
ALTER TABLE bank_override ALTER COLUMN category DROP NOT NULL;
ALTER TABLE bank_override DROP CONSTRAINT IF EXISTS bank_override_kind_check;
ALTER TABLE bank_override ADD CONSTRAINT bank_override_kind_check CHECK (kind IN ('manual', 'approved', 'excel'));
ALTER TABLE bank_override ADD COLUMN IF NOT EXISTS t_tin  TEXT;
ALTER TABLE bank_override ADD COLUMN IF NOT EXISTS t_name TEXT;
ALTER TABLE bank_override ADD COLUMN IF NOT EXISTS fish   TEXT;
ALTER TABLE bank_override ADD COLUMN IF NOT EXISTS pinfl  TEXT;
ALTER TABLE bank_txn ADD COLUMN IF NOT EXISTS fish  TEXT;
ALTER TABLE bank_txn ADD COLUMN IF NOT EXISTS pinfl TEXT;
