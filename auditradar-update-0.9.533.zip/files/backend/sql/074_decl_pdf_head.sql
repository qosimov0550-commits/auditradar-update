-- БЮД PDF: сарлавҳа маълумотлари — хорижий ҳамкор (2/8-графа), 24-графа (битим хусусияти), 44-графа (шартнома, инвойс),
-- C-графа (шартнома ИДНи), декларация ҳолати ва чиқаришга рухсат санаси. Шахсий маълумотлар (50, 54-графа) олинмайди.
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS partner_name    TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS partner_addr    TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS partner_country TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS deal_code       TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS contract_no     TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS contract_date   DATE;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS invoice_no      TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS invoice_date    DATE;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS idn             TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS status          TEXT;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS released_at     DATE;
ALTER TABLE ft_decl_pdf ADD COLUMN IF NOT EXISTS total_invoice   NUMERIC(20,2);
