-- =====================================================================
-- Аудит хатарлари платформаси — маълумотлар базаси схемаси
-- 1-қисм: ҚҚС ҳисоботлари, электрон ҳисобварақ-фактуралар (ЭҲФ),
--         онлайн назорат-касса машиналари (НКМ) маълумотлари
-- СУБД: PostgreSQL 15+
-- Версия: 0.3 (реал my3.soliq.uz ва Солиқсервис экспорт файлларига мосланган)
-- Муҳим: кунлик солиштиришлар тўғри бўлиши учун базанинг вақт минтақаси
--        Тошкент вақтида бўлиши шарт:
--        ALTER DATABASE <база_номи> SET timezone = 'Asia/Tashkent';
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0. Умумий маълумотномалар
-- ---------------------------------------------------------------------

-- Солиқ тўловчилар (аудит қилинаётган субъектлар)
CREATE TABLE taxpayer (
    id              BIGSERIAL PRIMARY KEY,
    tin             VARCHAR(9)   NOT NULL UNIQUE,       -- СТИР
    name            TEXT         NOT NULL,
    tax_regime      VARCHAR(20)  NOT NULL               -- 'QQS' (ҚҚС тўловчи), 'AOS' (айланмадан солиқ)
                    CHECK (tax_regime IN ('QQS', 'AOS', 'OTHER')),
    vat_cert_status VARCHAR(20),                        -- ҚҚС гувоҳномаси ҳолати
    oked            VARCHAR(10),                        -- асосий фаолият тури
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

-- Контрагентлар (юридик шахс — СТИР, жисмоний шахс — ЖШШИР)
CREATE TABLE counterparty (
    id              BIGSERIAL PRIMARY KEY,
    tin             VARCHAR(9),                         -- СТИР
    pinfl           VARCHAR(14),                        -- ЖШШИР
    name            TEXT         NOT NULL,
    is_vat_payer    BOOLEAN,
    risk_flags      JSONB        NOT NULL DEFAULT '{}', -- "шубҳали", "қора рўйхат", қарздор ва ҳ.к.
    CHECK (tin IS NOT NULL OR pinfl IS NOT NULL)
);
CREATE UNIQUE INDEX ux_counterparty_tin   ON counterparty(tin)   WHERE tin   IS NOT NULL;
CREATE UNIQUE INDEX ux_counterparty_pinfl ON counterparty(pinfl) WHERE pinfl IS NOT NULL;

-- Шартномалар
CREATE TABLE contract (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT  NOT NULL REFERENCES taxpayer(id),
    counterparty_id BIGINT  REFERENCES counterparty(id),
    contract_no     TEXT    NOT NULL,
    contract_date   DATE    NOT NULL,
    UNIQUE (taxpayer_id, counterparty_id, contract_no, contract_date)
);

-- Маҳсулот ва хизматларнинг ягона идентификация каталоги (МХИК / ИКПУ)
CREATE TABLE ikpu (
    code            VARCHAR(17) PRIMARY KEY,
    name            TEXT,
    requires_marking BOOLEAN    NOT NULL DEFAULT FALSE
);

-- Ўлчов бирликлари
CREATE TABLE unit (
    code            VARCHAR(10) PRIMARY KEY,
    name            TEXT        NOT NULL
);

-- ---------------------------------------------------------------------
-- 1. Маълумот манбалари ва импорт журнали
--    Ҳар бир ёзув қаердан, қачон, ким томонидан юкланганини билиш шарт.
-- ---------------------------------------------------------------------
CREATE TABLE data_import (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    source          VARCHAR(40) NOT NULL CHECK (source IN (
                        'MY3_VAT_SUBMITTED',   -- my3.soliq.uz: топширилган ҚҚС ҳисоботи
                        'MY3_VAT_GENERATED',   -- my3.soliq.uz: қайта шакллантирилган (топширилмаган) ҳисобот
                        'ESF_SOLIQSERVIS',     -- new.soliqservis.uz
                        'ESF_FAKTURA',         -- faktura.uz
                        'ESF_OTHER',
                        'MY3_KKM'              -- my3.soliq.uz: онлайн-НКМ маълумотлари
                    )),
    period_from     DATE,
    period_to       DATE,
    file_name       TEXT,
    file_sha256     VARCHAR(64),                -- айнан бир файл икки марта юкланмаслиги учун
    imported_by     TEXT        NOT NULL,
    imported_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    note            TEXT
);
CREATE UNIQUE INDEX ux_import_file ON data_import(taxpayer_id, source, file_sha256) WHERE file_sha256 IS NOT NULL;

-- ---------------------------------------------------------------------
-- 2. ҚҚС ҳисоботлари (1-вариант: топширилган, 2-вариант: қайта шакллантирилган)
-- ---------------------------------------------------------------------
CREATE TABLE vat_return (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    import_id       BIGINT      NOT NULL REFERENCES data_import(id),
    period_year     SMALLINT    NOT NULL,
    period_month    SMALLINT    NOT NULL CHECK (period_month BETWEEN 1 AND 12),
    variant         VARCHAR(10) NOT NULL CHECK (variant IN ('SUBMITTED', 'GENERATED')),
    report_no       TEXT,                       -- солиқ тизимидаги ҳисобот рақами
    submissions_count SMALLINT,                 -- шу давр учун неча марта топширилган
    form_version    VARCHAR(20),                -- ҳисобот шаклининг версияси (эски/янги шакл)
    correction_no   SMALLINT    NOT NULL DEFAULT 0, -- 0 — дастлабки, 1, 2... — тузатувчи ҳисоботлар
    submitted_at    TIMESTAMPTZ,                -- фақат SUBMITTED учун
    generated_at    TIMESTAMPTZ,                -- фақат GENERATED учун
    is_latest       BOOLEAN     NOT NULL DEFAULT TRUE, -- шу давр учун амалдаги охирги ҳисобот
    UNIQUE (taxpayer_id, period_year, period_month, variant, correction_no)
);

-- Ҳисобот ва иловалар қаторлари (умумий тузилма: шакл ўзгарса ҳам ишлайди)
CREATE TABLE vat_return_line (
    id              BIGSERIAL PRIMARY KEY,
    vat_return_id   BIGINT      NOT NULL REFERENCES vat_return(id) ON DELETE CASCADE,
    appendix_code   VARCHAR(20) NOT NULL,       -- 'MAIN' — асосий шакл, '1', '2', ... — иловалар
    line_code       VARCHAR(20) NOT NULL,       -- қатор коди
    line_name       TEXT,
    turnover        NUMERIC(20,2),              -- айланма (ҚҚСсиз)
    vat_amount      NUMERIC(20,2),              -- ҚҚС суммаси
    extra           JSONB       NOT NULL DEFAULT '{}', -- иловадаги қўшимча устунлар
    UNIQUE (vat_return_id, appendix_code, line_code)
);

-- Иловалардаги рўйхатлар (масалан, ЭҲФлар ёки фискал модуллар рўйхати)
CREATE TABLE vat_return_appendix_row (
    id              BIGSERIAL PRIMARY KEY,
    vat_return_id   BIGINT      NOT NULL REFERENCES vat_return(id) ON DELETE CASCADE,
    appendix_code   VARCHAR(20) NOT NULL,
    row_no          INTEGER     NOT NULL,
    data            JSONB       NOT NULL,       -- реал устунлар аниқланганда алоҳида жадвалга чиқарилади
    UNIQUE (vat_return_id, appendix_code, row_no)
);

-- ҚҚС ҳисоб-китобига 4-илова: 1-жадвал (харид реестри) ва 2-жадвал (сотув реестри)
-- Ҳар бир қатор — битта ҳисобварақ-фактура (ёки "Onlayn NKM" жамланмаси).
CREATE TABLE vat_register_row (
    id                  BIGSERIAL PRIMARY KEY,
    vat_return_id       BIGINT      NOT NULL REFERENCES vat_return(id) ON DELETE CASCADE,
    register            VARCHAR(10) NOT NULL CHECK (register IN ('PURCHASE', 'SALE')),
    row_no              INTEGER     NOT NULL,
    counterparty_tin    VARCHAR(14),            -- СТИР, ЖШШИР ёки чет эл учун шартли код
    counterparty_name   TEXT,
    invoice_no          TEXT,
    invoice_date        DATE,
    net_amount          NUMERIC(20,2),          -- етказиб бериш қиймати (ҚҚСсиз)
    vat_amount          NUMERIC(20,2),
    with_vat            NUMERIC(20,2),          -- фақат сотув реестрида
    nondeductible_net   NUMERIC(20,2),          -- харид: ҳисобга олинмайдиган қиймат
    nondeductible_vat   NUMERIC(20,2),          -- харид: ҳисобга олинмайдиган ҚҚС
    nondeductible_reason SMALLINT,              -- харид: изоҳ коди (1, 2, 4...)
    reimbursable_net    NUMERIC(20,2),          -- сотув: қопланадиган харажатлар
    reimbursable_vat    NUMERIC(20,2),
    is_kkm              BOOLEAN     GENERATED ALWAYS AS (invoice_no = 'Onlayn NKM') STORED,
    UNIQUE (vat_return_id, register, row_no)
);
CREATE INDEX ix_vat_register_key ON vat_register_row(counterparty_tin, invoice_no, invoice_date);

-- Солиштирма жадвал: топширилган ва қайта шакллантирилган ҳисобот
-- Иккала вариантдаги барча қаторлар чиқади: фақат биттасида бор қатор ҳам йўқолмайди.
CREATE VIEW v_vat_return_comparison AS
WITH sub AS (
    SELECT r.taxpayer_id, r.period_year, r.period_month,
           l.appendix_code, l.line_code, l.line_name, l.turnover, l.vat_amount
    FROM vat_return r JOIN vat_return_line l ON l.vat_return_id = r.id
    WHERE r.variant = 'SUBMITTED' AND r.is_latest
), gen AS (
    SELECT r.taxpayer_id, r.period_year, r.period_month,
           l.appendix_code, l.line_code, l.line_name, l.turnover, l.vat_amount
    FROM vat_return r JOIN vat_return_line l ON l.vat_return_id = r.id
    WHERE r.variant = 'GENERATED' AND r.is_latest
)
SELECT
    COALESCE(s.taxpayer_id,   g.taxpayer_id)                   AS taxpayer_id,
    COALESCE(s.period_year,   g.period_year)                   AS period_year,
    COALESCE(s.period_month,  g.period_month)                  AS period_month,
    COALESCE(s.appendix_code, g.appendix_code)                 AS appendix_code,
    COALESCE(s.line_code,     g.line_code)                     AS line_code,
    COALESCE(s.line_name,     g.line_name)                     AS line_name,
    s.turnover                                                 AS submitted_turnover,
    g.turnover                                                 AS generated_turnover,
    COALESCE(g.turnover, 0)   - COALESCE(s.turnover, 0)        AS diff_turnover,
    s.vat_amount                                               AS submitted_vat,
    g.vat_amount                                               AS generated_vat,
    COALESCE(g.vat_amount, 0) - COALESCE(s.vat_amount, 0)      AS diff_vat
FROM sub s
FULL JOIN gen g
  ON  g.taxpayer_id   = s.taxpayer_id
 AND  g.period_year   = s.period_year
 AND  g.period_month  = s.period_month
 AND  g.appendix_code = s.appendix_code
 AND  g.line_code     = s.line_code;

-- Бир давр учун фақат битта амалдаги (охирги) ҳисобот бўлишини кафолатлаш
CREATE UNIQUE INDEX ux_vat_return_latest
    ON vat_return(taxpayer_id, period_year, period_month, variant) WHERE is_latest;

-- ---------------------------------------------------------------------
-- 3. Электрон ҳисобварақ-фактуралар (ЭҲФ)
-- ---------------------------------------------------------------------
CREATE TABLE esf (
    id                  BIGSERIAL PRIMARY KEY,
    taxpayer_id         BIGINT      NOT NULL REFERENCES taxpayer(id),
    import_id           BIGINT      NOT NULL REFERENCES data_import(id),
    direction           VARCHAR(3)  NOT NULL CHECK (direction IN ('OUT', 'IN')), -- чиқим (сотув) / кирим (харид)
    external_id         TEXT,                   -- тизимдаги ноёб идентификатор (ЭҲФ ID)
    esf_no              TEXT        NOT NULL,
    esf_date            DATE        NOT NULL,
    doc_kind            TEXT,                   -- ҳужжат тури (Счет-фактура ва ҳ.к.)
    esf_type            VARCHAR(20) CHECK (esf_type IN (
                            'STANDARD',         -- Стандартный
                            'CORRECTED',        -- Исправленный
                            'ADDITIONAL',       -- Дополнительный
                            'REIMBURSEMENT',    -- Возмещение расходов
                            'OTHER')),
    corrected_esf_id    BIGINT      REFERENCES esf(id), -- тузатувчи ЭҲФ қайси ЭҲФни тузатади
    status              VARCHAR(20) NOT NULL CHECK (status IN (
                            'ACCEPTED',         -- қабул қилинган (Подписан)
                            'PENDING',          -- қабул қилиниши кутилмоқда (Ожидает)
                            'REJECTED',         -- рад этилган
                            'CANCELLED',        -- бекор қилинган
                            'OTHER')),
    status_raw          TEXT,                   -- манбадаги ҳолат матни
    status_date         TIMESTAMPTZ,
    sent_at             TIMESTAMPTZ,            -- юборилган вақт
    risk_level          VARCHAR(10),            -- ЭҲФ хатар даражаси (масалан, "қизил")
    contract_id         BIGINT      REFERENCES contract(id),
    contract_no         TEXT,
    contract_date       DATE,
    counterparty_id     BIGINT      NOT NULL REFERENCES counterparty(id),
    agent_role          VARCHAR(15) CHECK (agent_role IN ('COMMITTENT', 'COMMISSIONER')), -- комитент / комиссионер
    agent_counterparty_id BIGINT    REFERENCES counterparty(id),
    -- Сотувчи ва харидорнинг банк ва филиал реквизитлари (ЭҲФдаги кўринишида)
    seller_tin          VARCHAR(14),
    seller_name         TEXT,
    seller_account      TEXT,
    seller_mfo          TEXT,
    seller_branch_code  TEXT,
    seller_branch_name  TEXT,
    buyer_tin           VARCHAR(14),
    buyer_name          TEXT,
    buyer_account       TEXT,
    buyer_mfo           TEXT,
    buyer_branch_code   TEXT,
    buyer_branch_name   TEXT,
    comment             TEXT,
    -- Қабул қилиш (имзолаш) маълумотлари
    signer_name         TEXT,
    signed_at           TIMESTAMPTZ,
    operator_host       TEXT,                   -- ЭДО оператори (didox.uz, soliqservis.uz ...)
    signer_ip           TEXT,
    total_net           NUMERIC(20,2),
    total_excise        NUMERIC(20,2),
    total_vat           NUMERIC(20,2),
    total_with_vat      NUMERIC(20,2),
    UNIQUE (taxpayer_id, direction, external_id)
);
CREATE INDEX ix_esf_period ON esf(taxpayer_id, esf_date);
CREATE INDEX ix_esf_counterparty ON esf(counterparty_id);

-- ЭҲФ товар (иш, хизмат) қаторлари
CREATE TABLE esf_item (
    id              BIGSERIAL PRIMARY KEY,
    esf_id          BIGINT        NOT NULL REFERENCES esf(id) ON DELETE CASCADE,
    line_no         INTEGER       NOT NULL,
    name            TEXT          NOT NULL,
    ikpu_code       VARCHAR(17),
    ikpu_name       TEXT,                     -- МХИК каталогидаги номи (ЭҲФда кўрсатилгани)
    unit_code       VARCHAR(10),
    unit_name       TEXT,
    quantity        NUMERIC(20,4),
    price           NUMERIC(20,4),
    net_amount      NUMERIC(20,2),            -- соф қиймати (ҚҚСсиз)
    excise_rate     NUMERIC(14,4),            -- фоиз ёки қатъий ставка (сўмда)
    excise_amount   NUMERIC(20,2),
    vat_rate        NUMERIC(5,2),             -- 12, 15 (2022 й.), 0 ёки NULL (ҚҚСсиз)
    vat_amount      NUMERIC(20,2),
    total_with_vat  NUMERIC(20,2),
    origin          TEXT,                     -- товарнинг келиб чиқиши (ўз ишлаб чиқариш, қайта сотиш...)
    UNIQUE (esf_id, line_no)
);
CREATE INDEX ix_esf_item_ikpu ON esf_item(ikpu_code);

-- Маркировка кодлари (бир қаторда бир нечта код бўлиши мумкин)
CREATE TABLE esf_item_marking (
    esf_item_id     BIGINT  NOT NULL REFERENCES esf_item(id) ON DELETE CASCADE,
    marking_code    TEXT    NOT NULL,
    PRIMARY KEY (esf_item_id, marking_code)
);

-- ---------------------------------------------------------------------
-- 4. Онлайн назорат-касса машиналари (НКМ)
-- ---------------------------------------------------------------------

-- Фискал модуллар
CREATE TABLE fiscal_module (
    id              BIGSERIAL PRIMARY KEY,
    taxpayer_id     BIGINT      NOT NULL REFERENCES taxpayer(id),
    fm_number       TEXT        NOT NULL UNIQUE,
    kkm_model       TEXT,
    location        TEXT,
    registered_at   DATE,
    deregistered_at DATE
);

-- Ойлик жамланма (ҚҚС ҳисоботи иловасидаги фискал модуллар рўйхати асосида)
CREATE TABLE kkm_monthly (
    id              BIGSERIAL PRIMARY KEY,
    fiscal_module_id BIGINT     NOT NULL REFERENCES fiscal_module(id),
    import_id       BIGINT      NOT NULL REFERENCES data_import(id),
    period_year     SMALLINT    NOT NULL,
    period_month    SMALLINT    NOT NULL CHECK (period_month BETWEEN 1 AND 12),
    sales_total     NUMERIC(20,2),
    returns_total   NUMERIC(20,2),
    vat_total       NUMERIC(20,2),
    cash_total      NUMERIC(20,2),
    card_total      NUMERIC(20,2),
    receipts_count  INTEGER,
    UNIQUE (fiscal_module_id, period_year, period_month)
);

-- Кунлик жамланма (Z-ҳисобот)
CREATE TABLE kkm_daily (
    id              BIGSERIAL PRIMARY KEY,
    fiscal_module_id BIGINT     NOT NULL REFERENCES fiscal_module(id),
    import_id       BIGINT      NOT NULL REFERENCES data_import(id),
    work_date       DATE        NOT NULL,
    sales_total     NUMERIC(20,2),
    returns_total   NUMERIC(20,2),
    vat_total       NUMERIC(20,2),
    cash_total      NUMERIC(20,2),
    card_total      NUMERIC(20,2),
    receipts_count  INTEGER,
    UNIQUE (fiscal_module_id, work_date)
);

-- Чеклар (чекма-чек)
CREATE TABLE receipt (
    id              BIGSERIAL PRIMARY KEY,
    fiscal_module_id BIGINT     NOT NULL REFERENCES fiscal_module(id),
    import_id       BIGINT      NOT NULL REFERENCES data_import(id),
    receipt_no      TEXT        NOT NULL,
    receipt_at      TIMESTAMPTZ NOT NULL,
    receipt_type    VARCHAR(15) NOT NULL CHECK (receipt_type IN (
                        'SALE',             -- сотув
                        'RETURN',           -- қайтариш
                        'ADVANCE',          -- аванс
                        'CREDIT',           -- кредит / насия
                        'OTHER')),
    status          VARCHAR(15) NOT NULL DEFAULT 'VALID' CHECK (status IN (
                        'VALID',
                        'DAMAGED',          -- шикастланган
                        'CANCELLED')),
    original_receipt_id BIGINT  REFERENCES receipt(id), -- қайтариш чеки қайси чекка тегишли
    total_net       NUMERIC(20,2),
    total_excise    NUMERIC(20,2),
    total_vat       NUMERIC(20,2),
    total_with_vat  NUMERIC(20,2),
    cash_amount     NUMERIC(20,2),
    card_amount     NUMERIC(20,2),
    UNIQUE (fiscal_module_id, receipt_no, receipt_at)
);
CREATE INDEX ix_receipt_date ON receipt(fiscal_module_id, receipt_at);

-- Чек қаторлари
CREATE TABLE receipt_item (
    id              BIGSERIAL PRIMARY KEY,
    receipt_id      BIGINT        NOT NULL REFERENCES receipt(id) ON DELETE CASCADE,
    line_no         INTEGER       NOT NULL,
    name            TEXT          NOT NULL,
    ikpu_code       VARCHAR(17),
    unit_code       VARCHAR(10),
    unit_name       TEXT,
    quantity        NUMERIC(20,4),
    price           NUMERIC(20,4),
    net_amount      NUMERIC(20,2),
    excise_rate     NUMERIC(10,4),
    excise_amount   NUMERIC(20,2),
    vat_rate        NUMERIC(5,2),
    vat_amount      NUMERIC(20,2),
    total_with_vat  NUMERIC(20,2),
    UNIQUE (receipt_id, line_no)
);
CREATE INDEX ix_receipt_item_ikpu ON receipt_item(ikpu_code);

CREATE TABLE receipt_item_marking (
    receipt_item_id BIGINT  NOT NULL REFERENCES receipt_item(id) ON DELETE CASCADE,
    marking_code    TEXT    NOT NULL,
    PRIMARY KEY (receipt_item_id, marking_code)
);

-- ---------------------------------------------------------------------
-- 5. Ўзаро текширувлар (биринчи солиштиришлар)
-- ---------------------------------------------------------------------

-- 5.1. Ойлик чиқим ЭҲФлар (фақат қабул қилинганлар), қабул кутилаётганлар алоҳида
CREATE VIEW v_esf_out_monthly AS
SELECT
    taxpayer_id,
    EXTRACT(YEAR  FROM esf_date)::SMALLINT AS period_year,
    EXTRACT(MONTH FROM esf_date)::SMALLINT AS period_month,
    SUM(total_net)      FILTER (WHERE status = 'ACCEPTED') AS accepted_net,
    SUM(total_vat)      FILTER (WHERE status = 'ACCEPTED') AS accepted_vat,
    SUM(total_net)      FILTER (WHERE status = 'PENDING')  AS pending_net,
    SUM(total_vat)      FILTER (WHERE status = 'PENDING')  AS pending_vat,
    COUNT(*)            FILTER (WHERE status = 'PENDING')  AS pending_count
FROM esf
WHERE direction = 'OUT'
GROUP BY 1, 2, 3;

-- 5.2. Ойлик НКМ тушуми: чеклар бўйича (шикастланганлар чиқарилади, қайтаришлар айрилади)
CREATE VIEW v_kkm_receipts_monthly AS
SELECT
    fm.taxpayer_id,
    EXTRACT(YEAR  FROM r.receipt_at)::SMALLINT AS period_year,
    EXTRACT(MONTH FROM r.receipt_at)::SMALLINT AS period_month,
    SUM(CASE WHEN r.receipt_type = 'RETURN' THEN -r.total_net ELSE r.total_net END)
        FILTER (WHERE r.status = 'VALID')                                    AS net_sales,
    SUM(CASE WHEN r.receipt_type = 'RETURN' THEN -r.total_vat ELSE r.total_vat END)
        FILTER (WHERE r.status = 'VALID')                                    AS net_vat,
    COUNT(*) FILTER (WHERE r.status = 'DAMAGED')                             AS damaged_count,
    SUM(r.total_with_vat) FILTER (WHERE r.status = 'DAMAGED')                AS damaged_amount,
    COUNT(*) FILTER (WHERE r.status = 'VALID' AND r.receipt_type = 'RETURN') AS return_count,
    SUM(r.total_with_vat) FILTER (WHERE r.status = 'VALID' AND r.receipt_type = 'RETURN') AS return_amount
FROM receipt r
JOIN fiscal_module fm ON fm.id = r.fiscal_module_id
GROUP BY 1, 2, 3;

-- 5.4. Қайтариш чеки асл чекдан ошиб кетган ёки асл чеки кўрсатилмаган ҳолатлар
CREATE VIEW v_kkm_suspicious_returns AS
SELECT
    r.id                        AS return_receipt_id,
    r.fiscal_module_id,
    r.receipt_no,
    r.receipt_at,
    r.total_with_vat            AS return_amount,
    o.total_with_vat            AS original_amount,
    CASE
        WHEN r.original_receipt_id IS NULL              THEN 'NO_ORIGINAL'      -- асл чек йўқ
        WHEN r.total_with_vat > o.total_with_vat        THEN 'EXCEEDS_ORIGINAL' -- асл чекдан катта
        WHEN r.receipt_at < o.receipt_at                THEN 'BEFORE_ORIGINAL'  -- асл чекдан олдин
    END                         AS issue
FROM receipt r
LEFT JOIN receipt o ON o.id = r.original_receipt_id
WHERE r.receipt_type = 'RETURN'
  AND r.status = 'VALID'
  AND (r.original_receipt_id IS NULL
       OR r.total_with_vat > o.total_with_vat
       OR r.receipt_at < o.receipt_at);

-- 5.3. Чеклар йиғиндиси билан кунлик Z-ҳисобот тафовути
CREATE VIEW v_kkm_daily_vs_receipts AS
SELECT
    d.fiscal_module_id,
    d.work_date,
    d.sales_total - d.returns_total                       AS daily_net,
    COALESCE(SUM(CASE WHEN r.receipt_type = 'RETURN'
                      THEN -r.total_with_vat ELSE r.total_with_vat END), 0) AS receipts_net,
    (d.sales_total - d.returns_total)
      - COALESCE(SUM(CASE WHEN r.receipt_type = 'RETURN'
                          THEN -r.total_with_vat ELSE r.total_with_vat END), 0) AS diff
FROM kkm_daily d
LEFT JOIN receipt r
       ON r.fiscal_module_id = d.fiscal_module_id
      AND r.receipt_at::DATE = d.work_date
      AND r.status = 'VALID'
GROUP BY d.fiscal_module_id, d.work_date, d.sales_total, d.returns_total;
