-- 0.9.435: материал ҳисобот (4 усул) — 1С «ОСВ по счету» номенклатура (ва партия) кесимида, миқдор ва сумма билан.
CREATE TABLE IF NOT EXISTS inv_osv (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    account      TEXT    NOT NULL,
    df           DATE    NOT NULL,
    dt           DATE    NOT NULL,
    item         TEXT    NOT NULL,
    lot          TEXT    NOT NULL DEFAULT '',
    open_q       NUMERIC(24,4) NOT NULL DEFAULT 0,
    open_s       NUMERIC(20,2) NOT NULL DEFAULT 0,
    deb_q        NUMERIC(24,4) NOT NULL DEFAULT 0,
    deb_s        NUMERIC(20,2) NOT NULL DEFAULT 0,
    cred_q       NUMERIC(24,4) NOT NULL DEFAULT 0,
    cred_s       NUMERIC(20,2) NOT NULL DEFAULT 0,
    close_q      NUMERIC(24,4) NOT NULL DEFAULT 0,
    close_s      NUMERIC(20,2) NOT NULL DEFAULT 0,
    has_qty      BOOLEAN NOT NULL DEFAULT TRUE,
    file_name    TEXT,
    user_id      BIGINT,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_inv_osv ON inv_osv(taxpayer_id, account, df, dt);

-- мижоз бўйича танланган фаолият тури ва усул (ҳисоб сиёсати)
CREATE TABLE IF NOT EXISTS inv_policy (
    taxpayer_id  BIGINT PRIMARY KEY REFERENCES taxpayer(id) ON DELETE CASCADE,
    activity     TEXT NOT NULL DEFAULT 'AUTO' CHECK (activity IN ('AUTO','PRODUCTION','TRADE','CONSTRUCTION','SERVICE')),
    method       TEXT NOT NULL DEFAULT 'AUTO' CHECK (method IN ('AUTO','AVG_MONTH','AVG_YEAR','AVG_MOVING','FIFO','SPECIFIC')),
    note         TEXT,
    user_id      BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
