-- 0.9.469: харидлардан шаклланган асосий воситалар — чиқим (сотув/ҳисобдан чиқариш) ва қўшимча харажатлар (етказиб бериш, монтаж).
ALTER TABLE fa_obj ADD COLUMN IF NOT EXISTS out_date   DATE;            -- чиқим санаси (NULL — ҳисобда)
ALTER TABLE fa_obj ADD COLUMN IF NOT EXISTS out_doc    TEXT;            -- чиқим ҳужжати (масалан, сотув ЭҲФ рақами)
ALTER TABLE fa_obj ADD COLUMN IF NOT EXISTS extra_cost NUMERIC(20,2);   -- бошланғич қийматга қўшиладиган харажатлар (ҚҚССиз)
ALTER TABLE fa_obj ADD COLUMN IF NOT EXISTS extra_note TEXT;            -- харажат изоҳи (ҳужжат рақами)
