-- 0.9.354 (фойдаланувчи, 08.11.2026): бухгалтернинг қўлда юритиладиган омбор ҳисоботи — эталон (платформа FIFO билан солиштириш учун).
CREATE TABLE IF NOT EXISTS wh_manual (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    y           INTEGER NOT NULL,
    m           INTEGER NOT NULL,              -- 0 — йил боши қолдиғи
    grp         TEXT,
    ikpu_code   TEXT,
    name        TEXT NOT NULL,
    unit        TEXT,
    open_q      NUMERIC(22,6) NOT NULL DEFAULT 0,  open_a  NUMERIC(22,2) NOT NULL DEFAULT 0,
    in_q        NUMERIC(22,6) NOT NULL DEFAULT 0,  in_a    NUMERIC(22,2) NOT NULL DEFAULT 0,
    esf_q       NUMERIC(22,6) NOT NULL DEFAULT 0,  esf_a   NUMERIC(22,2) NOT NULL DEFAULT 0,
    nkm_q       NUMERIC(22,6) NOT NULL DEFAULT 0,  nkm_a   NUMERIC(22,2) NOT NULL DEFAULT 0,
    prod_q      NUMERIC(22,6) NOT NULL DEFAULT 0,  prod_a  NUMERIC(22,2) NOT NULL DEFAULT 0,
    term_q      NUMERIC(22,6) NOT NULL DEFAULT 0,  term_a  NUMERIC(22,2) NOT NULL DEFAULT 0,
    close_q     NUMERIC(22,6) NOT NULL DEFAULT 0,  close_a NUMERIC(22,2) NOT NULL DEFAULT 0,
    file_name   TEXT,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_wh_manual ON wh_manual(taxpayer_id, y, m);
-- фарқ бўйича бухгалтер қарори: PLAT — платформа тўғри, MAN — бухгалтер тўғри, CODE — МХИК алмашган (alt_code билан бир товар)
CREATE TABLE IF NOT EXISTS wh_manual_mark (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    ikpu_code   TEXT   NOT NULL,
    verdict     TEXT   NOT NULL,
    note        TEXT,
    alt_code    TEXT,
    user_id     BIGINT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, ikpu_code)
);
