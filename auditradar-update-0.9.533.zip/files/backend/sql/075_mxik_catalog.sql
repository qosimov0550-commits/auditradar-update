-- 0.9.55: МХИК каталоги (tasnif.soliq.uz очиқ маълумоти) кеши — ТИФ ТН коди ёнига мос МХИК ни топиш учун
CREATE TABLE IF NOT EXISTS mxik_node (
    code       text PRIMARY KEY,          -- синф (5), позиция (8), субпозиция (11) ёки МХИК (17)
    parent     text,
    level      smallint NOT NULL,         -- 5 / 8 / 11 / 17
    name_ru    text,
    name_uz    text,
    n          integer,
    fetched_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS mxik_node_parent ON mxik_node(parent);
CREATE TABLE IF NOT EXISTS mxik_fetch (
    parent     text PRIMARY KEY,          -- шу код болалари (ёки 17 хонали МХИК мавжудлиги) олинган
    ok         boolean NOT NULL,
    fetched_at timestamptz NOT NULL DEFAULT now()
);
