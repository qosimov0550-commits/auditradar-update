-- 1С айланма-сальдо ведомостлари (бошланғич қолдиқ, баланс, платформа проводкалари билан солиштириш)
CREATE TABLE IF NOT EXISTS gl_osv_1c (
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    df           DATE    NOT NULL,
    dt           DATE    NOT NULL,
    account      TEXT    NOT NULL,
    name         TEXT,
    open_d       NUMERIC(20,2) NOT NULL DEFAULT 0,
    open_k       NUMERIC(20,2) NOT NULL DEFAULT 0,
    turn_d       NUMERIC(20,2) NOT NULL DEFAULT 0,
    turn_k       NUMERIC(20,2) NOT NULL DEFAULT 0,
    close_d      NUMERIC(20,2) NOT NULL DEFAULT 0,
    close_k      NUMERIC(20,2) NOT NULL DEFAULT 0,
    file_name    TEXT,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, df, dt, account)
);
