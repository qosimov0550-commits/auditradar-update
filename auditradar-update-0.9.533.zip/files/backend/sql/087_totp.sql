-- 0.9.111: икки босқичли кириш (TOTP, RFC 6238). Махфий калит платформа калити билан шифрланган ҳолда сақланади.
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS totp_secret_enc TEXT;          -- тасдиқлангандан кейин
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS totp_pending_enc TEXT;         -- уланиш жараёнида (тасдиқланмаган)
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS totp_last_step BIGINT;         -- бир кодни икки марта ишлатмаслик
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS totp_recovery JSONB;           -- захира кодлар (bcrypt хэш), бир марталик
ALTER TABLE app_user ADD COLUMN IF NOT EXISTS totp_enabled_at TIMESTAMPTZ;
