-- license.gov.uz очиқ реестридан олинган ҳужжатлар (лицензия, рухсатнома, хабарнома, хулоса) — очиқ маълумот, СТИР бўйича.
-- Фойдаланувчи реестрда ўзи қидиради (Cloudflare текширувини ўзи ўтади) ва натижа саҳифасини юклайди; платформа license.gov.uz га
-- ўзи сўров юбормайди.
CREATE TABLE IF NOT EXISTS license_doc (
    tin TEXT NOT NULL,
    doc_number TEXT NOT NULL,
    category TEXT,
    service TEXT NOT NULL,
    org_name TEXT,
    valid_from DATE,
    valid_to DATE,
    doc_type TEXT,
    active BOOLEAN,
    kind TEXT NOT NULL DEFAULT 'other',      -- fuel_notice | gas_license | azs | other
    source TEXT NOT NULL DEFAULT 'html',
    file_name TEXT,
    loaded_by BIGINT,
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tin, doc_number));
CREATE INDEX IF NOT EXISTS license_doc_kind ON license_doc (tin, kind);

-- реестрда қачон текширилгани (натижа бўш бўлса ҳам — «ҳужжат йўқ» ҳам далил)
CREATE TABLE IF NOT EXISTS license_check (
    tin TEXT PRIMARY KEY,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    n_docs INT NOT NULL DEFAULT 0,
    source TEXT,
    checked_by BIGINT);
