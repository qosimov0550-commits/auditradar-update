-- 0.9.249: e-auksion — лот сотувчиси (лот саҳифасидаги «Buyurtmachi») ва шахсий ҳисобга тушумлар канали («Мои платежи»: банк / Payme-карта).
ALTER TABLE auk_lot ADD COLUMN IF NOT EXISTS seller_name TEXT;
ALTER TABLE auk_lot ADD COLUMN IF NOT EXISTS seller_type TEXT;
CREATE TABLE IF NOT EXISTS auk_pay (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    ticket_no   TEXT   NOT NULL,
    op_date     DATE,
    amount      NUMERIC(20,2),
    channel     TEXT,          -- BANK | CARD
    payer       TEXT,          -- тўлов тизими номи (масалан, "PAYME" AJ); ИНН/ЖШШИР олинмайди
    status      TEXT,
    PRIMARY KEY (taxpayer_id, ticket_no)
);
