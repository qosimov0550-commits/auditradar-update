-- 0.9.352 (фойдаланувчи, 07.11.2026): newsoliq.uz (Солиқ-сервис ЭДО) шартномалари — юборилган ва келган, товарлар жадвали билан.
-- «Шартномалар» бўлими: newsoliq.uz + my.soliq + Didox + E-CONTRACT ягона реестри ва ЭҲФ бўйича бажарилиши.
CREATE TABLE IF NOT EXISTS ss_contract (
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    doc_id        TEXT   NOT NULL,
    direction     TEXT   NOT NULL,          -- OUT — корхона юборган, IN — корхонага келган
    status        TEXT,                     -- accept | reject | cancel | ...
    page_status   TEXT,
    name          TEXT,
    contract_no   TEXT,
    contract_date DATE,
    expire_date   DATE,
    place         TEXT,
    cp_tin        TEXT,
    cp_name       TEXT,
    has_vat       BOOLEAN,
    net           NUMERIC(22,2),
    vat           NUMERIC(22,2),
    total         NUMERIC(22,2),
    updated       TEXT,
    collected_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, doc_id)
);
CREATE INDEX IF NOT EXISTS ix_ss_contract_cp ON ss_contract(taxpayer_id, cp_tin);
CREATE TABLE IF NOT EXISTS ss_contract_line (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    doc_id       TEXT   NOT NULL,
    ord          INTEGER NOT NULL,
    name         TEXT,
    ikpu_code    TEXT,
    ikpu_name    TEXT,
    package_code TEXT,
    unit         TEXT,
    qty          NUMERIC(22,6),
    price        NUMERIC(22,6),
    net          NUMERIC(22,2),
    vat_rate     NUMERIC(6,2),
    vat          NUMERIC(22,2),
    total        NUMERIC(22,2),
    PRIMARY KEY (taxpayer_id, doc_id, ord)
);
