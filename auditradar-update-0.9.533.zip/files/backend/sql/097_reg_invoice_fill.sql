-- 0.9.141: ҳисоботда контрагент СТИРи/ЖШШИРи бўш қатор — шаклдаги мос қатор билан тўлдириш.
-- Аввал: шаклда шу рақам+сана билан ягона СТИР бўлсагина. Энди бир нечта бўлса (бир рақам икки харидорга, масалан
-- 91/26 — MCHJ ва жисмоний шахс), номи ёки суммаси (ҚҚСсиз ва ҚҚС) мос келган ягона қатор СТИРи олинади.
CREATE OR REPLACE FUNCTION norm_cp_name(t TEXT) RETURNS TEXT
    LANGUAGE SQL IMMUTABLE AS $$ SELECT regexp_replace(upper(COALESCE(t, '')), '[^0-9A-ZА-ЯЁЎҚҒҲ]', '', 'g') $$;

CREATE OR REPLACE VIEW v_reg_invoice AS
WITH base AS (
    SELECT r.taxpayer_id, r.variant, l.register, r.period_year, r.period_month,
           norm_doc_no(l.invoice_no) AS invoice_key, l.invoice_no, l.invoice_date,
           l.counterparty_tin, l.counterparty_name, l.is_kkm,
           l.net_amount, l.vat_amount, l.nondeductible_net, l.nondeductible_vat, l.nondeductible_reason
    FROM vat_register_row l
    JOIN vat_return r ON r.id = l.vat_return_id AND r.is_latest
), gen AS (
    SELECT taxpayer_id, register, period_year, period_month, invoice_key, invoice_date, counterparty_tin AS tin,
           norm_cp_name(counterparty_name) AS nm, SUM(net_amount) AS net, SUM(vat_amount) AS vat
    FROM base
    WHERE variant = 'GENERATED' AND counterparty_tin IS NOT NULL
    GROUP BY 1, 2, 3, 4, 5, 6, 7, 8
), fill AS (
    SELECT taxpayer_id, register, period_year, period_month, invoice_key, invoice_date, MIN(tin) AS tin
    FROM gen
    GROUP BY 1, 2, 3, 4, 5, 6
    HAVING COUNT(DISTINCT tin) = 1
), filled AS (
    SELECT b.*,
           COALESCE(b.counterparty_tin, f.tin,
                    (SELECT MIN(g.tin) FROM gen g
                      WHERE g.taxpayer_id = b.taxpayer_id AND g.register = b.register
                        AND g.period_year = b.period_year AND g.period_month = b.period_month
                        AND g.invoice_key = b.invoice_key AND g.invoice_date = b.invoice_date
                        AND g.nm <> '' AND g.nm = norm_cp_name(b.counterparty_name)
                     HAVING COUNT(DISTINCT g.tin) = 1),
                    (SELECT MIN(g.tin) FROM gen g
                      WHERE g.taxpayer_id = b.taxpayer_id AND g.register = b.register
                        AND g.period_year = b.period_year AND g.period_month = b.period_month
                        AND g.invoice_key = b.invoice_key AND g.invoice_date = b.invoice_date
                        AND g.net = b.net_amount AND g.vat IS NOT DISTINCT FROM b.vat_amount
                     HAVING COUNT(DISTINCT g.tin) = 1)) AS tin_f
    FROM base b
    LEFT JOIN fill f
           ON f.taxpayer_id = b.taxpayer_id AND f.register = b.register
          AND f.period_year = b.period_year AND f.period_month = b.period_month
          AND f.invoice_key = b.invoice_key AND f.invoice_date = b.invoice_date
)
SELECT
    b.taxpayer_id,
    b.variant,
    b.register,
    b.period_year,
    b.period_month,
    b.invoice_key,
    b.invoice_date,
    b.tin_f                                   AS counterparty_tin,
    MIN(b.invoice_no)                         AS invoice_no,
    BOOL_OR(b.counterparty_tin IS NULL)       AS tin_missing_in_source,
    MAX(b.counterparty_name)                  AS counterparty_name,
    BOOL_OR(b.is_kkm)                         AS is_kkm,
    COUNT(*)                                  AS row_count,
    SUM(b.net_amount)                         AS net_amount,
    SUM(b.vat_amount)                         AS vat_amount,
    SUM(COALESCE(b.nondeductible_net, 0))     AS nondeductible_net,
    SUM(COALESCE(b.nondeductible_vat, 0))     AS nondeductible_vat,
    MAX(b.nondeductible_reason)               AS nondeductible_reason
FROM filled b
GROUP BY 1, 2, 3, 4, 5, 6, 7, 8;
