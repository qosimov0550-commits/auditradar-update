-- 0.9.277: ЭҲФ API «0001-01-01T00:00:00» (имзоланмаган) — timestamptz да эрамиздан аввалги сана бўлиб қолган, ўқишда хато берарди
UPDATE esf SET signed_at = NULL WHERE signed_at < '1900-01-01';
UPDATE esf SET sent_at = NULL WHERE sent_at < '1900-01-01';
UPDATE esf SET status_date = NULL WHERE status_date < '1900-01-01';
