-- Солиқ ҳисоботлари назорат жадвали: Солиқ кодекси (ЎРҚ-599, жорий таҳрир) бўйича муддатлар, солиқ кодлари,
-- мижоз × ҳисобот × давр бўйича солиқ қарзи, тўлов топшириқномаси санаси, масъул ва изоҳ

ALTER TABLE tax_obligation ADD COLUMN IF NOT EXISTS tax_codes INT[] NOT NULL DEFAULT '{}';   -- КЛС солиқ кодлари (қарз/тўлов учун)
ALTER TABLE tax_obligation ADD COLUMN IF NOT EXISTS article TEXT;                          -- Солиқ кодекси моддаси
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS responsible TEXT;                            -- бириктирилган масъул шахс

-- аввалги бошланғич муддатлар Солиқ кодексига мослаштирилади (администратор ўзгартирмаган бўлса)
UPDATE tax_obligation SET freq='M', due_day=15, note='Ҳисобот ойидан кейинги ойнинг 15-кунидан кечиктирмай (СК 470-модда)'
 WHERE code='AOS' AND freq='Q' AND due_day=20;
UPDATE tax_obligation SET year_month=3, year_day=1, year_offset=1,
       note='Чораклар — кейинги ойнинг 20-куни; йиллик — кейинги йилнинг 1 марти (СК 339-модда)'
 WHERE code='PROFIT' AND year_month=3 AND year_day=25;
UPDATE tax_obligation SET year_month=3, year_day=1, year_offset=1,
       note='Йиллик ҳисобот — кейинги йилнинг 1 марти; бўнак ҳақида маълумотнома — жорий йилнинг 20 январи (СК 417-модда)'
 WHERE code='PROP' AND year_month=1 AND year_day=15 AND year_offset=0;
UPDATE tax_obligation SET year_day=20,
       note='Қишлоқ хўжалигига мўлжалланмаган ерлар — жорий йилнинг 20 январи; қишлоқ хўжалиги ерлари — 1 май (СК 431-модда)'
 WHERE code='LAND' AND year_month=1 AND year_day=15 AND year_offset=0;
UPDATE tax_obligation SET year_month=3, year_day=1, year_offset=1,
       note='Йилда бир марта — кейинги йилнинг 1 марти (СК 447-модда)'
 WHERE code='WATER' AND year_month=1 AND year_day=15 AND year_offset=0;

UPDATE tax_obligation SET tax_codes='{1,94}', article='273' WHERE code='VAT' AND tax_codes='{}';
UPDATE tax_obligation SET tax_codes='{100}', article='470' WHERE code='AOS' AND tax_codes='{}';
UPDATE tax_obligation SET tax_codes='{46,36,101,186}', article='389, 407' WHERE code='PIT' AND tax_codes='{}';
UPDATE tax_obligation SET tax_codes='{186}', article='389' WHERE code='RENT' AND tax_codes='{}';
UPDATE tax_obligation SET tax_codes='{32}', article='339, 340' WHERE code='PROFIT' AND tax_codes='{}';
UPDATE tax_obligation SET tax_codes='{44}', article='417' WHERE code='PROP' AND tax_codes='{}';
UPDATE tax_obligation SET tax_codes='{53}', article='431, 432' WHERE code='LAND' AND tax_codes='{}';
UPDATE tax_obligation SET tax_codes='{52}', article='447, 448' WHERE code='WATER' AND tax_codes='{}';

INSERT INTO tax_obligation(code, name, applies, freq, due_day, year_month, year_day, year_offset, source, codes, tax_codes, article, note, sort) VALUES
 ('PIT_Y', 'ЖШДС ва ижтимоий солиқ — йиллик ҳисоб-китоб', 'ALL', 'Y', 20, 2, 15, 1, 'manual', '{}', '{46,36,101}', '389, 407',
  'Йил якунлари бўйича — кейинги йилнинг 15 феврали (СК 389, 407-моддалар)', 31),
 ('AOS_Y', 'Айланмадан олинадиган солиқ — йиллик ҳисобот', 'AOS', 'Y', 20, 2, 15, 1, 'manual', '{}', '{100}', '470',
  'Солиқ даври якунлари бўйича — кейинги йилнинг 15 феврали (СК 470-модда)', 21),
 ('DIV', 'Дивиденд ва фоизлардан солиқ (солиқ агенти)', 'NONE', 'M', 20, NULL, NULL, 1, 'manual', '{}', '{138,35}', '345',
  'Дивиденд/фоиз ҳисобланган ойдан кейинги ойнинг 20-куни (СК 345-модда); тўлов — дивиденд тўлаш муддатидан кечиктирмай. Дивиденд тўлайдиган мижозлар учун ёқинг', 36),
 ('NR_VAT', 'Норезидент учун ҚҚС (солиқ агенти)', 'NONE', 'M', 20, NULL, NULL, 1, 'manual', '{}', '{29}', '273',
  'Тўлов амалга оширилган ойдан кейинги ойнинг 20-куни (СК 273-модда). Норезидентдан хизмат олган мижозлар учун ёқинг', 37),
 ('NR_INC', 'Норезидент даромадидан солиқ (солиқ агенти)', 'NONE', 'M', 20, NULL, NULL, 1, 'manual', '{}', '{137}', '355',
  'Даромад тўланган ойдан кейинги ойнинг 20-куни (СК 355-модда); тўлов — даромад тўланган куннинг эртасидан кечиктирмай', 38),
 ('EXCISE', 'Акциз солиғи ҳисоботи', 'NONE', 'M', 10, NULL, NULL, 1, 'manual', '{}', '{}', '292, 293',
  'Ҳар ойда, кейинги ойнинг 10-куни (СК 292-модда); ёқилғи шохобчалари — шохобча жойлашган ердаги солиқ органига. Акциз тўловчи мижозлар учун ёқинг', 39)
ON CONFLICT (code) DO NOTHING;

CREATE TABLE IF NOT EXISTS tax_control (
    taxpayer_id   BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    obligation_id INT    NOT NULL REFERENCES tax_obligation(id) ON DELETE CASCADE,
    period        TEXT   NOT NULL,                  -- 2026-09 | 2026-Q3 | 2026
    tax_code      INT    NOT NULL DEFAULT 0,        -- 0 — қатор (изоҳ), бошқаси — солиқ коди бўйича
    debt          NUMERIC(20,2),                    -- қўлда киритилган солиқ қарзи (бўлмаса — далолатномадан)
    paid_on       DATE,                             -- тўлов топшириқномаси санаси (бўлмаса — КЛС/банкдан)
    note          TEXT,
    user_id       BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, obligation_id, period, tax_code)
);
