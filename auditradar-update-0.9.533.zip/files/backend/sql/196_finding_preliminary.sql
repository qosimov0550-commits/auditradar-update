-- 0.9.528: топилма маълумот тўлиқ бўлмаган ҳолда чиққан бўлса — «дастлабки» (сабаби); хатар даражасига кирмайди
ALTER TABLE finding ADD COLUMN IF NOT EXISTS preliminary TEXT;
