-- Мижоз гуруҳлари: «Бухгалтерия» (ҳисоб юритилади) ва «Аудит». Битта корхона фақат битта гуруҳда (ЎРҚ-677, 34-модда);
-- «Бухгалтерия» гуруҳидаги корхонада ички аудит белгиси бўлиши мумкин.
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS client_group TEXT CHECK (client_group IN ('ACCOUNTING', 'AUDIT'));
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS internal_audit BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS client_group_history (
    id             SERIAL PRIMARY KEY,
    taxpayer_id    INT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    client_group   TEXT,
    internal_audit BOOLEAN NOT NULL DEFAULT FALSE,
    prev_group     TEXT,
    reason         TEXT,
    changed_by     INT REFERENCES app_user(id) ON DELETE SET NULL,
    changed_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS client_group_history_tp ON client_group_history (taxpayer_id, changed_at DESC);
