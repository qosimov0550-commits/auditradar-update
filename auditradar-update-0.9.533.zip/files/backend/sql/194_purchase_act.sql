-- 0.9.520: электрон харид далолатномалари (my.soliq.uz → «Харид қилиш далолатномаси», XQD/DSQ) — деҳқон/жисмоний
-- шахслардан ЭҲФсиз харид қилинган маҳсулотлар. Омборга кирим манбаси сифатида олинади.
ALTER TABLE data_import DROP CONSTRAINT IF EXISTS data_import_source_check;
ALTER TABLE data_import ADD CONSTRAINT data_import_source_check CHECK (source IN (
    'MY3_VAT_SUBMITTED', 'MY3_VAT_GENERATED', 'ESF_SOLIQSERVIS', 'ESF_FAKTURA', 'ESF_OTHER', 'MY3_KKM',
    'ECONTRACT_CONTRACTS', 'ECONTRACT_OPERATIONS', 'ECONTRACT_GOODS', 'CUSTOMS_REGISTER', 'ECONTRACT_API',
    'MY3_TAX_REPORT', 'CUSTOMS_ACT', 'ECONTRACT_CARD', 'PURCHASE_ACT'));

CREATE TABLE ft_purchase_act (
    id             BIGSERIAL PRIMARY KEY,
    taxpayer_id    BIGINT        NOT NULL REFERENCES taxpayer(id),
    act_id         VARCHAR(40)   NOT NULL,          -- тизимдаги ID (24 белгили hex)
    doc_no         VARCHAR(40),                     -- DSQ-98090
    doc_date       DATE          NOT NULL,
    act_type       VARCHAR(12)   NOT NULL DEFAULT 'STANDARD',   -- STANDARD / ADDITIONAL (қўшимча)
    base_doc_no    VARCHAR(40),                     -- қўшимча бўлса — асосий XQD рақами
    base_doc_date  DATE,
    activity       TEXT,                            -- «Экспортчи» ва ҳ.к.
    seller_pinfl   VARCHAR(14),
    seller_name    TEXT,
    signer         TEXT,                            -- тасдиқлаган шахс (ЭРИ)
    signed_at      TIMESTAMP,
    total          NUMERIC(20,2) NOT NULL DEFAULT 0,
    data_import_id BIGINT        REFERENCES data_import(id),
    UNIQUE (taxpayer_id, act_id)
);
CREATE INDEX ix_ft_purchase_act_date ON ft_purchase_act(taxpayer_id, doc_date);

CREATE TABLE ft_purchase_act_item (
    id       BIGSERIAL PRIMARY KEY,
    act_id   BIGINT        NOT NULL REFERENCES ft_purchase_act(id) ON DELETE CASCADE,
    taxpayer_id BIGINT     NOT NULL,             -- ҳисоб кэши белгиси мижоз бўйича бўлиши учун
    line_no  INTEGER       NOT NULL,
    mxik     VARCHAR(20),
    name     TEXT,
    unit     TEXT,
    qty      NUMERIC(20,5),
    price    NUMERIC(20,2),
    amount   NUMERIC(20,2) NOT NULL DEFAULT 0
);
CREATE INDEX ix_ft_purchase_act_item ON ft_purchase_act_item(act_id);

SELECT ar_ver_attach();
