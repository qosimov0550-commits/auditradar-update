-- Божхона тўловлари бўйича акт-сверка (dep.customs.uz/qarzdor, ҳудуд бўйича): ҳар БЮД учун ҳисобланган жами
-- божхона тўловлари (бож + акциз + ҚҚС + йиғим) ва ҳисоб рақамдан ўтказилган маблағлар.
ALTER TABLE data_import DROP CONSTRAINT IF EXISTS data_import_source_check;
ALTER TABLE data_import ADD CONSTRAINT data_import_source_check CHECK (source IN (
    'MY3_VAT_SUBMITTED', 'MY3_VAT_GENERATED', 'ESF_SOLIQSERVIS', 'ESF_FAKTURA', 'ESF_OTHER', 'MY3_KKM',
    'ECONTRACT_CONTRACTS', 'ECONTRACT_OPERATIONS', 'ECONTRACT_GOODS', 'CUSTOMS_REGISTER', 'ECONTRACT_API',
    'MY3_TAX_REPORT', 'CUSTOMS_ACT'));

CREATE TABLE ft_customs_act_row (
    id             BIGSERIAL PRIMARY KEY,
    taxpayer_id    BIGINT      NOT NULL REFERENCES taxpayer(id),
    region         TEXT,
    row_date       DATE        NOT NULL,
    doc_no         TEXT,
    doc_type       TEXT,                    -- ГТД(ПД/НД), ГТД(ИМ,ЭК), Расч.счет ...
    decl_post      VARCHAR(10),
    decl_no        INTEGER,
    decl_date      DATE,
    paid           NUMERIC(20,2) NOT NULL DEFAULT 0,   -- корхона томонидан ўтказилган (дебет)
    charged        NUMERIC(20,2) NOT NULL DEFAULT 0,   -- божхона ҳисоблаган тўловлар (кредит)
    row_key        VARCHAR(64) NOT NULL,
    data_import_id BIGINT      REFERENCES data_import(id),
    UNIQUE (taxpayer_id, row_key)
);
CREATE INDEX ix_ft_customs_act_decl ON ft_customs_act_row(taxpayer_id, decl_no, decl_date);

-- БЮД бўйича жами ҳисобланган божхона тўловлари
CREATE VIEW v_ft_customs_charge AS
SELECT taxpayer_id, decl_post, decl_no, decl_date, SUM(charged) AS charged, MIN(row_date) AS first_date,
       string_agg(DISTINCT doc_type, ', ') AS doc_types, string_agg(DISTINCT region, ', ') AS region,
       MAX(doc_no) AS doc_no
FROM ft_customs_act_row
WHERE decl_no IS NOT NULL
GROUP BY taxpayer_id, decl_post, decl_no, decl_date;
