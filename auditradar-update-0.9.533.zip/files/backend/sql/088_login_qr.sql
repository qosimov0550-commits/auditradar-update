-- 0.9.113: телефон орқали киришни тасдиқлаш (QR) ва ишончли қурилмалар.
-- login_qr — компьютерда логин+пароль тўғри киритилгач берилган 2 дақиқалик сўров. Телефондаги ишончли қурилма
-- QR ни сканерлаб тасдиқлаганда компьютерга сессия берилади (бир марта). Махфий қисм фақат SHA-256 хэш кўринишида.
CREATE TABLE IF NOT EXISTS login_qr (
    id           BIGSERIAL PRIMARY KEY,
    secret_hash  TEXT        NOT NULL,
    user_id      BIGINT      NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    session_ver  INT         NOT NULL,
    status       VARCHAR(10) NOT NULL DEFAULT 'pending',      -- pending | approved | denied | used
    ip           TEXT,
    ua           TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at   TIMESTAMPTZ NOT NULL,
    decided_at   TIMESTAMPTZ,
    device_id    BIGINT
);
CREATE INDEX IF NOT EXISTS login_qr_user ON login_qr(user_id, created_at);

-- user_device — икки босқичли кириш ўтилган ва «ишончли» деб эслаб қолинган қурилма (телефон).
-- Қурилмада httponly cookie (ar_dev) да тасодифий калит, базада — фақат SHA-256 хэш.
CREATE TABLE IF NOT EXISTS user_device (
    id           BIGSERIAL PRIMARY KEY,
    user_id      BIGINT      NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    token_hash   TEXT        NOT NULL UNIQUE,
    label        TEXT,
    ip           TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_used_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS user_device_user ON user_device(user_id);
