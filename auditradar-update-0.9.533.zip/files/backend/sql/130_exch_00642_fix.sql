-- 0.9.267: 129 даги ўтказиш ишламади — сервер базаси C локалида, ILIKE/~* кирилл ҳарфларни катта-кичикка солиштирмайди.
-- Кирилл матн учун аниқ LIKE (иккала ёзилиши), 00642 коди рақам — регуляр ифода.
UPDATE exchange_txn SET kind = CASE WHEN COALESCE(credit, 0) > 0 THEN 'DEPOSIT' ELSE 'WITHDRAW' END
 WHERE kind = 'MOVE'
   AND (comment LIKE 'Платеж%' OR comment LIKE 'платеж%' OR comment LIKE 'ПЛАТЕЖ%')
   AND (details ~ '^\s*00642' OR details LIKE '%Переброск%' OR details LIKE '%переброск%' OR details LIKE '%ПЕРЕБРОСК%');
