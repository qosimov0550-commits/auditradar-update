-- 0.9.302: қайта ташкил этиш (қўшиб олиш) — қўшиб олинган корхоналар ва топшириш далолатномаси (21-сон БҲМС счётлари бўйича).
-- Фойдаланувчи (03.11.2026): «Малика пояфзаллари 2024 йилда Ахсан бизнесни ўз таркибига қўшиб олган»; активлар (асосий воситалар,
-- мулк, ТМЗ, пул), мажбуриятлар ва дебитор-кредиторлар қўшиб олиш санасида ўтади.
CREATE TABLE IF NOT EXISTS merge_company (
    id          BIGSERIAL PRIMARY KEY,
    taxpayer_id BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    tin         TEXT        NOT NULL,
    name        TEXT,
    merge_date  DATE        NOT NULL,          -- топшириш далолатномаси / давлат реестридан чиқарилган сана: шу кун бошидан ўтади
    contra      TEXT        NOT NULL DEFAULT '8710',   -- далолатнома Дт ≠ Кт бўлса фарқ (соф активлар) шу счётга
    act_no      TEXT,
    note        TEXT,
    user_id     BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, tin)
);
CREATE TABLE IF NOT EXISTS merge_line (
    id          BIGSERIAL PRIMARY KEY,
    merge_id    BIGINT      NOT NULL REFERENCES merge_company(id) ON DELETE CASCADE,
    account     TEXT        NOT NULL,          -- 4 хонали счёт (21-сон БҲМС)
    acc_name    TEXT,
    cp_tin      TEXT,                          -- дебитор/кредитор: контрагент
    cp_name     TEXT,
    debit       NUMERIC(20,2) NOT NULL DEFAULT 0,
    credit      NUMERIC(20,2) NOT NULL DEFAULT 0,
    file_name   TEXT
);
CREATE INDEX IF NOT EXISTS ix_merge_line ON merge_line(merge_id);
-- Омбор: қўшиб олинган корхонадан товар кесимида ўтган ТМЗ (кирим)
ALTER TABLE stock_balance_file DROP CONSTRAINT IF EXISTS stock_balance_file_kind_check;
ALTER TABLE stock_balance_file ADD CONSTRAINT stock_balance_file_kind_check CHECK (kind IN ('OPEN', 'CLOSE', 'MERGE'));
