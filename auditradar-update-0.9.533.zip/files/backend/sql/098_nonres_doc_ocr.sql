-- 0.9.142: асос файлидан (резидентлик сертификати) OCR билан ажратилган реквизитлар. Тўлиқ матн сақланмайди.
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_no TEXT;
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_date DATE;
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_year INT;
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_at TIMESTAMPTZ;
ALTER TABLE ft_nonres_doc ADD COLUMN IF NOT EXISTS ocr_err TEXT;
