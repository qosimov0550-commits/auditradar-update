-- Акциз: чиқувчи ЭҲФ харидорлари — ёқилғи савдосига лицензияси бор (улгуржи/чакана сотувчи) харидорларга сотув акциз базасига
-- кирмайди (СК 289³); якуний истеъмолчига сотув ва ўз эҳтиёжи — тортилади. Белгини аудитор қўяди, ОКЭД 46.71/47.30 — таклиф.
CREATE TABLE IF NOT EXISTS excise_buyer (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    tin          TEXT NOT NULL,
    licensed     BOOLEAN NOT NULL DEFAULT TRUE,
    note         TEXT,
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, tin)
);
