-- 0.9.120: ed2.customs.uz «КТД» (корректировка) рўйхати — ГТД (справ. рақами, ҚҚС шаклидаги рақам) ↔ КТД боғланиши.
-- «Номер КТД, присвоенный специалистом» (инспектор ЖШШИРи билан бошланади) САҚЛАНМАЙДИ.
CREATE TABLE IF NOT EXISTS ft_ed2_ktd (
    taxpayer_id    BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    decl_uuid      TEXT        NOT NULL,
    ebr_id         TEXT,
    gtd_post       VARCHAR(10),
    gtd_date       DATE,
    gtd_no         INTEGER,
    ktd_post       VARCHAR(10),
    ktd_date       DATE,
    ktd_no         INTEGER,
    registered_at  TIMESTAMP,
    regime         VARCHAR(10),
    sender         TEXT,
    receiver       TEXT,
    customs_value  NUMERIC(20,2),
    n_goods        INTEGER,
    ktd_type       TEXT,
    status         TEXT,
    first_seen     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, decl_uuid)
);
CREATE INDEX IF NOT EXISTS ix_ft_ed2_ktd_gtd ON ft_ed2_ktd(taxpayer_id, gtd_no, gtd_date);
