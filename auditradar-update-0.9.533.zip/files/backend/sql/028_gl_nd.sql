-- Солиқ кодекси бўйича фойда солиғи базасидан чегириб ташланмайдиган харажатлар (СК 317-модда ва бошқалар) қоидалари.
-- taxpayer_id NULL — умумий қоида. rule_keys — проводка қоидаси (масалан, tax.penalty); pattern — проводка матни/контрагент номи;
-- accounts — счёт префикслари (бўш — барча харажат счётлари); share — чегирилмайдиган улуш (1 — тўлиқ).
CREATE TABLE IF NOT EXISTS gl_nd_rule (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT REFERENCES taxpayer(id) ON DELETE CASCADE,
    name         TEXT    NOT NULL,
    line         TEXT,                              -- фойда солиғи ҳисоб-китоби 2.1-иловаси сатри (масалан, 0328)
    rule_keys    TEXT,
    pattern      TEXT,
    accounts     TEXT,
    share        NUMERIC(6,4) NOT NULL DEFAULT 1,
    basis        TEXT,
    active       BOOLEAN NOT NULL DEFAULT true,
    priority     INTEGER NOT NULL DEFAULT 100,
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Фойда солиғи ставкаси мижоз ва йил бўйича (масалан, имтиёзли 7,5 %); йўқ бўлса — умумий 15 %
CREATE TABLE IF NOT EXISTS gl_profit_rate (
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    year         INTEGER NOT NULL,
    rate         NUMERIC(5,2) NOT NULL,
    PRIMARY KEY (taxpayer_id, year)
);

-- Товар-моддий захиралар қолдиғи (таннархни ҳисоблаш учун): қўлда киритилади ёки 1С ОСВдан олинади
CREATE TABLE IF NOT EXISTS gl_inventory (
    taxpayer_id  BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    as_of        DATE    NOT NULL,          -- шу кун охиридаги қолдиқ
    amount       NUMERIC(20,2) NOT NULL,
    note         TEXT,
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, as_of)
);
