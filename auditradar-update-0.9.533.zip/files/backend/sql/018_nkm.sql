-- Онлайн-НКМ (my.soliq.uz янги кабинети): фискал модуллар, чеклар ва товар қаторлари.
CREATE TABLE IF NOT EXISTS nkm_terminal (
    taxpayer_id    BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    terminal_id    TEXT    NOT NULL,                 -- ФМ рақами
    kind           TEXT    NOT NULL,                 -- NKM_CHECK | MARKETPLACE_CHECK | TAXI_CHECK
    is_commission  BOOLEAN NOT NULL DEFAULT FALSE,   -- воситачи (комиссионер) режими: Payme, маркетплейс ва ҳ.к.
    registered_at  DATE,
    expires_at     DATE,
    raw            JSONB,
    seen_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, terminal_id)
);

CREATE TABLE IF NOT EXISTS nkm_receipt (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    terminal_id   TEXT        NOT NULL,
    receipt_no    TEXT        NOT NULL,
    paid_at       TIMESTAMP   NOT NULL,              -- чек вақти (кабинет кўрсатганидек, Тошкент вақти)
    subtype       TEXT        NOT NULL,              -- SALE | REFUND
    owner_tin     TEXT,                              -- чек эгаси СТИР/ЖШШИР (маркетплейсда — оператор)
    cash          NUMERIC(20,2) NOT NULL DEFAULT 0,  -- чек бўйича жами нақд
    card          NUMERIC(20,2) NOT NULL DEFAULT 0,  -- чек бўйича жами карта
    vat_total     NUMERIC(20,2) NOT NULL DEFAULT 0,  -- чек бўйича жами ҚҚС
    own_price     NUMERIC(20,2) NOT NULL DEFAULT 0,  -- корхонага тегишли қаторлар: нарх
    own_discount  NUMERIC(20,2) NOT NULL DEFAULT 0,  -- чегирма + дисконт
    own_vat       NUMERIC(20,2) NOT NULL DEFAULT 0,
    lines         INTEGER     NOT NULL DEFAULT 0,
    own_lines     INTEGER     NOT NULL DEFAULT 0,
    extra         JSONB
);
CREATE INDEX IF NOT EXISTS ix_nkm_receipt ON nkm_receipt(taxpayer_id, terminal_id, paid_at);

CREATE TABLE IF NOT EXISTS nkm_item (
    receipt_id     BIGINT  NOT NULL REFERENCES nkm_receipt(id) ON DELETE CASCADE,
    line_no        INTEGER NOT NULL,
    name           TEXT,
    qty            NUMERIC(20,4),
    price          NUMERIC(20,2),
    discount       NUMERIC(20,2),
    other          NUMERIC(20,2),                    -- дисконт
    vat            NUMERIC(20,2),
    product_code   TEXT,                             -- ИКПУ
    package_code   TEXT,
    barcode        TEXT,
    commission_tin TEXT,
    label          TEXT,                             -- маркировка коди
    is_own         BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (receipt_id, line_no)
);
CREATE INDEX IF NOT EXISTS ix_nkm_item_code ON nkm_item(product_code);

-- Қайси ФМ, ой ва чек тури тўлиқ юкланган (қайта йиғишда ўтказиб юбориш учун)
CREATE TABLE IF NOT EXISTS nkm_month (
    taxpayer_id  BIGINT   NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    terminal_id  TEXT     NOT NULL,
    y            SMALLINT NOT NULL,
    m            SMALLINT NOT NULL,
    subtype      TEXT     NOT NULL,
    receipts     INTEGER  NOT NULL DEFAULT 0,
    loaded_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, terminal_id, y, m, subtype)
);
