-- 0.9.346: my.soliq e-контракт (рўйхатдан ўтган шартномалар) товарлар жадвали — МХИК, ўлчов бирлиги коди, миқдор, нарх, ҚҚС.
-- Барча ЭДО операторларида (Didox, Солиқ-сервис ва б.) тузилиб, солиқда рўйхатдан ўтган шартномалар шу ерда. ЭҲФ шаблони учун.
CREATE TABLE IF NOT EXISTS econtract_line (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    contract_id  TEXT   NOT NULL,
    direction    TEXT   NOT NULL,
    ord          INTEGER NOT NULL,
    name         TEXT,
    ikpu_code    TEXT,
    package_code TEXT,
    unit         TEXT,
    qty          NUMERIC(22,6),
    price        NUMERIC(22,6),
    net          NUMERIC(22,2),
    vat_rate     NUMERIC(6,2),
    vat          NUMERIC(22,2),
    total        NUMERIC(22,2),
    PRIMARY KEY (taxpayer_id, contract_id, direction, ord)
);
