-- 0.9.139: cargo.customs.uz БЮД нусхаси (PDF) олиш уринишлари — ҳар йиғишда аввал олинган/олинмайдиган БЮДлар қайта юкланмасин
ALTER TABLE ft_cargo_decl ADD COLUMN IF NOT EXISTS pdf_tries INT NOT NULL DEFAULT 0;
ALTER TABLE ft_cargo_decl ADD COLUMN IF NOT EXISTS pdf_at TIMESTAMPTZ;
ALTER TABLE ft_cargo_decl ADD COLUMN IF NOT EXISTS pdf_ok BOOLEAN;
