-- 0.9.161: биржада бир ИНП бўйича бир нечта ҳисоб (сўм ва валюта, бир нечта сўм ҳисоби) — ҳисоб калитига биржанинг б/с
-- рақами қўшилади. 0.9.154–0.9.160 да бир хил ИНП ва валютадаги ҳисоблар бир-бирини алмаштириб юборган — кўчирмалар
-- қайта олинади (йиғиш ёки файл).
DELETE FROM exchange_txn;
DELETE FROM exchange_account;
ALTER TABLE exchange_account ADD COLUMN IF NOT EXISTS bank_acc TEXT NOT NULL DEFAULT '';
ALTER TABLE exchange_account DROP CONSTRAINT IF EXISTS exchange_account_pkey;
ALTER TABLE exchange_account ADD PRIMARY KEY (taxpayer_id, platform_tin, account_no, currency, bank_acc);
ALTER TABLE exchange_txn ADD COLUMN IF NOT EXISTS bank_acc TEXT NOT NULL DEFAULT '';
DROP INDEX IF EXISTS ux_exchange_txn;
CREATE UNIQUE INDEX IF NOT EXISTS ux_exchange_txn ON exchange_txn(taxpayer_id, platform_tin, account_no, currency, bank_acc, txn_no, kind, debit, credit)
    WHERE txn_no IS NOT NULL;
