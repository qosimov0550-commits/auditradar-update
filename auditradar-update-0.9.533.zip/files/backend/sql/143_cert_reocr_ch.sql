-- 0.9.290: Швейцария — ёрлиқлар устуни ва «15. Januar — 2026» санаси — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
