-- Марказий банк курслари кэши (cbu.uz). code — валютанинг рақамли коди (840 = USD), rate — 1 бирлик учун сўм.
CREATE TABLE IF NOT EXISTS cbu_rate (
    code       TEXT          NOT NULL,
    rate_date  DATE          NOT NULL,
    rate       NUMERIC(20,6) NOT NULL,
    PRIMARY KEY (code, rate_date)
);
