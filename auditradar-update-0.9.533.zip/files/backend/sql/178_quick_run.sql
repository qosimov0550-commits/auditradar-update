-- 0.9.441: тезкор янгилаш (Онлайн-НКМ, ЭҲФ) — тўлиқ йиғишдан (collect_run) алоҳида: «сўнгги ЭРИ йиғиши», ЭРИ навбати,
-- аномалия текшируви ва бошқа ҳисобларга аралашмайди.
CREATE TABLE IF NOT EXISTS quick_run (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    user_id      BIGINT REFERENCES app_user(id),
    kind         TEXT NOT NULL CHECK (kind IN ('nkm','esf')),
    started_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at  TIMESTAMPTZ,
    status       TEXT NOT NULL DEFAULT 'RUNNING',
    summary      JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS ix_quick_run ON quick_run(taxpayer_id, kind, started_at DESC);
