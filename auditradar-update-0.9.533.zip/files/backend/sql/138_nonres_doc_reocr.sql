-- 0.9.285: Швейцария 2026 шакли (Company Name, «15. Januar 2026»), апостиль «Convention de la Haye» дан — қайта ўқилсин
UPDATE ft_nonres_doc SET ocr_at = NULL WHERE kind = 'treaty' AND file_path IS NOT NULL;
