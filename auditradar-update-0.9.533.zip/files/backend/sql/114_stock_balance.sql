-- 0.9.213: «Омбор» — давр бошига (OPEN) ва охирига (CLOSE) товар-моддий захиралар қолдиқлари (1С, материал ҳисобот ёки Excel).
-- Мажбурий устунлар: туркум, номи, МХИК, ўлчов бирлиги, миқдор, қиймат.
CREATE TABLE IF NOT EXISTS stock_balance_file (
    id           BIGSERIAL PRIMARY KEY,
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    kind         TEXT   NOT NULL CHECK (kind IN ('OPEN', 'CLOSE')),
    as_of        DATE   NOT NULL,
    file_name    TEXT,
    rows_n       INTEGER NOT NULL DEFAULT 0,
    qty_total    NUMERIC(24,4),
    amount_total NUMERIC(24,2),
    uploaded_by  BIGINT,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (taxpayer_id, kind, as_of)
);
CREATE TABLE IF NOT EXISTS stock_balance (
    file_id      BIGINT NOT NULL REFERENCES stock_balance_file(id) ON DELETE CASCADE,
    row_no       INTEGER NOT NULL,
    category     TEXT,
    name         TEXT,
    mxik         TEXT,
    unit         TEXT,
    qty          NUMERIC(24,4),
    amount       NUMERIC(24,2),
    PRIMARY KEY (file_id, row_no)
);
