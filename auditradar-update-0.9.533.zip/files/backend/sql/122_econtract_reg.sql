-- 0.9.242: my.soliq «Шартномаларни рўйхатдан ўтказиш» (econtract-api) — ёрдамчи маълумот, хатар чиқармайди.
-- direction: OUT — корхона юборган (owner), IN — корхонага юборилган (contra-agent).
CREATE TABLE IF NOT EXISTS econtract_reg (
    taxpayer_id  BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    contract_id  TEXT   NOT NULL,
    direction    TEXT   NOT NULL CHECK (direction IN ('OUT', 'IN')),
    contract_no  TEXT,
    contract_date DATE,
    expire_date  DATE,
    total_sum    NUMERIC(22,2),
    status       INTEGER,
    cp_tin       TEXT,
    cp_name      TEXT,
    products     TEXT,
    source       TEXT,
    collected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, contract_id, direction)
);
