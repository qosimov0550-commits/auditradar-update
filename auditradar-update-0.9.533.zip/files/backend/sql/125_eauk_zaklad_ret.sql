-- 0.9.247: e-auksion «Zaklad puli qaytarilishi uchun so'rov yuborildi» (ҳамёндан чиқим) — закалат банкка қайтарилди
UPDATE exchange_txn SET kind='WITHDRAW' WHERE platform_tin='305004780' AND kind='OTHER' AND debit > 0
   AND comment ~* 'zaklad' AND comment ~* 'so.?rov';
