-- 0.9.241: e-auksion (cabinet.e-auksion.uz) — ютилган лотлар (фақат ўқиш). Шахсий ҳисоб ҳаракатлари exchange_txn га
-- (platform_tin 305004780) ёзилади — биржа/РКП/Shaffof кўчирмалари билан бир хил тартибда.
CREATE TABLE IF NOT EXISTS auk_lot (
    taxpayer_id     BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    lot_number      TEXT   NOT NULL,
    lot_id          BIGINT,
    name            TEXT,
    address         TEXT,
    auction_date    DATE,
    start_price     NUMERIC(20,2),
    zaklad          NUMERIC(20,2),
    win_amount      NUMERIC(20,2),
    win_pay_amount  NUMERIC(20,2),
    paid_full       BOOLEAN,
    term_payment    BOOLEAN,
    status_name     TEXT,
    category_id     INTEGER,
    contract_no     TEXT,
    contract_date   DATE,
    contract_status TEXT,
    protocol_no     TEXT,
    collected_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, lot_number)
);
