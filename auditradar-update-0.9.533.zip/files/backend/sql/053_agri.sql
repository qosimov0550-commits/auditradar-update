-- Қишлоқ хўжалиги корхоналари (фермер хўжаликлари): қишлоқ хўжалиги ерлари учун ер солиғи ва сув солиғи — ҳисобот ва тўлов
ALTER TABLE tax_obligation DROP CONSTRAINT IF EXISTS tax_obligation_applies_check;
ALTER TABLE tax_obligation ADD CONSTRAINT tax_obligation_applies_check
    CHECK (applies IN ('ALL', 'QQS', 'AOS', 'PROFIT', 'DATA', 'NONE', 'NOAOS', 'BIG', 'AGRI'));

INSERT INTO tax_obligation(code, name, kind, applies, freq, due_day, year_month, year_day, year_offset, source, tax_codes, article, note, sort) VALUES
 ('LAND_AGRI', 'Ер солиғи (қишлоқ хўжалиги ерлари) — ҳисобот', 'REPORT', 'AGRI', 'Y', 20, 5, 1, 0, 'manual', '{53,58}', '431',
  'Жорий йилнинг 1 майидан кечиктирмай; экинзорлар ўзгарса — аниқлаштирилган ҳисобот 1 декабргача (СК 431-модда)', 73),
 ('LAND_AGRI_P1', 'Ер солиғи (қ/х ерлари) — тўлов, 30%', 'PAY', 'AGRI', 'Y', 20, 8, 31, 0, 'manual', '{53,58}', '432',
  'Йиллик солиқнинг 30% и — 1 сентябргача (СК 432-модда)', 74),
 ('LAND_AGRI_P2', 'Ер солиғи (қ/х ерлари) — тўлов, қолган қисми', 'PAY', 'AGRI', 'Y', 20, 11, 30, 0, 'manual', '{53,58}', '432',
  'Солиқнинг қолган суммаси — 1 декабргача (СК 432-модда)', 75),
 ('WATER_AGRI', 'Сув солиғи (қишлоқ хўжалиги корхонаси) — ҳисобот', 'REPORT', 'AGRI', 'Y', 20, 12, 15, 0, 'manual', '{52}', '447',
  'Жорий йилнинг 15 декабридан кечиктирмай (СК 447-модда)', 83),
 ('WATER_AGRI_P1', 'Сув солиғи (қ/х корхонаси) — тўлов, 70%', 'PAY', 'AGRI', 'Y', 20, 9, 30, 0, 'manual', '{52}', '448',
  'Солиқ органлари аниқлаган йиллик солиқнинг 70% и — 1 октябргача (СК 448-модда)', 84),
 ('WATER_AGRI_P2', 'Сув солиғи (қ/х корхонаси) — тўлов, қолган қисми', 'PAY', 'AGRI', 'Y', 20, 12, 14, 0, 'manual', '{52}', '448',
  'Солиқнинг қолган суммаси — 15 декабргача (СК 448-модда)', 85)
ON CONFLICT (code) DO NOTHING;
