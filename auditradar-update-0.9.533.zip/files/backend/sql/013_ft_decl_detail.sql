-- E-CONTRACT (contract.customs.uz) саҳифасидан кенгайтма ўқиган БЮД тафсилотлари: «Батафсил» ойнасидаги
-- майдонлар ва товар қаторлари (ТИФ ТН коди, номи, миқдори, фактура ва божхона қиймати...). Устун номлари
-- сайтдагидек сақланади (сайт ўзгарса ҳам маълумот йўқолмаслиги учун), қоидалар кейин шу асосда қурилади.
CREATE TABLE ft_decl_detail (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT      NOT NULL REFERENCES taxpayer(id),
    idn           VARCHAR(40),
    decl_full_no  TEXT        NOT NULL,
    decl_no       INTEGER,
    decl_date     DATE,
    kind          VARCHAR(10),
    regime        TEXT,
    value_text    TEXT,
    entered_text  TEXT,
    fields        JSONB       NOT NULL DEFAULT '{}'::jsonb,
    goods_columns JSONB       NOT NULL DEFAULT '[]'::jsonb,
    goods         JSONB       NOT NULL DEFAULT '[]'::jsonb,
    collected_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    collected_by  BIGINT      REFERENCES app_user(id),
    UNIQUE (taxpayer_id, decl_full_no)
);
CREATE INDEX ix_ft_decl_detail_no ON ft_decl_detail(taxpayer_id, decl_no, decl_date);
