-- 0.9.119: cargo.customs.uz — экспорт декларациялари (E-CONTRACT орқали кирилади, кенгайтма фақат ўқийди).
-- Декларант ЖШШИРи (insUser) ва бошқа шахсий маълумотлар сақланмайди. БЮД PDF нусхаси (/export/pdf/gtd/{id})
-- customs_pdf орқали ft_decl_pdf га ёзилади (матнли PDF — 20, 44, 47-графалар ҳам ўқилади).
CREATE TABLE IF NOT EXISTS ft_cargo_decl (
    taxpayer_id    BIGINT      NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    autodecl_id    TEXT        NOT NULL,
    uncod_id       TEXT,                    -- EK2026…
    decl_post      VARCHAR(10),
    decl_date      DATE,
    decl_no        INTEGER,
    state          SMALLINT,
    state_nm       TEXT,
    contract_idn   TEXT,
    contract_no    TEXT,
    contract_date  DATE,
    shipper        TEXT,
    receiver       TEXT,
    receiver_addr  TEXT,
    border_post    TEXT,
    t_type         TEXT,
    channel        SMALLINT,
    pay_total      NUMERIC(20,2),
    pay_paid       NUMERIC(20,2),
    ins_time       TIMESTAMP,
    upd_time       TIMESTAMP,
    first_seen     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, autodecl_id)
);
CREATE INDEX IF NOT EXISTS ix_ft_cargo_decl_no ON ft_cargo_decl(taxpayer_id, decl_no, decl_date);
