-- Солиқ API: тадбиркорлик субъекти тоифаси (1 — микрофирма, 2 — кичик, 3 — ўрта, 4 — йирик)
ALTER TABLE cp_soliq ADD COLUMN IF NOT EXISTS business_type TEXT;
-- шахсга доир маълумотлар (бош бухгалтер ва ҳ.к.) аввал сақланган жавоблардан олиб ташланади
UPDATE cp_soliq SET raw = raw - 'accountant' - 'director' WHERE raw IS NOT NULL;
UPDATE cp_soliq SET raw = jsonb_set(raw, '{company}', (raw->'company') - 'accountant' - 'director')
 WHERE raw ? 'company' AND jsonb_typeof(raw->'company') = 'object';
