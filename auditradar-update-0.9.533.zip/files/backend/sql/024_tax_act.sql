-- my.soliq.uz «Солиштирма далолатнома» — айни сана бўйича сальдо (ҳар бир ҳудуд ва солиқ коди).
CREATE TABLE IF NOT EXISTS tax_act_saldo (
    id            BIGSERIAL PRIMARY KEY,
    taxpayer_id   BIGINT  NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    as_of         DATE    NOT NULL,
    region        TEXT    NOT NULL DEFAULT '',
    tax_code      INTEGER NOT NULL,
    tax_name      TEXT,
    debt          NUMERIC(20,2) NOT NULL DEFAULT 0,   -- солиқ қарзи (saldoTekNed)
    debt_deferred NUMERIC(20,2) NOT NULL DEFAULT 0,   -- кечиктирилган (saldoTekNedOts)
    penalty       NUMERIC(20,2) NOT NULL DEFAULT 0,   -- пеня (saldoTekPen)
    penalty_deferred NUMERIC(20,2) NOT NULL DEFAULT 0,
    overpay       NUMERIC(20,2) NOT NULL DEFAULT 0,   -- ортиқча тўлов (saldoTekPer)
    fetched_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tax_act_saldo_tp ON tax_act_saldo(taxpayer_id);
