-- Норматив ҳужжатлар ва қўшимча қўлланмалар реестри («Норматив ҳужжатлар» бўлими)
CREATE TABLE IF NOT EXISTS normdoc (
    id          BIGSERIAL PRIMARY KEY,
    kind        TEXT NOT NULL DEFAULT 'other',      -- code|law|decree|resolution|order|letter|guide|other
    title       TEXT NOT NULL,
    doc_number  TEXT,
    doc_date    DATE,
    valid_from  DATE,
    valid_to    DATE,
    topic       TEXT,                                -- ҚҚС, акциз, фойда солиғи, ЖШДС, валюта назорати ...
    link        TEXT,
    note        TEXT,
    files       JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_by  BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS normdoc_topic ON normdoc(topic);
