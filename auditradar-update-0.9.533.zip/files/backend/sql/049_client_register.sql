-- Мижозлар реестри: бириктирилган солиқ тўловчилар рўйхатидан (ҳудуд, фаолият тури, ташкил топган сана) ва йиллик айланма
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS region_code TEXT;
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS region_name TEXT;
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS activity    TEXT;
ALTER TABLE taxpayer ADD COLUMN IF NOT EXISTS founded_on  DATE;

CREATE TABLE IF NOT EXISTS client_turnover (
    taxpayer_id BIGINT NOT NULL REFERENCES taxpayer(id) ON DELETE CASCADE,
    year        INT    NOT NULL,
    months      INT    NOT NULL DEFAULT 12 CHECK (months BETWEEN 1 AND 12),   -- жорий йил: неча ойлик
    amount      NUMERIC(20,2) NOT NULL,
    source      TEXT   NOT NULL DEFAULT 'list',                               -- list — юкланган рўйхатдан
    user_id     BIGINT REFERENCES app_user(id) ON DELETE SET NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (taxpayer_id, year)
);
