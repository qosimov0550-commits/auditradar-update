-- 0.9.408: проводкалар ўзгармаган бўлса gl_entry қайта ёзилмайди (база ўсишининг олдини олиш)
ALTER TABLE gl_settings ADD COLUMN IF NOT EXISTS e_hash TEXT;
