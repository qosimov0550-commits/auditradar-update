-- 0.9.185: жисмоний шахс СТИРи → ЖШШИР (Солиқ қўмитаси операторидан — new.soliqservis.uz, мижоз ЭРИ сессияси билан).
-- Банкда жисмоний шахс 9 хонали СТИР билан, ЭҲФ да эса ЖШШИР билан — сунъий дебитор/кредиторнинг олдини олиш учун.
CREATE TABLE IF NOT EXISTS person_tin (
    tin         VARCHAR(9)  PRIMARY KEY,
    pinfl       VARCHAR(14),
    name        TEXT,
    source      TEXT        NOT NULL DEFAULT 'SOLIQSERVIS',
    status      TEXT        NOT NULL DEFAULT 'OK',          -- OK | NOT_FOUND | ERROR
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
