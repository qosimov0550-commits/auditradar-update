-- 0.9.443: «Қайта йиғиш» рўйхатида ОНКМ бошланишидан олдинги ойлар (ФМ ҳали бўлмаган — чек йўқ) доим «…» да қоларди
-- (LATIF BUILD: 2025-01…07). Шундай белгилар ўчирилади.
DELETE FROM nkm_recollect r
WHERE NOT EXISTS (SELECT 1 FROM nkm_month m WHERE m.taxpayer_id = r.taxpayer_id AND m.y = r.y AND m.m = r.m)
  AND EXISTS (SELECT 1 FROM nkm_month m WHERE m.taxpayer_id = r.taxpayer_id)
  AND (r.y * 100 + r.m) < (SELECT MIN(m.y * 100 + m.m) FROM nkm_month m WHERE m.taxpayer_id = r.taxpayer_id);
