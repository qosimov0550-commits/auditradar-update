-- dep.customs.uz акт-сверкаси: қайси ҳудуд (УГТК коди) ва йил қачон олингани (бўш акт ҳам). Ёпилган йиллар қайта
-- сўралмаслиги учун (ҳар бир йиғишда 15 ҳудуд × бир неча йил сўраш кўп вақт оларди).
CREATE TABLE IF NOT EXISTS ft_customs_act_fetch (
    taxpayer_id BIGINT      NOT NULL REFERENCES taxpayer(id),
    ugtk        VARCHAR(8)  NOT NULL,
    year        INTEGER     NOT NULL,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    rows        INTEGER     NOT NULL DEFAULT 0,
    PRIMARY KEY (taxpayer_id, ugtk, year)
);

-- аввал кенгайтма юклаган актлар (файл номи akt_sverka_<УГТК>_<йил>.xls) — бўш бўлмаганлари
INSERT INTO ft_customs_act_fetch(taxpayer_id, ugtk, year, fetched_at, rows)
SELECT i.taxpayer_id, m.v[1], m.v[2]::int, MAX(i.imported_at), COUNT(a.id)
FROM data_import i
JOIN LATERAL (SELECT regexp_match(i.file_name, '^akt_sverka_(\d{3,6})_(\d{4})') AS v) m ON m.v IS NOT NULL
LEFT JOIN ft_customs_act_row a ON a.data_import_id = i.id
WHERE i.source = 'CUSTOMS_ACT'
GROUP BY i.taxpayer_id, m.v[1], m.v[2]
ON CONFLICT DO NOTHING;
