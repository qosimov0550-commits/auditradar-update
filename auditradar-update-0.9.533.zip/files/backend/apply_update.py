"""
Янгилашни ўрнатишнинг якуний қадами — сервер тўхтагандан кейин алоҳида жараёнда ишлайди.
    python apply_update.py <лойиҳа илдизи> <очилган пакет папкаси>
1) эски код updates/backup_<версия>_<вақт>/ га сақланади; 2) янги файллар қўйилади (backend/app, frontend/dist ва extension
тўлиқ алмаштирилади, қолганлари устига ёзилади); 3) сервер қайта ишга туширилади (миграциялар шунда қўлланади).
Хато бўлса эски код қайтарилади ва сервер эски версияда ишга тушади.
"""
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

REPLACE = ('backend/app', 'frontend/dist', 'extension')     # тўлиқ алмаштириладиган папкалар (эскирган файллар қолмаслиги учун)


def _retry(fn, *a):
    """0.9.438: Windows да сервер жараёни ёки антивирус файлни (масалан, lxml .pyd) бир неча сония ушлаб туриши мумкин —
    ўчириш 45 сониягача қайта уринилади."""
    for i in range(30):
        try:
            return fn(*a)
        except PermissionError:
            if i == 29:
                raise
            time.sleep(1.5)


def _replace_dir(src, dst):
    """dst папкасининг ўзини сақлаб (Windows ҳуқуқлари ва умумий папка — масалан, кенгайтма учун berilgan icacls —
    йўқолмаслиги учун), ичидагини src билан алмаштиради."""
    if dst.is_dir():
        for ch in dst.iterdir():
            if ch.is_dir() and not ch.is_symlink():
                _retry(shutil.rmtree, ch)
            else:
                _retry(ch.unlink)
    else:
        dst.mkdir(parents=True)
    shutil.copytree(src, dst, dirs_exist_ok=True)


def main():
    root, staged = Path(sys.argv[1]), Path(sys.argv[2])
    log_file = root / 'logs' / 'server.log'

    def log(msg):
        try:
            log_file.parent.mkdir(exist_ok=True)
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} [янгилаш] {msg}\n")
        except OSError:
            pass

    time.sleep(3)                                            # сервер жараёни тўлиқ чиқиб кетсин
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    old_ver = 'eski'
    try:
        txt = (root / 'backend' / 'app' / 'version.py').read_text(encoding='utf-8')
        old_ver = txt.split("VERSION = '")[1].split("'")[0]
    except Exception:
        pass
    backup = root / 'updates' / f'backup_{old_ver}_{stamp}'
    files = [p.relative_to(staged) for p in staged.rglob('*') if p.is_file() and p.name != 'update.json']
    done_dirs, done_files = [], []
    try:
        backup.mkdir(parents=True)
        for d in REPLACE:
            if (staged / d).is_dir() and (root / d).is_dir():
                (backup / d).parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(root / d, backup / d, ignore=shutil.ignore_patterns('__pycache__'))
        for rel in files:
            if any(str(rel).replace('\\', '/').startswith(d + '/') for d in REPLACE):
                continue
            if (root / rel).is_file():
                (backup / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(root / rel, backup / rel)
        for d in REPLACE:
            if (staged / d).is_dir():
                done_dirs.append(d)
                _replace_dir(staged / d, root / d)
        for rel in files:
            if any(str(rel).replace('\\', '/').startswith(d + '/') for d in REPLACE):
                continue
            (root / rel).parent.mkdir(parents=True, exist_ok=True)
            done_files.append(rel)
            shutil.copy2(staged / rel, root / rel)
        # 0.9.320: манбасиз (ҳимояланган) пакет — серверда очиқ манба қолмайди: тестлар ва ишлаб чиқиш скриптлари олиб ташланади
        try:
            import json as _j
            man = _j.loads((staged / 'update.json').read_text(encoding='utf-8')) if (staged / 'update.json').is_file() else {}
        except Exception:
            man = {}
        if man.get('protected'):
            if (root / 'backend' / 'tests').is_dir():
                shutil.rmtree(root / 'backend' / 'tests', ignore_errors=True)
            for p in (root / 'scripts').glob('*.py') if (root / 'scripts').is_dir() else []:
                p.unlink(missing_ok=True)
            for d in ('scripts', 'backend'):
                pc = root / d / '__pycache__'
                if pc.is_dir():
                    shutil.rmtree(pc, ignore_errors=True)
        log(f'янги версия файллари қўйилди ({len(files)} та файл); эски код: updates/{backup.name}')
        shutil.rmtree(staged, ignore_errors=True)
    except Exception as e:                                   # ярим ўрнатилган ҳолатда қолмаслик учун эски код қайтарилади
        log(f'ХАТО: {type(e).__name__}: {e} — эски версия қайтарилмоқда')
        try:
            for d in done_dirs:
                if (backup / d).is_dir():
                    _replace_dir(backup / d, root / d)
            for rel in done_files:
                if (backup / rel).is_file():
                    shutil.copy2(backup / rel, root / rel)
            log('эски версия қайтарилди')
        except Exception as e2:
            log(f'ЭСКИ ВЕРСИЯНИ ҚАЙТАРИБ БЎЛМАДИ: {type(e2).__name__}: {e2} — updates/{backup.name} дан қўлда тикланг')
    flags = 0x00000008 | 0x08000000 if sys.platform == 'win32' else 0
    subprocess.Popen([sys.executable, str(root / 'backend' / 'launcher.py'), '--wait-port'], creationflags=flags, close_fds=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == '__main__':
    main()
