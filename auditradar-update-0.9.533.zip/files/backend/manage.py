"""
Аудит Радар — бошқарув буйруқлари.

    python manage.py migrate                      — базани яратиш/янгилаш
    python manage.py create-user <логин> "<Ф.И.Ш.>" [--admin]
    python manage.py import <мижоз СТИРи> <папка>  — папкадаги my3 файлларини юклаш (браузерсиз)
    python manage.py rescan <мижоз СТИРи>          — топилмаларни қайта ҳисоблаш
    python manage.py run [--port 8000]            — серверни ишга тушириш
    python manage.py sinov                        — автоматик тестлар (алоҳида auditradar_test базасида; ишчи базага тегмайди)
    python manage.py zaxira-och <файл.arbk>       — шифрланган захира нусхасини очиш (янги компьютерда тиклаш учун):
                                                    база backups/ га .dump бўлиб ёзилади, storage/ файллари қайтарилади
"""
import argparse
import getpass
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.db import connect, migrate  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description='Аудит Радар бошқарув буйруқлари')
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('migrate')
    cu = sub.add_parser('create-user')
    cu.add_argument('login')
    cu.add_argument('full_name')
    cu.add_argument('--admin', action='store_true')
    cu.add_argument('--allow-short', action='store_true', help='8 белгидан қисқа паролга рухсат (фақат синов учун)')
    im = sub.add_parser('import')
    im.add_argument('tin')
    im.add_argument('folder')
    im.add_argument('--all-versions', action='store_true')
    rs = sub.add_parser('rescan')
    rs.add_argument('tin')
    rn = sub.add_parser('run')
    rn.add_argument('--port', type=int, default=8000)
    rn.add_argument('--host', default='127.0.0.1')
    sub.add_parser('sinov')
    tr = sub.add_parser('totp-reset', help='икки босқичли киришни ўчириш (телефон йўқолса, шошилинч — сервер компьютерида)')
    tr.add_argument('login')
    zx = sub.add_parser('zaxira-och')
    zx.add_argument('file')
    zx.add_argument('--no-storage', action='store_true')
    a = ap.parse_args()

    if a.cmd == 'sinov':
        import subprocess
        run = Path(__file__).resolve().parent / 'tests' / 'run.py'
        if not run.exists():
            sys.exit('Тестлар бу нусхада йўқ (серверга 0.9.96 дан бошлаб келади).')
        sys.exit(subprocess.run([sys.executable, str(run)]).returncode)
    if a.cmd == 'totp-reset':
        from app.auth import log
        with connect() as conn:
            r = conn.execute("""UPDATE app_user SET totp_secret_enc=NULL, totp_pending_enc=NULL, totp_last_step=NULL, totp_recovery=NULL,
                                totp_enabled_at=NULL, session_ver=session_ver+1 WHERE login=%s RETURNING id""", (a.login,)).fetchone()
            if not r:
                sys.exit('Бундай логин йўқ.')
            from app.login_qr import revoke_all
            revoke_all(conn, r['id'])
            log(conn, r['id'], 'totp_reset_console', details={'login': a.login})
        print(f'{a.login}: икки босқичли кириш ўчирилди. Тизимга логин ва парол билан кириб, уни қайта ёқинг.')
        return
    if a.cmd == 'migrate':
        migrate()
        print('База тайёр.')
    elif a.cmd == 'create-user':
        from app.auth import hash_password
        pw = os.environ.get('AR_NEW_PASSWORD') or getpass.getpass('Парол (камида 8 белги): ')
        if len(pw) < 8 and not a.allow_short:
            sys.exit('Парол камида 8 белгидан иборат бўлиши керак.')
        if len(pw) < 8:
            print('Огоҳлантириш: парол қисқа. Синовдан кейин уни алмаштиринг.')
        with connect() as conn:
            conn.execute("""INSERT INTO app_user(login, full_name, password_hash, role) VALUES (%s,%s,%s,%s)
                            ON CONFLICT (login) DO UPDATE SET password_hash=EXCLUDED.password_hash,
                            full_name=EXCLUDED.full_name, role=EXCLUDED.role, is_active=TRUE""",
                         (a.login, a.full_name, hash_password(pw), 'admin' if a.admin else 'auditor'))
        print(f'Фойдаланувчи сақланди: {a.login}')
    elif a.cmd in ('import', 'rescan'):
        from app import findings
        from app.loaders import my3
        import json
        with connect() as conn:
            tp = conn.execute('SELECT id, tin FROM taxpayer WHERE tin=%s', (a.tin,)).fetchone()
            if not tp:
                tp = conn.execute("INSERT INTO taxpayer(tin, name, tax_regime) VALUES (%s,%s,'QQS') RETURNING id, tin",
                                  (a.tin, a.tin)).fetchone()
                print('Янги мижоз яратилди (номини интерфейсда тўғриланг).')
            if a.cmd == 'import':
                folder = Path(a.folder)
                for j in folder.glob('vat_journal*.json'):
                    n = my3.import_journal(conn, tp['id'], json.loads(j.read_text(encoding='utf-8')))
                    print(f'Журнал: {n} ёзув')
                stats, warns = my3.import_files(conn, tp['id'], tp['tin'], [str(p) for p in folder.iterdir()],
                                                None, 'манба: буйруқ сатри', a.all_versions)
                print('Юклаш:', stats)
                for w in warns:
                    print('  огоҳлантириш:', w)
            new, upd, closed = findings.run(conn, tp['id'])
            print(f'Топилмалар: янги {new}, янгиланган {upd}, ёпилган {closed}')
    elif a.cmd == 'zaxira-och':
        from app import zaxira as Z
        from app.config import BASE_DIR, ROOT_DIR, STORAGE_DIR
        src = Path(a.file).resolve()
        pw = os.environ.get('AR_ZAXIRA_PAROL') or getpass.getpass('Захира пароли: ')
        try:
            r = Z.open_bundle(src, pw, ROOT_DIR / 'backups', None if a.no_storage else STORAGE_DIR, env_to=BASE_DIR / '.env.zaxiradan')
        except (ValueError, FileNotFoundError) as e:
            sys.exit(f'Очилмади: {e}')
        print(f"Тайёр: backups/{r['dump']} (нусха {r['created']}), storage файллари: {r['restored_files']}.")
        print('Кейин: install.bat (ёки платформада Созламалар → «Захирадан тиклаш») шу .dump файлни танлаб тиклайди.')
        adopt_key(BASE_DIR)
    elif a.cmd == 'run':
        import uvicorn
        uvicorn.run('app.main:app', host=a.host, port=a.port)


def _env_key(path):
    if not path.is_file():
        return None
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if line.strip().startswith('AR_SECRET_KEY='):
            return line.split('=', 1)[1].strip()
    return None


def adopt_key(base):
    """0.9.117: эски сервер калитини (AR_SECRET_KEY) .env га кўчириш — 2FA калитлари, E-CONTRACT ва Солиқ API пароллари,
    телефон хабарномаси шу калит билан шифрланган. Кўчирилмаса — 2FA ёқилган ходимлар фақат захира код билан кира олади."""
    env, old = base / '.env', base / '.env.zaxiradan'
    ok, cur = _env_key(old), _env_key(env)
    if not ok:
        print('Захирада сервер калити (AR_SECRET_KEY) йўқ — ўзгартирилмади.')
        return
    if ok == cur:
        print('Сервер калити (AR_SECRET_KEY) эски сервер билан бир хил — ҳаммаси жойида.')
        return
    ans = (os.environ.get('AR_ZAXIRA_KEY') or input(
        'Эски сервер калити (AR_SECRET_KEY) жорийсидан фарқ қилади. 2FA, E-CONTRACT ва Солиқ API пароллари ишлаши учун\n'
        'уни .env га кўчириш керак (жорий .env — .env.bak га сақланади). Кўчирайми? [Y/n]: ')).strip().lower()
    if ans not in ('', 'y', 'yes', 'ha', 'h', 'ҳа', 'да', 'д'):
        print('Кўчирилмади. Кейин қўлда: backend\\.env.zaxiradan даги AR_SECRET_KEY қаторини backend\\.env га кўчиринг.')
        return
    text = env.read_text(encoding='utf-8-sig') if env.is_file() else ''
    if env.is_file():
        (base / '.env.bak').write_text(text, encoding='utf-8')
    lines = [ln for ln in text.splitlines() if not ln.strip().startswith('AR_SECRET_KEY=')]
    lines.append(f'AR_SECRET_KEY={ok}')
    env.write_text('\n'.join(lines).strip() + '\n', encoding='utf-8')
    print('Сервер калити кўчирилди. Платформани қайта ишга туширинг (start.bat ёки компьютерни қайта ёқинг).')


if __name__ == '__main__':
    main()
