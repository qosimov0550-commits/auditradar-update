# Information Security and Professional Ethics Policy for Use of the «Аудит Радар» Platform

Version: 1.0 · Effective date: 11 October 2026 · Approved by: Sh.A. Karimov, Director of "FISCAL AUDIT" MCHJ AT

## 1. General Provisions

1.1. This Policy establishes the rules under which employees of "FISCAL AUDIT" MCHJ AT, an audit organization (hereinafter the Organization), use the «Аудит Радар» platform (hereinafter the Platform), its browser extension, and the client data obtained through them.

1.2. The Policy is based on the Law of the Republic of Uzbekistan "On Auditing Activity" (25 February 2021, No. ZRU-677), the Law "On Personal Data" (2 July 2019, No. ZRU-547), the Code of Ethics for Professional Accountants, and the service agreements concluded with clients. As an internal rule, it may be stricter than the requirements of the law.

1.3. The Policy applies to all employees who use the Platform: the administrator, auditors, and accountants. Before starting work on the Platform, an employee reads the Policy and confirms acceptance of it both on the Platform ("I have read it and will comply") and in writing. When the Policy changes, acknowledgement is confirmed again.

## 2. Professional Ethics, Objectivity, and Confidentiality

2.1. **Objectivity and integrity.** Auditors and accountants using the Platform must uphold the primacy of the public interest, remain impartial, base their opinions on evidence rather than assumptions, not compromise their professional judgement because of a conflict of interest or pressure from other persons, and not allow situations that adversely affect the reputation of the Organization (ZRU-677, Articles 5 and 6).

2.2. **Confidentiality.** Employees using the Platform are not entitled to disclose or pass on to others information that became known to them in the course of providing audit and accounting services without the written consent of the persons to whom the services were provided, except in the cases provided for by anti-corruption legislation and by legislation on combating the legalization of proceeds from criminal activity, the financing of terrorism, and the financing of the proliferation of weapons of mass destruction (ZRU-677, Article 8 and Article 29). This obligation continues to apply after the employee leaves the Organization.

2.3. In the cases provided for by law, information is provided only by decision of the head of the Organization and in writing. The employee does not fulfil such a request independently but immediately refers it to the head of the Organization.

2.4. **Independence.** It is prohibited to conduct an audit of an enterprise whose accounting is maintained (or was maintained during the period under review) by the Organization (ZRU-677, Article 34). On the Platform, clients are divided into the "Accounting" and "Audit" groups; a single enterprise cannot be in both groups. Internal audit is an exception.

2.5. **Conflict of interest.** If an employee is aware of a conflict of interest with respect to a client (kinship, a financial interest, previous employment at that enterprise, etc.), the employee clicks the "Conflict of interest — I recuse myself" button on that client's page on the Platform and informs the head of the Organization. Thereafter the employee's access to that client's data is closed; only the administrator may reopen it.

2.6. **Safeguard against pressure.** Findings identified on the Platform are not deleted. A finding may be moved to the "Found to be unsubstantiated" state only when a justification (comment) is recorded; all changes are kept in the history together with who made them and when.

2.7. When facts are identified that clearly confirm serious violations of accounting legislation or corruption-related offences, the employee reports this to the head of the Organization; the management of the business entity is notified by the Organization in writing (ZRU-677, Article 29).

## 3. Electronic Digital Signature (ERI) and Tax Cabinets

3.1. The e-signature (ERI) password is entered only by the ERI holder or by an employee authorized by the holder, in person. The Platform and the extension do not store the ERI key or password; the employee likewise does not write the password down, tell it to anyone, or send it in messages.

3.2. It is prohibited to copy e-signature (ERI) key files (pfx, etc.), transfer them to another computer or a flash drive, or upload them to cloud services. The password is not written in the key file name.

3.3. The Platform and the extension **only read data** from the tax cabinets (my3.soliq.uz, my.soliq.uz, Солиқсервис, customs systems). In the tab where the extension is running, the employee does not sign, submit, edit, or delete anything; accepting, rejecting, or signing e-invoices is not performed through the Platform.

3.4. A client's e-signature (ERI) is used only for work on that client and only within the scope of the service agreement.

## 4. Client Data

4.1. Client data on the Platform (e-invoices, reports, bank statements, payroll, findings) and the files generated from it (Excel, PDF, backups) are not taken outside the Organization's server and the employee's work computer.

4.2. Transferring client files via Telegram, WhatsApp and other messengers, personal e-mail, OneDrive, Google Drive and other cloud services, or flash drives is prohibited. Files are provided to the client in the manner established by the head of the Organization.

4.3. Every file downloaded from the Platform (Excel, etc.) is recorded in the log: who, for which client, and when. Once the work is complete, copies that are no longer needed are deleted from the computer.

4.4. Data relating to individuals (employees, customers, PINFL) is used solely for official purposes and, unless necessary, is shown in reports in abbreviated form.

4.5. **Retention period.** Information and conclusions relating to an audit are retained for at least 5 years (ZRU-677, Article 29). A client is deleted from the Platform only by the administrator, with the reason stated; before deletion, a backup of the entire database is taken and retained for 5 years.

## 5. Access, Passwords, and the Workplace

5.1. Each employee logs in to the Platform only with their own login. Giving one's login and password to another person, or working under another employee's login, is prohibited.

5.2. A password must consist of at least 8 characters, differ from passwords used for other services, and must not be visible in screenshots or documents. If there is any suspicion that a password has become known to others, it is changed immediately (Settings → "Change password").

5.3. When stepping away from the computer, the employee locks the screen (**Win + L**). At the end of the working day, the employee logs out of the Platform.

5.4. The Platform is accessed in the office via its network address and from home only through the secure connection designated by the Organization (Tailscale). Old or test copies of the Platform and third-party computers are not used.

5.5. The browser extension is installed only by the official method indicated on the Platform (ulanish.bat, the network drive, or the Chrome Web Store). Extensions obtained from other sources are not installed. It is recommended not to conduct personal activities in the Chrome profile in which the extension is installed.

## 6. Rights and Roles

6.1. **Administrator** — users, updates, backups, client deletion, announcements, and lifting a conflict-of-interest restriction.

6.2. **Auditor** and **accountant** — working with clients, data collection, analysis, and findings. The right to post announcements is granted separately by the administrator.

6.3. When an employee leaves or moves to another position, their login is deleted or their rights are changed on the same day.

## 7. Incident Reporting

7.1. In the following cases the employee immediately (within 1 hour) notifies the head of the Organization:
- when the Platform password or the e-signature (ERI) password has become known to another person;
- when an e-signature (ERI) key, a computer, or a flash drive is lost or stolen;
- when client data has been transferred or disclosed without authorization;
- when an unusual situation is observed on the Platform (unauthorized login, altered data, an unexplained message).

7.2. The head of the Organization assesses the incident, arranges for passwords and keys to be changed, and notifies the client where necessary. The incident and the measures taken are recorded.

## 8. Oversight and Liability

8.1. All significant actions on the Platform (login, data upload, file download, change of finding status, announcements) are recorded in the log. The log is reviewed by the head of the Organization and the administrator.

8.2. Violation of this Policy entails disciplinary liability and, in the cases provided for by law, other liability (ZRU-677, Article 51).

8.3. The Policy is reviewed at least once a year, as well as whenever the law or the Platform changes. The new version is published on the Platform and is re-acknowledged by all employees.
