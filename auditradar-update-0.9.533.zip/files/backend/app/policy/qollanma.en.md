# «Audit Radar» platform — user guide

Version: 2.0 · October 2026 · "FISCAL AUDIT" MCHJ AT

This guide is for auditors and accountants: which task is done where. Technical details of each update are in the “Change log” (button at the top of this page).

## 1. What the platform does

- Gathers a client’s tax and accounting data in one place — from government systems (my.soliq, e-invoices, online cash registers, customs, exchange, etc.) and from uploaded files (bank statements, 1C).
- Cross-checks them and shows risky situations as **findings** — before the tax authority sees them.
- Prepares working papers in Excel: VAT, bank, receivables-payables, payroll, foreign trade and more.
- The platform **only reads**: it does not file reports, sign e-invoices or change anything in the tax cabinet.

## 2. First day: sign-in and setup

- **Sign-in.** At the office — open the address given by the administrator. From home — only with Tailscale on. Enter your login and password.
- **Policy.** On first sign-in the “Security and professional ethics policy” opens — read it and press “I have read and will comply”.
- **Password and 2FA.** Settings → “My account”: change your password (at least 8 characters). Turn on two-step sign-in by phone under “2FA”.
- **Language.** At the bottom of the left menu: Uzbek (Cyrillic / Latin), Russian, English.
- **Extension.** Collecting with a digital signature needs the “Audit Radar — collector” Chrome extension: install it per Settings → “Extension”. Status “Installed and connected” means ready.

## 3. Working with a client (in brief)

1) Add the client and set the **analysis period** (section 4).
2) Run “Collect with E-IMZO (signature)” (section 5).
3) Upload files not available in government systems: bank statements, 1C trial balance, etc. (section 6).
4) Review **Overview** and the sections (section 7), work through the **findings** (section 8).
5) Download the Excel report (section 9).

## 4. Adding a client and the analysis period

- **Adding.** “Clients” → “Add via client’s signature” (company data is fetched automatically) or “+ Add manually” (enter the TIN, the name is filled from the registry).
- **Group.** “Accounting” — companies whose books we keep; “Audit” — companies under audit. A company cannot be in both.
- **Analysis period.** “Period start / end” at the top of the client page. All analysis, findings and Excel follow this period.
- **Source settings.** Choose which data to collect for this client (VAT, e-invoices, cash registers, payroll, customs, exchange, etc.).
- **Conflict of interest.** If you have a personal link to the client: “Edit” → “Conflict of interest…”. Access to that client is then closed.

## 5. Collecting data (with a signature)

- On the client page press **“Collect with E-IMZO (signature)”**. The collector window opens with the client’s name and TIN at the top.
- Check that the company in the E-IMZO window is this client and **enter the signature password yourself**. The platform does not store the key or password.
- Do not close the window or work in it until collection ends. Each step shows its result; the last step is “Analysis and findings”.
- On the next collection, data already received is not requested again, so it is faster.
- **Several clients at once** — each in a separate Chrome profile (install the extension in each). One client cannot be collected from two places at once.
- **Signature queue** (in “Clients”) — clients not refreshed for 7 days. **“Refresh all”** — data obtained without a signature (exchange rate, customs API).

## 6. Uploading files

Files are uploaded via “Upload file” on the client page or the button in the relevant section. Never pass client data via messengers, personal e-mail or USB sticks.
- **Bank statements** (Excel, all accounts) — “Bank” section. Later it is enough to upload only the new days.
- **1C trial balance** — “Accounting (trial balance)”.
- **Opening / closing balances:** counterparties (4010, 6010, etc.) — “Receivables-payables” → “Balances”; employees (6710) — “Payroll” → “Balances and cash payroll sheets”.
- **Cash payroll sheets** — “Payroll” → “Balances and cash payroll sheets”.
- **Exchange and auction account statement** — “Bank” → “Exchanges and auctions”.
- Each section has a “Template” button — fill in that Excel form and upload it.

## 7. Client page sections

- **Overview** — risk score, company data, VAT returns ↔ e-invoices reconciliation, main findings.
- **Bank** — statements, payment types, receipts ↔ VAT return, accounts with no statement (per the my.soliq list), exchanges and auctions.
- **Receivables-payables** — balances by counterparty (e-invoices + bank), ageing, opening and closing balances, reconciliation with 1C.
- **Payroll** — accrued wages and taxes, account 6710 settlements per employee (opening → accrued → card / cash → closing ↔ 1C), deductible and non-deductible payments for profit tax.
- **Budget settlements** — personal tax account: accrued, paid, arrears and overpayment; customs payments are reconciled with the VAT register.
- **Foreign trade** — export and import contracts, customs declarations, repatriation deadlines, payments to non-residents, logistics.
- **Online cash registers** — receipts, fiscal modules, register revenue ↔ VAT return ↔ bank.
- **Inventory** — goods in and out (e-invoices, customs declarations, receipts), opening and closing stock.
- **Accounting (trial balance)** — trial balance, balance sheet, financial result, profit tax calculation.
- **Counterparties** — registry status, “suspicious” companies, tax arrears.
- **Documents** — outgoing e-invoice builder and receipt acts without e-invoices.
- **Accounting control** — document register, month-end close checklist and quality indicators (outsourcing processes).
- **Audit** — data completeness matrix, audit programme and written report (for clients in the “Audit” group).
- **Excise** — analysis of excise tax returns.
Most cards have a note underneath explaining what they show and how they are calculated.

## 8. Findings

- Each finding shows what was found, evidence, recommendation and the **basis in auditing standards** (ISA and paragraph).
- **Levels:** High, Medium, Low and Opportunity (a situation in the client’s favour).
- **Statuses:** New → Under review → Sent to client → Resolved. “Found groundless” requires a reason.
- After data is refreshed, findings are recalculated: if the difference is gone the finding closes itself, keeping its history.

## 9. Excel reports

- “Download to Excel” on the client page gives the main report for the analysis period; each section has its own Excel button.
- ⚙ — choose sheets and columns. “For client” — a copy without internal data.
- Each sheet starts with its purpose. Downloads are logged.

## 10. Calendar, tasks, letters and notifications

- **Calendar** — reporting deadlines by month and each client’s filing status.
- **Tasks** — assign, do and review: New → In progress → Under review → Accepted.
- **Letters** (a client page section) — tax authority letters (my.soliq “Relations”), assignee and reply deadline.
- **Notifications** — collection results, new high-risk findings, deadlines and announcements. Link Telegram: “Staff” → “My details”.
- **Outsourcing monitor** — work quality and service cost across all clients (for the manager).

## 11. Security — key rules

- Only you enter the signature password; never tell it to anyone or write it down.
- When leaving the computer press **Win + L**; when done — “Sign out”.
- Do not move client data to personal devices, messengers or cloud services.
- In a suspicious situation (password exposed, computer lost) tell your manager within 1 hour. Full rules are in the “Rules” section.

## 12. For the administrator

- **Users** — add, role, rights, “Active” flag (cleared when an employee leaves).
- **Update** — once a new version is placed in the “updates” folder, install it from Settings → “Update”.
- **Backup** — automatic every day at 22:00; backup destinations and “Restore test” are here. Run a restore test on another computer once a year.
- **HTTPS, Network and IP, Risk and API** — encrypted connection, allowed addresses and the Tax Committee API key.
- Technical details and per-version changes — the “Change log”.

## 13. Frequent questions

- **Extension not connected** — Settings → “Extension” → “Reconnect”.
- **Signature window closed or collection stopped** — start again; data already received is kept.
- **“Being collected in another window”** — this client is being collected elsewhere; wait for it to finish.
- **Finding is wrong** — choose “Found groundless” and give the reason; later analyses take it into account.
- **Platform does not open** — check the server computer is on and, from home, that Tailscale is on; tell the administrator.

## 14. Help

Questions and suggestions go to the administrator. When reporting an error give the client, section, time and a screenshot (no passwords).
