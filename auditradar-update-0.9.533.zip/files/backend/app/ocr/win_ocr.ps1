﻿# Аудит Радар 0.9.142: Windows ўз OCR механизми (Windows.Media.Ocr) билан PDF/расмни ўқиш. Ҳеч қандай дастур
# ўрнатилмайди, файл компьютердан чиқмайди; матн stdout га (UTF-8) чиқарилади ва фақат рақам/сана ажратиб олиш учун ишлатилади.
param([Parameter(Mandatory = $true)][string]$Path, [int]$MaxPages = 4)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$ext = [System.WindowsRuntimeSystemExtensions].GetMethods()
$asTaskOp = ($ext | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
$asTaskAct = ($ext | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
function Await($op, [Type]$t) { $task = $asTaskOp.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }
function AwaitAction($op) { $task = $asTaskAct.Invoke($null, @($op)); $task.Wait(-1) | Out-Null }
[void][Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
[void][Windows.Storage.FileAccessMode,Windows.Storage,ContentType=WindowsRuntime]
[void][Windows.Storage.Streams.IRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
[void][Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
[void][Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
[void][Windows.Media.Ocr.OcrResult,Windows.Foundation,ContentType=WindowsRuntime]
[void][Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
[void][Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime]
[void][Windows.Data.Pdf.PdfPageRenderOptions,Windows.Data.Pdf,ContentType=WindowsRuntime]
[void][Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics,ContentType=WindowsRuntime]
[void][Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics,ContentType=WindowsRuntime]

$engines = @()
$avail = @()
try { $avail = @([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) } catch { }
# 0.9.144: ўрнатилган OCR тилларидан en, ru, zh (хитой сертификатлари) — ҳаммаси; бўлмаса бошқа ҳар қандай ўрнатилгани
foreach ($l in $avail) {
  if ($l.LanguageTag -match '^(en|ru|zh)') { try { $e = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($l); if ($e) { $engines += $e } } catch { } }
}
if (-not $engines.Count) {
  foreach ($l in $avail) { try { $e = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($l); if ($e) { $engines += $e; break } } catch { } }
}
if (-not $engines.Count) { try { $e = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages(); if ($e) { $engines += $e } } catch { } }
if (-not $engines.Count) { Write-Output ('NO_OCR_ENGINE avail=' + (($avail | ForEach-Object { $_.LanguageTag }) -join ',')); exit 3 }
$seen = @{}
$engines = $engines | Where-Object { $k = $_.RecognizerLanguage.LanguageTag.Substring(0, 2); if ($seen[$k]) { $false } else { $seen[$k] = 1; $true } }

function OcrBitmap($bmp) {
  foreach ($e in $engines) {
    $r = Await ($e.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
    Write-Output ('===== ' + $e.RecognizerLanguage.LanguageTag)
    foreach ($ln in $r.Lines) { Write-Output $ln.Text }
  }
}
function DecodeStream($stream) {
  $dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
}

$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Path)) ([Windows.Storage.StorageFile])
if ($Path -match '\.pdf$') {
  $doc = Await ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
  $n = [Math]::Min([int]$doc.PageCount, $MaxPages)
  for ($i = 0; $i -lt $n; $i++) {
    $page = $doc.GetPage([uint32]$i)
    $stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
    $opt = New-Object Windows.Data.Pdf.PdfPageRenderOptions
    $w = [Math]::Min(2400, [Math]::Max(1600, $page.Size.Width * 2.5))
    $opt.DestinationWidth = [uint32]$w
    AwaitAction ($page.RenderToStreamAsync($stream, $opt))
    $stream.Seek(0)
    $bmp = DecodeStream $stream
    Write-Output ('##### page ' + ($i + 1))
    OcrBitmap $bmp
    $page.Dispose()
  }
} else {
  $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  OcrBitmap (DecodeStream $stream)
}
