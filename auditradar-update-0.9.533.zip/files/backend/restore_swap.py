"""
Захира нусхадан тиклашнинг якуний қадами (сервер тўхтагандан кейин алоҳида жараёнда ишлайди):
  auditradar          → auditradar_old_<вақт>  (эски база ўчирилмайди, сақланади)
  auditradar_restore  → auditradar
кейин сервер қайта ишга туширилади (launcher.py --wait-port), миграциялар ўзи қўлланади.
"""
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import psycopg

BACKEND = Path(__file__).resolve().parent
LOG = BACKEND.parent / 'logs' / 'server.log'


def log(msg):
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} [тиклаш] {msg}\n")


def main():
    admin_dsn = sys.argv[1]   # postgres базасига уланиш
    time.sleep(3)             # сервер жараёни тўлиқ чиқиб кетсин
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    try:
        with psycopg.connect(admin_dsn, autocommit=True) as c:
            for db in ('auditradar', 'auditradar_restore'):
                c.execute("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname=%s AND pid<>pg_backend_pid()",
                          (db,))
            c.execute(f'ALTER DATABASE auditradar RENAME TO auditradar_old_{stamp}')
            c.execute('ALTER DATABASE auditradar_restore RENAME TO auditradar')
        log(f'база алмаштирилди; эски база: auditradar_old_{stamp}')
    except Exception as e:  # алмаштириб бўлмаса — эски база ўз жойида қолади
        log(f'ХАТО: {type(e).__name__}: {e}')
    flags = 0x00000008 | 0x08000000 if sys.platform == 'win32' else 0
    subprocess.Popen([sys.executable, str(BACKEND / 'launcher.py'), '--wait-port'], creationflags=flags, close_fds=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == '__main__':
    main()
