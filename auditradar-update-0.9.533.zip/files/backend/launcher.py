"""
Аудит Радар — фон режимида ишга тушириш (қора ойнасиз).

    pythonw launcher.py            — базани ва серверни фонда ишга туширади (Windows ёқилганда)
    pythonw launcher.py --open     — ишламаётган бўлса ишга туширади ва браузерда очади
    pythonw launcher.py --stop     — серверни ва базани тўхтатади

Ҳамма хабарлар logs/server.log файлига ёзилади. Сервер аллақачон ишлаётган бўлса, иккинчи нусха
ишга тушмайди (фақат браузер очилади).
"""
import json
import os
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

BACKEND = Path(__file__).resolve().parent
ROOT = BACKEND.parent
PG_BIN = ROOT / 'pgsql' / 'bin'
PG_DATA = ROOT / 'pgdata'
PG_PORT = 5499
HOST, PORT = '127.0.0.1', 8000
TLS_PORT = 8443
URL = f'http://{HOST}:{PORT}'


def _env_value(key, default=None):
    """backend/.env дан битта қийматни ўқийди (app.config импорт қилинмасдан — база ҳали ёқилмаган бўлиши мумкин)."""
    v = os.environ.get(key)
    if v:
        return v
    env = BACKEND / '.env'
    if env.exists():
        for line in env.read_text(encoding='utf-8-sig').splitlines():
            line = line.strip().lstrip('\ufeff')
            if line.startswith(key + '='):
                return line.split('=', 1)[1].strip() or default
    return default


# Тармоқ режими: .env да AR_HOST=0.0.0.0 бўлса, сервер офис тармоғидаги бошқа компьютерлардан ҳам очилади.
# Соғлиқ текшируви ва браузер ҳар доим 127.0.0.1 орқали.
BIND_HOST = _env_value('AR_HOST', HOST) or HOST
LOG_DIR = ROOT / 'logs'
PID_FILE = LOG_DIR / 'server.pid'
NO_WINDOW = 0x08000000 if os.name == 'nt' else 0   # CREATE_NO_WINDOW



def open_browser(url=None):
    """Платформани Google Chrome'да очади (кенгайтма Chrome'да); Chrome топилмаса — тизимнинг асосий браузерида."""
    url = url or URL
    cands = []
    for env in ('PROGRAMFILES', 'PROGRAMFILES(X86)', 'LOCALAPPDATA'):
        base = os.environ.get(env)
        if base:
            cands.append(os.path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'))
    for exe in cands:
        if os.path.isfile(exe):
            try:
                subprocess.Popen([exe, url], close_fds=True,
                                 creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                return True
            except OSError:
                pass
    return webbrowser.open(url)

def _setup_log():
    LOG_DIR.mkdir(exist_ok=True)
    log = LOG_DIR / 'server.log'
    if log.exists() and log.stat().st_size > 5_000_000:
        log.replace(LOG_DIR / 'server.old.log')
    f = open(log, 'a', encoding='utf-8', buffering=1)
    sys.stdout = sys.stderr = f
    return f


def say(msg):
    print(time.strftime('%Y-%m-%d %H:%M:%S'), msg, flush=True)


def message_box(text, title='Аудит Радар'):
    if os.name == 'nt':
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, title, 0x40)
            return
        except Exception:
            pass
    say(text)


def health(timeout=1.5):
    try:
        with urllib.request.urlopen(URL + '/api/health', timeout=timeout) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception:
        return None


def port_busy(port=None):
    import socket
    s = socket.socket()
    s.settimeout(0.5)
    try:
        return s.connect_ex((HOST, port or PORT)) == 0
    finally:
        s.close()


def pg(*args, to_file=False):
    exe = PG_BIN / ('pg_ctl.exe' if os.name == 'nt' else 'pg_ctl')
    cmd = [str(exe), '-D', str(PG_DATA), *args]
    if to_file:
        # ишга туширишда чиқишни файлга йўналтирамиз: pipe бўлса, postgres уни очиқ ушлаб, кутиш қотиб қолади
        with open(LOG_DIR / 'pg_ctl.log', 'a', encoding='utf-8', errors='replace') as out:
            r = subprocess.run(cmd, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL, stdout=out,
                               stderr=subprocess.STDOUT, timeout=150)
        return r
    return subprocess.run(cmd, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL,
                          capture_output=True, text=True, timeout=120)


def ensure_postgres():
    if not PG_BIN.exists():
        say('pgsql папкаси топилмади — ташқи база ишлатилади деб ҳисобланади')
        return True
    if pg('status').returncode == 0:
        return True
    say('PostgreSQL ишга туширилмоқда…')
    r = pg('-o', f'-p {PG_PORT} -c listen_addresses=localhost', '-l', str(ROOT / 'pgdata.log'), '-w', '-t', '90',
           'start', to_file=True)
    say(f'pg_ctl start: {r.returncode}')
    return pg('status').returncode == 0


def harden_db():
    """0.9.296: маҳаллий PostgreSQL «trust» (паролсиз) режимда яратилган эди — сервер компьютеридаги ҳар қандай дастур
    базага тўлиқ ҳуқуқ билан кира оларди. Биринчи ишга туширишда: тасодифий парол .env (AR_DB_PASSWORD) га ёзилади,
    базадаги фойдаланувчига scram-sha-256 пароли қўйилади, pg_hba.conf да trust → scram-sha-256. Ҳар қадам текширилади;
    хато бўлса pg_hba.conf олдинги ҳолатига қайтарилади (платформа аввалгидек ишлайверади)."""
    import re
    import secrets
    import shutil
    hba = PG_DATA / 'pg_hba.conf'
    pw = _env_value('AR_DB_PASSWORD')
    if pw:
        os.environ['AR_DB_PASSWORD'] = pw
        os.environ['PGPASSWORD'] = pw
    if not PG_BIN.exists() or not hba.exists() or _env_value('AR_DB_HARDEN', '1') == '0':
        return
    lines = hba.read_text(encoding='utf-8', errors='replace').splitlines()
    idx = [i for i, ln in enumerate(lines) if ln.strip() and not ln.lstrip().startswith('#') and re.search(r'\btrust\s*$', ln)]
    if not idx:
        return
    bak = PG_DATA / 'pg_hba.conf.trust.bak'
    changed = False
    try:
        import psycopg
        from psycopg import sql
        dsn = _env_value('AR_DATABASE_URL', 'dbname=auditradar') or 'dbname=auditradar'
        if os.name == 'nt':
            dsn = re.sub(r'host=/\S*', 'host=localhost', dsn)
        if '://' not in dsn:
            dsn += ' gssencmode=disable sslmode=disable connect_timeout=10'
        if not pw:
            pw = secrets.token_urlsafe(24)
            with open(BACKEND / '.env', 'a', encoding='utf-8') as f:
                f.write(f'\nAR_DB_PASSWORD={pw}\n')
            if _env_value_file('AR_DB_PASSWORD') != pw:
                raise RuntimeError('.env га ёзиб бўлмади')
            os.environ['AR_DB_PASSWORD'] = pw
            os.environ['PGPASSWORD'] = pw
        with psycopg.connect(dsn, autocommit=True) as c:
            c.execute("SET password_encryption = 'scram-sha-256'")
            c.execute(sql.SQL('ALTER ROLE CURRENT_USER PASSWORD {}').format(sql.Literal(pw)))
        if not bak.exists():
            shutil.copy2(hba, bak)
        for i in idx:
            lines[i] = re.sub(r'\btrust(\s*)$', r'scram-sha-256\1', lines[i])
        hba.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        changed = True
        pg('reload')
        time.sleep(1.0)
        with psycopg.connect(dsn + ('' if '://' in dsn else f' password={pw}')) as c:
            c.execute('SELECT 1')
        say('База: парол ўрнатилди (scram-sha-256), паролсиз кириш (trust) ўчирилди')
    except Exception as e:  # noqa: BLE001
        say(f'База паролини ўрнатиб бўлмади: {type(e).__name__}: {e}')
        if changed and bak.exists():
            shutil.copy2(bak, hba)
            pg('reload')
            say('pg_hba.conf олдинги ҳолатига қайтарилди')


def _env_value_file(key):
    env = BACKEND / '.env'
    if env.exists():
        for line in env.read_text(encoding='utf-8-sig').splitlines():
            line = line.strip().lstrip('\ufeff')
            if line.startswith(key + '='):
                return line.split('=', 1)[1].strip()
    return None


def stop():
    pid = None
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
        except ValueError:
            pass
    if pid:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'], creationflags=NO_WINDOW, capture_output=True)
        else:
            try:
                os.kill(pid, 15)
            except OSError:
                pass
        PID_FILE.unlink(missing_ok=True)
    if PG_BIN.exists():
        pg('-m', 'fast', '-w', 'stop')
    say('Тўхтатилди')


def wait_ready(seconds=60):
    for _ in range(seconds * 4):
        h = health(0.5)
        if h and h.get('app') == 'auditradar':
            return True
        time.sleep(0.25)
    return False


_LOCK = None


def single_instance(seconds=0.0):
    """Бир вақтда фақат битта ишга туширувчи: компьютер ёқилганда вазифа (AtStartup) ва «Автозагрузка»даги ёрлиқ
    бирга ишга тушса, иккинчиси портни банд қилолмай хато берар ва server.pid ни ўчириб юборар эди (10.10.2026)."""
    global _LOCK
    f = open(LOG_DIR / 'launcher.lock', 'a+')
    end = time.time() + seconds
    while True:
        try:
            if os.name == 'nt':
                import msvcrt
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            _LOCK = f
            return True
        except OSError:
            if time.time() >= end:
                f.close()
                return False
            time.sleep(0.25)


def main():
    args = set(sys.argv[1:])
    _setup_log()
    if '--stop' in args:
        stop()
        if '--quiet' not in args:
            message_box('Аудит Радар тўхтатилди.')
        return

    if '--wait-port' in args:  # платформа ичидан қайта ишга тушириш: эски нусха портни бўшатишини кутамиз
        for _ in range(80):
            if not port_busy():
                break
            time.sleep(0.25)
    os.environ['AR_LAUNCHER'] = '1'
    if not single_instance(25 if '--wait-port' in args else 0):
        # бошқа нусха ҳозир ишга туширяпти — унинг тайёр бўлишини кутамиз, ўзимиз сервер очмаймиз
        say('Бошқа нусха ишга тушириляпти — кутилмоқда')
        if wait_ready(120) and '--open' in args:
            open_browser()
        return
    h = health()
    if h and h.get('app') == 'auditradar':
        if not h.get('db'):  # сервер ишлаяпти, лекин база тўхтаб қолган — қайта ёқамиз
            say('База жавоб бермаяпти — қайта ишга туширилмоқда')
            ensure_postgres()
        if '--open' in args:
            open_browser()
        return
    if port_busy():
        message_box(f'{PORT}-порт бошқа дастур томонидан банд. Аудит Радар ишга тушмади.')
        return

    if not ensure_postgres():
        message_box('Маълумотлар базасини ишга тушириб бўлмади. Батафсил: logs\\server.log ва pgdata.log')
        return

    harden_db()
    sys.path.insert(0, str(BACKEND))
    os.chdir(BACKEND)
    from app.db import migrate
    for attempt in range(10):
        try:
            migrate(verbose=True)
            break
        except Exception as e:  # база эндигина ёқилган бўлса, бир оз кутамиз
            say(f'migrate: {e}')
            time.sleep(1.5)
    else:
        message_box('Базага уланиб бўлмади. Батафсил: logs\\server.log')
        return

    PID_FILE.write_text(str(os.getpid()))
    if '--open' in args:
        import threading
        threading.Thread(target=lambda: wait_ready() and open_browser(), daemon=True).start()

    import uvicorn
    from app.main import app
    if BIND_HOST != HOST:
        say(f'Сервер ишга тушди: {URL} (тармоқда ҳам: {BIND_HOST}:{PORT})')
    else:
        say(f'Сервер ишга тушди: {URL}')
    # 0.9.93: HTTPS (шифрланган уланиш) — 8443-портда, HTTP 8000 билан ёнма-ён. Сертификат тайёрланмаса ёки
    # .env да AR_HTTPS=0 бўлса — фақат HTTP (олдингидек).
    # 0.9.296: шифрланмаган HTTP (8000) тармоқда фақат ҳали ундан фойдаланаётганлар бўлса (app/http_lan.py) ёки HTTPS
    # ишламаса очилади; акс ҳолда фақат шу компьютерда (127.0.0.1). HTTPS (8443) — тармоқда (BIND_HOST).
    http_host = HOST
    tls_ok = _env_value('AR_HTTPS', '1') != '0'
    if BIND_HOST != HOST:
        lan = True
        try:
            from app.db import connect
            from app import http_lan as HL
            with connect() as conn:
                lan = HL.lan_open(conn)
        except Exception as e:  # noqa: BLE001 — аниқлаб бўлмаса аввалгидек
            say(f'HTTP тармоқ режими аниқланмади: {e}')
        if lan or not tls_ok:
            http_host = BIND_HOST
    os.environ['AR_HTTP_LAN_ACTIVE'] = '1' if http_host != HOST else '0'
    say(f'HTTP {PORT}: ' + ('тармоқда ҳам очиқ (ҳали ундан фойдаланаётганлар бор)' if http_host != HOST else 'фақат шу компьютерда'))
    servers = [uvicorn.Server(uvicorn.Config(app, host=http_host, port=PORT, log_level='info', use_colors=False))]
    if tls_ok:
        tls_port = int(_env_value('AR_HTTPS_PORT', str(TLS_PORT)) or TLS_PORT)
        try:
            from app import tls
            os.environ.setdefault('AR_TLS_NAMES', _env_value('AR_TLS_NAMES', '') or '')
            pair = tls.ensure(log=say)
            for _ in range(40):          # қайта ишга туширишда эски жараён портни бўшатишини кутамиз
                if not port_busy(tls_port):
                    break
                time.sleep(0.25)
            if pair and not port_busy(tls_port):
                servers.append(uvicorn.Server(uvicorn.Config(
                    app, host=BIND_HOST, port=tls_port, log_level='info', use_colors=False, lifespan='off',
                    ssl_certfile=pair[0], ssl_keyfile=pair[1])))
                say(f'HTTPS: https://{BIND_HOST if BIND_HOST != "0.0.0.0" else "<сервер IP>"}:{tls_port}')
            elif pair:
                say(f'HTTPS: {tls_port}-порт банд — фақат HTTP')
        except Exception as e:  # noqa: BLE001
            say(f'HTTPS ёқилмади: {type(e).__name__}: {e}')
    if len(servers) == 1 and http_host != BIND_HOST:     # HTTPS ишламади — тармоқдаги ходимлар узилиб қолмасин
        servers[0] = uvicorn.Server(uvicorn.Config(app, host=BIND_HOST, port=PORT, log_level='info', use_colors=False))
        os.environ['AR_HTTP_LAN_ACTIVE'] = '1'
        say(f'HTTPS йўқ — HTTP {PORT} тармоқда очиқ қолди')
    try:
        if len(servers) == 1:
            servers[0].run()
        else:
            import asyncio

            async def both():
                # бир сервер тўхтаса (сигнал/хато) — иккинчиси ҳам тўхтайди, жараён осилиб қолмасин
                tasks = [asyncio.create_task(s.serve()) for s in servers]
                await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                for s in servers:
                    s.should_exit = True
                await asyncio.gather(*tasks, return_exceptions=True)
            asyncio.run(both())
    finally:
        PID_FILE.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
