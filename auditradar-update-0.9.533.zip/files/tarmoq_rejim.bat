@echo off
chcp 65001 >nul
rem Аудит Радар: тармоқ режими.  tarmoq_rejim.bat — ёқиш,  tarmoq_rejim.bat off — ўчириш
rem Натижа хабар ойнасида чиқади; қора ойна кўринмайди.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\setup_network.ps1" %1
