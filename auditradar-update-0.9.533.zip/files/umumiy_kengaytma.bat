@echo off
chcp 65001 >nul
rem Аудит Радар: extension папкасини тармоқда умумий қилиш.  umumiy_kengaytma.bat off — олиб ташлаш
rem Натижа хабар ойнасида чиқади; қора ойна кўринмайди.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\share_extension.ps1" %1
