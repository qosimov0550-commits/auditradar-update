@echo off
chcp 65001 >nul
rem Аудит Радар: фон режими (қора ойнасиз, Windows ёқилганда ишга тушиш)
rem Натижа хабар ойнасида чиқади; қора ойна кўринмайди.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\setup_background.ps1" %1
