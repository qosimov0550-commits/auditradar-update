@echo off
rem Shifrlangan zaxira nusxasini ochish (yangi kompyuterda tiklash uchun): AR_....arbk faylini shu faylning ustiga sudrab tashlang
rem yoki: zaxiradan_ochish.bat D:\AuditRadar_zaxira\AR_20261017_2200_FULL.arbk
if "%~1"=="" (echo  Foydalanish: zaxiradan_ochish.bat ^<fayl.arbk^> & pause & exit /b 1)
"%~dp0venv\Scripts\python.exe" "%~dp0backend\manage.py" zaxira-och "%~1"
pause
