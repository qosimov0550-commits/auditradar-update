@echo off
chcp 65001 >nul
rem Аудит Радар: уйдан уланиш (Tailscale VPN).  uy_rejim.bat — ёқиш,  uy_rejim.bat off — ўчириш
rem Натижа хабар ойнасида чиқади; қора ойна кўринмайди.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\setup_remote.ps1" %1
