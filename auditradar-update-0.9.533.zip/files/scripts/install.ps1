﻿# =====================================================================
# Аудит Радар — Windows учун ўрнатиш скрипти
# Python ва PostgreSQL'ни (портатив, лойиҳа папкаси ичида) ўрнатади,
# базани яратади ва администратор фойдаланувчисини қўшади.
# Ишга тушириш: install.bat файлини икки марта босинг.
# =====================================================================
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$PgVersion = '16.4-1'
$PgDir = Join-Path $Root 'pgsql'
$PgData = Join-Path $Root 'pgdata'
$PgPort = 5499
$Venv = Join-Path $Root 'venv'

function Step($t) { Write-Host ''; Write-Host "== $t" -ForegroundColor Cyan }

# ---------- 1. Python
Step '1/5 Python текширилмоқда'
$py = $null
# 0.9.443: платформа кодлари Python 3.12 учун тайёрланган (.pyc) — айнан 3.12 керак
foreach ($c in @('py -3.12', 'python')) {
    try {
        $v = & cmd /c "$c --version 2>&1"
        if ($v -match 'Python 3\.12') { $py = $c; break }
    } catch {}
}
if (-not $py) {
    Write-Host 'Python 3.12 топилмади. winget орқали Python 3.12 ўрнатилмоқда...'
    winget install -e --id Python.Python.3.12 --source winget --scope user --accept-package-agreements --accept-source-agreements
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
    $py = 'py -3.12'
    $v = & cmd /c "py -3.12 --version 2>&1"
    if ($v -notmatch 'Python 3\.12') {
        throw 'Python ўрнатилмади. python.org/downloads дан Python 3.12 ни ўрнатинг («Add python.exe to PATH» белгиланган ҳолда) ва install.bat ни қайта ишга туширинг.'
    }
}
Write-Host "Python: $py"

# ---------- 2. Виртуал муҳит ва кутубхоналар
Step '2/5 Python кутубхоналари ўрнатилмоқда'
if (-not (Test-Path $Venv)) { & cmd /c "$py -m venv `"$Venv`"" }
$VPy = Join-Path $Venv 'Scripts\python.exe'
& $VPy -m pip install --upgrade pip --quiet
& $VPy -m pip install -r (Join-Path $Root 'backend\requirements.txt') --quiet

# ---------- 3. PostgreSQL (портатив)
Step '3/5 PostgreSQL тайёрланмоқда'
if (-not (Test-Path (Join-Path $PgDir 'bin\pg_ctl.exe'))) {
    $zip = Join-Path $env:TEMP "pgsql-$PgVersion.zip"
    $url = "https://get.enterprisedb.com/postgresql/postgresql-$PgVersion-windows-x64-binaries.zip"
    Write-Host "Юкланмоқда: $url (~300 МБ, бир неча дақиқа)"
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    Expand-Archive -Path $zip -DestinationPath $Root -Force
    Remove-Item $zip
}
$PgBin = Join-Path $PgDir 'bin'
if (-not (Test-Path (Join-Path $PgData 'PG_VERSION'))) {
    & (Join-Path $PgBin 'initdb.exe') -D $PgData -U postgres -A trust -E UTF8 --locale=C
}
& (Join-Path $PgBin 'pg_ctl.exe') -D $PgData -o "-p $PgPort -c listen_addresses=localhost" -l (Join-Path $Root 'pgdata.log') -w start
$exists = & (Join-Path $PgBin 'psql.exe') -h localhost -p $PgPort -U postgres -Atc "SELECT 1 FROM pg_database WHERE datname='auditradar'"
if ($exists -ne '1') {
    & (Join-Path $PgBin 'createdb.exe') -h localhost -p $PgPort -U postgres auditradar
    # бошқа компьютердан олиб келинган захира нусха бўлса — маълумотларни тиклаймиз
    $dump = Get-ChildItem (Join-Path $Root 'backups') -Filter '*.dump' -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1
    if ($dump) {
        Write-Host "Захира нусхадан маълумотлар тикланмоқда: $($dump.Name)" -ForegroundColor Yellow
        $ErrorActionPreference = 'Continue'
        & (Join-Path $PgBin 'pg_restore.exe') -h localhost -p $PgPort -U postgres -d auditradar --no-owner $dump.FullName
        $ErrorActionPreference = 'Stop'
    }
}

# ---------- 4. Созламалар ва база
Step '4/5 База тузилмаси яратилмоқда'
$EnvFile = Join-Path $Root 'backend\.env'
if (-not (Test-Path $EnvFile)) {
    # BOM'сиз UTF-8 (Windows PowerShell 5.1 нинг Out-File -Encoding utf8 BOM қўшади)
    [System.IO.File]::WriteAllText($EnvFile, "AR_DATABASE_URL=host=localhost port=$PgPort user=postgres dbname=auditradar`r`n", (New-Object System.Text.UTF8Encoding $false))
}
& $VPy (Join-Path $Root 'backend\manage.py') migrate

# ---------- 5. Администратор
Step '5/5 Администратор фойдаланувчиси'
$has = & (Join-Path $PgBin 'psql.exe') -h localhost -p $PgPort -U postgres -d auditradar -Atc "SELECT COUNT(*) FROM app_user"
if ($has -eq '0') {
    $login = Read-Host 'Администратор логини (масалан: admin)'
    $name = Read-Host 'Ф.И.Ш.'
    & $VPy (Join-Path $Root 'backend\manage.py') create-user $login $name --admin
} else {
    Write-Host 'Фойдаланувчилар аллақачон мавжуд.'
}
& (Join-Path $PgBin 'pg_ctl.exe') -D $PgData -w stop

Write-Host ''
Write-Host 'Ўрнатиш якунланди.' -ForegroundColor Green
& (Join-Path $PSScriptRoot 'setup_background.ps1')
