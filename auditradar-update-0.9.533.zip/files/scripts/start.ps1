﻿# Аудит Радар — ишга тушириш: базани ёқади, серверни очади ва браузерни очади.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$PgBin = Join-Path $Root 'pgsql\bin'
$PgData = Join-Path $Root 'pgdata'
$VPy = Join-Path $Root 'venv\Scripts\python.exe'

& (Join-Path $PgBin 'pg_ctl.exe') -D $PgData status *> $null
if ($LASTEXITCODE -ne 0) {
    & (Join-Path $PgBin 'pg_ctl.exe') -D $PgData -o "-p 5499 -c listen_addresses=localhost" -l (Join-Path $Root 'pgdata.log') -w start
}
& $VPy (Join-Path $Root 'backend\manage.py') migrate | Out-Null
Start-Process 'http://127.0.0.1:8000'
Write-Host 'Аудит Радар ишлаяпти: http://127.0.0.1:8000' -ForegroundColor Green
Write-Host 'Консол режими (носозликни текшириш учун). Одатда иш столидаги «Аудит Радар» ёрлиғидан фойдаланинг.'
try {
    Set-Location (Join-Path $Root 'backend')
    & $VPy manage.py run --port 8000
} finally {
    # база тўхтатилмайди: фон режимидаги платформа ҳам шу базадан фойдаланади
}
