﻿# Аудит Радар — фон режимини ўрнатиш: қора ойнасиз ишга тушириш, Windows ёқилганда автоматик ишга тушиш,
# иш столида «Аудит Радар» ва «Аудит Радарни тўхтатиш» ёрлиқлари.
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '_ui.ps1')
trap { Say ('Хато: ' + $_.Exception.Message); Show-Done 'Аудит Радар — фон режими' $false; exit 1 }
$Root = Split-Path -Parent $PSScriptRoot
$PyW = Join-Path $Root 'venv\Scripts\pythonw.exe'
$Launcher = Join-Path $Root 'backend\launcher.py'
$Icon = Join-Path $Root 'scripts\assets\auditradar.ico'
if (-not (Test-Path $PyW)) { throw "venv топилмади: $PyW. Аввал install.bat ни ишга туширинг." }

$sh = New-Object -ComObject WScript.Shell
function New-Link($path, $arguments, $desc) {
    $l = $sh.CreateShortcut($path)
    $l.TargetPath = $PyW
    $l.Arguments = "`"$Launcher`" $arguments"
    $l.WorkingDirectory = Join-Path $Root 'backend'
    $l.IconLocation = "$Icon,0"
    $l.Description = $desc
    $l.Save()
}
$desk = [Environment]::GetFolderPath('Desktop')
$startup = [Environment]::GetFolderPath('Startup')
New-Link (Join-Path $desk 'Аудит Радар.lnk') '--open' 'Аудит Радарни очиш'
New-Link (Join-Path $desk 'Аудит Радарни тўхтатиш.lnk') '--stop' 'Аудит Радар серверини тўхтатиш'
New-Link (Join-Path $startup 'Аудит Радар (фон).lnk') '' 'Windows ёқилганда Аудит Радарни фонда ишга тушириш'

# консол режимида (start.bat) ишлаётган эски нусхани ойнаси билан ёпамиз, кейин фон режимида қайта ишга туширамиз
$ErrorActionPreference = 'Continue'
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'scripts\\start\.ps1' } | ForEach-Object {
    Start-Process taskkill.exe -ArgumentList "/PID $($_.ParentProcessId) /T /F" -WindowStyle Hidden -Wait
    Start-Process taskkill.exe -ArgumentList "/PID $($_.ProcessId) /T /F" -WindowStyle Hidden -Wait
}
$c = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($c) { Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue }
Start-Sleep 4
Start-Process -FilePath $PyW -ArgumentList "`"$Launcher`" --open" -WorkingDirectory (Join-Path $Root 'backend')
Say 'Тайёр: иш столида «Аудит Радар» ёрлиғи пайдо бўлди. Платформа энди фонда ишлайди.'
Show-Done 'Аудит Радар — фон режими' $true
