﻿# Скриптлар учун умумий: қора ойна кўрсатилмайди, натижа Windows хабар ойнасида (Unicode — ҳ, қ, ғ, ў тўғри
# кўринади) ва logs\scripts.log да. Ишлатиш: . (Join-Path $PSScriptRoot '_ui.ps1')
Add-Type -AssemblyName System.Windows.Forms
$script:UiLines = New-Object System.Collections.Generic.List[string]
$script:UiLog = Join-Path (Split-Path -Parent $PSScriptRoot) 'logs\scripts.log'
function Say {
    param([string]$Text = '', $ForegroundColor)
    $script:UiLines.Add($Text)
    try { Add-Content -Path $script:UiLog -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $Text) -Encoding UTF8 } catch { }
}
function Show-Done {
    param([string]$Title = 'Аудит Радар', [bool]$Ok = $true)
    $text = ($script:UiLines -join "`n").Trim()
    if (-not $text) { $text = $(if ($Ok) { 'Тайёр.' } else { 'Хато.' }) }
    $icon = $(if ($Ok) { 'Information' } else { 'Error' })
    # яширин ойнадан чиқарилган хабар бошқа ойналар орқасида қолмаслиги учун — энг устки (TopMost) эга ойна
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; Opacity = 0; StartPosition = 'CenterScreen' }
    $owner.Show(); $owner.Activate()
    [System.Windows.Forms.MessageBox]::Show($owner, $text, $Title, 'OK', $icon) | Out-Null
    $owner.Close()
}
# администратор ҳуқуқи йўқ бўлса — ўзини яширин ойнада, UAC сўрови билан қайта ишга туширади. Қайтаради: $true — давом этиш
function Ensure-Admin([string]$ScriptPath, [string]$Arg) {
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if ($isAdmin) { return $true }
    Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`" $Arg"
    return $false
}
