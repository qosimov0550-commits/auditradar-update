﻿# Аудит Радар — уйдан (ва бошқа жойдан) Tailscale VPN орқали уланиш: сервер компьютерида бир марта ишга туширилади.
#   setup_remote.ps1        — ёқиш:  firewall'да 8000 (платформа) ва 445 (кенгайтма папкаси) портлари ФАҚАТ Tailscale
#                             тармоғи (100.64.0.0/10) учун очилади; компьютер уйқуга кетмайдиган қилинади
#   setup_remote.ps1 off    — қоидаларни олиб ташлаш
# Порт интернетга очилмайди: Tailscale фақат сизнинг Google ҳисобингизга уланган қурилмаларни бир-бирига улайди.
param([string]$Mode = 'on')
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot '_ui.ps1')
trap { Say ('Хато: ' + $_.Exception.Message); Show-Done 'Аудит Радар' $false; exit 1 }
if (-not (Ensure-Admin $PSCommandPath $Mode)) { exit }

$Net = '100.64.0.0/10'                       # Tailscale манзиллари
$Rules = @(
    @{ Name = 'Аудит Радар — Tailscale (8000)'; Port = 8000; Desc = 'Аудит Радар платформаси — фақат Tailscale VPN орқали' },
    @{ Name = 'Аудит Радар — Tailscale (кенгайтма папкаси)'; Port = 445; Desc = 'Кенгайтма умумий папкаси (\\сервер\AuditRadar-extension) — фақат Tailscale VPN орқали' }
)
$On = ($Mode -ne 'off')

function Done($code) {
    Show-Done 'Аудит Радар — уйдан уланиш' ($code -eq 0)
    exit $code
}

try {
    foreach ($r in $Rules) { Get-NetFirewallRule -DisplayName $r.Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule }
    if (-not $On) {
        Say 'Tailscale орқали кириш қоидалари олиб ташланди.' -ForegroundColor Green
        Done 0
    }

    # 1. Tailscale ўрнатилганми ва уланганми
    $ts = @("$env:ProgramFiles\Tailscale\tailscale.exe", "${env:ProgramFiles(x86)}\Tailscale\tailscale.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $ts) {
        Say 'Tailscale топилмади.' -ForegroundColor Yellow
        Say '  1) https://tailscale.com/download/windows дан юклаб ўрнатинг;'
        Say '  2) Google ҳисобингиз билан киринг;'
        Say '  3) шу файлни (uy_rejim.bat) қайта ишга туширинг.'
        Done 1
    }
    $ip = (& $ts ip -4 2>$null | Select-Object -First 1)
    if (-not $ip -or $ip -notmatch '^100\.') {
        Say 'Tailscale ўрнатилган, лекин уланмаган: вазифалар панелидаги Tailscale белгиси орқали Google ҳисоби билан киринг ва қайта ишга туширинг.' -ForegroundColor Yellow
        Done 1
    }

    # 2. Firewall: фақат Tailscale тармоғидан (барча профилларда — Tailscale адаптери «Public» бўлиши мумкин)
    foreach ($r in $Rules) {
        New-NetFirewallRule -DisplayName $r.Name -Direction Inbound -Action Allow -Protocol TCP -LocalPort $r.Port `
            -RemoteAddress $Net -Profile Any -Description $r.Desc | Out-Null
    }

    # 3. Сервер ўчмаслиги: тармоқдан ишлаганда уйқу ва гибернация ўчирилади (фақат розеткадан ишлаганда)
    powercfg /change standby-timeout-ac 0 | Out-Null
    powercfg /change hibernate-timeout-ac 0 | Out-Null

    # 4. Платформа 0.0.0.0 да тинглаяптими (тармоқ режими)
    $listen = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    $name = (& $ts status --json 2>$null | ConvertFrom-Json).Self.DNSName -replace '\.$', ''

    Say ''
    Say 'Тайёр: уйдан уланиш ёқилди.' -ForegroundColor Green
    if (-not $listen -or $listen.LocalAddress -eq '127.0.0.1') {
        Say 'Огоҳлантириш: платформа тармоқ режимида эмас — аввал tarmoq_rejim.bat ни ишга туширинг.' -ForegroundColor Yellow
    }
    Say ''
    Say 'Уй компьютерида (Tailscale ўрнатилиб, ШУ Google ҳисоби билан кирилгандан кейин):'
    Say "  Платформа:           http://${ip}:8000" -ForegroundColor Cyan
    if ($name) { Say "                       http://${name}:8000" -ForegroundColor Cyan }
    Say "  Кенгайтма папкаси:   \\$ip\AuditRadar-extension   (Z: диск қилиб уланг)" -ForegroundColor Cyan
    Say "  Кенгайтма → «Платформа манзили»: http://${ip}:8000" -ForegroundColor Cyan
    Say ''
    Say 'Компьютер розеткадан ишлаганда уйқуга кетмайди. Платформа Windows ёқилганда ўзи ишга тушади (fon_rejim.bat).'
    Say 'Эслатма: 8000-порт интернетга очилмади — фақат Tailscale тармоғидаги қурилмаларингиз кира олади.'
    Done 0
} catch {
    Say ('Хато: ' + $_.Exception.Message) -ForegroundColor Red
    Done 1
}
