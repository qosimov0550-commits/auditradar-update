﻿# Аудит Радар — платформани компьютер ёқилиши билан, Windows'га кирмасдан ишга тушириш (Планировщик заданий).
#   setup_autostart.ps1        — ёқиш: «Аудит Радар (компьютер ёқилганда)» вазифаси — тизим ёқилганда, шу фойдаланувчи
#                                номидан (паролсиз, S4U), фонда; Windows янгиланиб қайта ёқилса ҳам платформа ишга тушади
#   setup_autostart.ps1 off    — вазифани олиб ташлаш
# Пароль сўралмайди ва сақланмайди. «Пуск → Автозагрузка» даги ёрлиқ қолади (кирилганда ишга тушган бўлса — ўтказиб юборади).
param([string]$Mode = 'on')
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '_ui.ps1')
trap { Say ('Хато: ' + $_.Exception.Message); Show-Done 'Аудит Радар — автоматик ишга тушиш' $false; exit 1 }
if (-not (Ensure-Admin $PSCommandPath $Mode)) { exit }

$Root = Split-Path -Parent $PSScriptRoot
$PyW = Join-Path $Root 'venv\Scripts\pythonw.exe'
$Launcher = Join-Path $Root 'backend\launcher.py'
$TaskName = 'Аудит Радар (компьютер ёқилганда)'
if (-not (Test-Path $PyW)) { throw "venv топилмади: $PyW. Аввал install.bat ни ишга туширинг." }

Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
if ($Mode -eq 'off') {
    Say 'Вазифа олиб ташланди: платформа энди фақат Windowsʼга кирилганда ишга тушади.'
    Show-Done 'Аудит Радар — автоматик ишга тушиш' $true; exit 0
}

$user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute $PyW -Argument "`"$Launcher`"" -WorkingDirectory (Join-Path $Root 'backend')
$trigger = New-ScheduledTaskTrigger -AtStartup
$trigger.Delay = 'PT45S'                                  # тармоқ ва диск тайёр бўлиши учун
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType S4U -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
    -Description 'Аудит Радар серверини компьютер ёқилганда (Windowsʼга кирмасдан) фонда ишга туширади' | Out-Null

Say 'Тайёр: платформа энди компьютер ёқилиши билан ўзи ишга тушади — Windowsʼга кириш шарт эмас.'
Say ''
Say "Вазифа: «$TaskName» (фойдаланувчи $user, пароль сақланмайди)."
Say 'Windows янгиланиб қайта ёқилса ёки чироқ ўчиб-ёқилса (BIOS созланган бўлса) — уйдан ҳам уланиш мумкин бўлади.'
Say 'Ўчириш: avto_ishga_tushirish.bat off'
Show-Done 'Аудит Радар — автоматик ишга тушиш' $true
