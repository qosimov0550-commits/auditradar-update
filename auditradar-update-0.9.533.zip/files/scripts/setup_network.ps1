﻿# Аудит Радар — тармоқ режими: битта компьютер сервер, қолган аудиторлар браузер орқали шу базада ишлайди.
#   setup_network.ps1        — ёқиш  (AR_HOST=0.0.0.0, firewall қоидаси, серверни қайта ишга тушириш)
#   setup_network.ps1 off    — ўчириш (AR_HOST=127.0.0.1, қоида олиб ташланади, сервер қайта ишга тушади)
param([string]$Mode = 'on')
$ErrorActionPreference = 'Stop'

# Администратор ҳуқуқи (firewall учун) — йўқ бўлса ўзини қайта ишга туширади (UAC сўрови)
. (Join-Path $PSScriptRoot '_ui.ps1')
trap { Say ('Хато: ' + $_.Exception.Message); Show-Done 'Аудит Радар' $false; exit 1 }
if (-not (Ensure-Admin $PSCommandPath $Mode)) { exit }

$Root = Split-Path -Parent $PSScriptRoot
$EnvFile = Join-Path $Root 'backend\.env'
$PyW = Join-Path $Root 'venv\Scripts\pythonw.exe'
$Launcher = Join-Path $Root 'backend\launcher.py'
$RuleName = 'Аудит Радар (8000)'
$RuleTls = 'Аудит Радар (8443 HTTPS)'
$Port = 8000
$TlsPort = 8443
$On = ($Mode -ne 'off')

if (-not (Test-Path $EnvFile)) { throw "backend\.env топилмади. Аввал install.bat ни ишга туширинг." }

# 1. .env: AR_HOST (BOM'сиз UTF-8)
$lines = [System.IO.File]::ReadAllLines($EnvFile, [System.Text.Encoding]::UTF8) | Where-Object { $_ -notmatch '^\s*AR_HOST\s*=' }
$lines += 'AR_HOST=' + $(if ($On) { '0.0.0.0' } else { '127.0.0.1' })
[System.IO.File]::WriteAllLines($EnvFile, $lines, (New-Object System.Text.UTF8Encoding $false))

# 2. Firewall: TCP 8000, фақат Domain/Private профиллар (ommaviy Wi-Fi'да порт ёпиқ қолади)
Get-NetFirewallRule -DisplayName $RuleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
Get-NetFirewallRule -DisplayName $RuleTls -ErrorAction SilentlyContinue | Remove-NetFirewallRule
if ($On) {
    New-NetFirewallRule -DisplayName $RuleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port `
        -Profile Domain, Private -Description 'Аудит Радар платформасига офис тармоғидан кириш' | Out-Null
    # 0.9.93: шифрланган уланиш (HTTPS)
    New-NetFirewallRule -DisplayName $RuleTls -Direction Inbound -Action Allow -Protocol TCP -LocalPort $TlsPort `
        -Profile Domain, Private -Description 'Аудит Радар — шифрланган уланиш (HTTPS)' | Out-Null
}

# 3. Серверни қайта ишга тушириш
Say 'Сервер қайта ишга туширилмоқда…'
Start-Process -FilePath $PyW -ArgumentList "`"$Launcher`" --stop --quiet" -WorkingDirectory (Join-Path $Root 'backend') -Wait
Start-Sleep 2
Start-Process -FilePath $PyW -ArgumentList "`"$Launcher`" --wait-port" -WorkingDirectory (Join-Path $Root 'backend')
$ok = $false
for ($i = 0; $i -lt 120; $i++) {
    Start-Sleep -Milliseconds 500
    try {
        $h = Invoke-RestMethod "http://127.0.0.1:$Port/api/health" -TimeoutSec 2
        if ($h.app -eq 'auditradar') { $ok = $true; break }
    } catch { }
}
if (-not $ok) { throw 'Сервер 60 сония ичида ишга тушмади. Батафсил: logs\server.log' }

# 4. Натижа
if ($On) {
    $listen = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    Say ''
    Say 'Тармоқ режими ёқилди.' -ForegroundColor Green
    if ($listen -and $listen.LocalAddress -ne '0.0.0.0') {
        Say "Огоҳлантириш: сервер ҳали фақат $($listen.LocalAddress) да тингламоқда — logs\server.log ни текширинг." -ForegroundColor Yellow
    }
    Say 'Бошқа компьютерлардан браузерда очиш манзили:'
    Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
        ForEach-Object { Say "    https://$($_.IPAddress):$TlsPort   ($($_.InterfaceAlias), шифрланган)" -ForegroundColor Green
                         Say "    http://$($_.IPAddress):$Port   ($($_.InterfaceAlias))" -ForegroundColor Cyan }
    Say "    http://$($env:COMPUTERNAME):$Port" -ForegroundColor Cyan
    Say ''
    Say 'Эслатма: алоқа оддий HTTP — фақат ишончли офис тармоғида ишлатинг, интернетга очманг.'
    Say 'Роутерда шу компьютерга доимий IP беринг, акс ҳолда манзил ўзгариб қолиши мумкин.'
} else {
    Say ''
    Say 'Тармоқ режими ўчирилди: платформа фақат шу компьютерда (127.0.0.1:8000) очилади.' -ForegroundColor Green
}

Show-Done 'Аудит Радар — тармоқ режими' $true
