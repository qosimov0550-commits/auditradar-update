﻿# Аудит Радар — extension папкасини офис тармоғида умумий (фақат ўқиш) қилиш.
# Бошқа компьютерларда Chrome кенгайтмани тўғридан-тўғри \\<СЕРВЕР>\AuditRadar-extension дан юклайди,
# серверда янгиланганда «Обновить» босиш кифоя — кўчириш керак эмас.
#   share_extension.ps1        — ёқиш
#   share_extension.ps1 off    — умумий папкани олиб ташлаш
param([string]$Mode = 'on')
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot '_ui.ps1')
trap { Say ('Хато: ' + $_.Exception.Message); Show-Done 'Аудит Радар' $false; exit 1 }
if (-not (Ensure-Admin $PSCommandPath $Mode)) { exit }

$Root = Split-Path -Parent $PSScriptRoot
$Folder = Join-Path $Root 'extension'
$ShareName = 'AuditRadar-extension'
$On = ($Mode -ne 'off')

try {
    if (Get-SmbShare -Name $ShareName -ErrorAction SilentlyContinue) { Remove-SmbShare -Name $ShareName -Force }
    if ($On) {
        if (-not (Test-Path $Folder)) { throw "Папка топилмади: $Folder" }
        # Фақат ўқиш: Everyone (S-1-1-0) — локал тармоқдаги ҳар қандай компьютер ўқийди, ҳеч ким ёза олмайди
        $everyone = (New-Object System.Security.Principal.SecurityIdentifier('S-1-1-0')).Translate([System.Security.Principal.NTAccount]).Value
        New-SmbShare -Name $ShareName -Path $Folder -ReadAccess $everyone -Description 'Аудит Радар — Chrome кенгайтмаси (фақат ўқиш)' | Out-Null
        # Тармоқдан кириш учун алоҳида фойдаланувчи (net user kengaytma <парол> /add) бўлса — папкани ўқиш ҳуқуқи
        if (Get-LocalUser -Name 'kengaytma' -ErrorAction SilentlyContinue) {
            icacls $Folder /grant 'kengaytma:(OI)(CI)RX' /T | Out-Null
        }
        # Firewall: «Файл ва принтер умумий фойдаланиши» фақат Private профилда
        Set-NetFirewallRule -DisplayGroup 'File and Printer Sharing' -Enabled True -Profile Private -ErrorAction SilentlyContinue
        if (-not $?) { Set-NetFirewallRule -DisplayGroup 'Общий доступ к файлам и принтерам' -Enabled True -Profile Private -ErrorAction SilentlyContinue }
        # Тармоқ профили Private бўлмаса, бошқа компьютерлар кўрмайди
        $pub = Get-NetConnectionProfile | Where-Object { $_.NetworkCategory -eq 'Public' -and $_.IPv4Connectivity -ne 'Disconnected' }
        foreach ($p in $pub) { Set-NetConnectionProfile -InterfaceIndex $p.InterfaceIndex -NetworkCategory Private }

        Say ''
        Say 'Умумий папка яратилди (фақат ўқиш):' -ForegroundColor Green
        Say "    \\$($env:COMPUTERNAME)\$ShareName" -ForegroundColor Cyan
        Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
            ForEach-Object { Say "    \\$($_.IPAddress)\$ShareName" -ForegroundColor Cyan }
        Say ''
        Say 'Бошқа компьютерда: chrome://extensions → «Загрузить распакованное» → манзил қаторига юқоридаги йўлни ёзинг.'
        Say 'Агар Windows логин сўраса — сервер компьютерининг фойдаланувчи номи ва паролини киритинг.'
    } else {
        Say 'Умумий папка олиб ташланди.' -ForegroundColor Green
    }
} catch {
    Say "Хато: $($_.Exception.Message)" -ForegroundColor Red
    Show-Done 'Аудит Радар — кенгайтма папкаси' $false; exit 1
}
Show-Done 'Аудит Радар — кенгайтма папкаси' $true
